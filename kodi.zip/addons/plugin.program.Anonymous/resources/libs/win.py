# -*- coding: utf-8 -*-
import subprocess
import xbmc ,os
from threading import Thread

def callprocess(process, args=False):
	if args:
		subprocess.call([process, args], creationflags=0x08000000)
	else:
		subprocess.call([process], creationflags=0x08000000)

try:
	kodipath = [os.path.join(xbmc.translatePath('special://xbmc/'), 'kodi.exe')]
	if 'portable_data' in xbmc.translatePath('special://home/'):
		kodipath += ['-p']
	Thread(target=callprocess, args=kodipath).start()
except:
	pass
'''
try:
	Thread(target=callprocess, args=[r'C:\Program Files (x86)\Kodi\kodi.exe']).start()
except:
	pass
try:
	Thread(target=callprocess, args=[r'C:\Program Files\Kodi\kodi.exe']).start()
except:
	pass
'''
xbmc.sleep(500)
os._exit(1)
