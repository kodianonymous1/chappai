# -*- coding: utf-8 -*-
# Name:        main.py
# Author:      Mancuniancol
# Created on:  28.01.2017
# Licence:     GPL v.3: http://www.gnu.org/copyleft/gpl.html
from parsers import *
from time import sleep

# Gets the token
if Browser.open("%s/pubapi_v2.php?get_token=get_token&app_id=script.magnetic.rarbg-mc" % Settings.url):
    items = parse_json(Browser.content)
sleep(2)


def extract_torrents(html):
    """
    Parse the HTML to get Torrents
    :param html: html code of the page
    :type html: str or None
    :return: dict
    """
    links = parse_json(html)
    logger.log.debug(links)
    if "error" not in links:
        for link in links.get("torrent_results", []):
            name = link["title"]
            magnet = link["download"]
            size = "%d MB" % (link["size"] / 1048576)
            seeds = link["seeders"]
            peers = link["leechers"]
            yield (name, "", magnet, size, seeds, peers)  # name, info_hash, magnet, size, seeds, peers


def search(info):
    """
    General Search
    :param info: payload
    :type info: dict or None
    :return: torrents
    """
    Filtering.use_general(info)
    Filtering.get_data = dict(mode='search',
                              search_string='QUERY',
                              format='json_extended',
                              app_id='script.magnetic.rarbg-mc',
                              token=items.get("token", ""))
    return process(generator=extract_torrents)


def search_movie(info):
    """
    Movie Search
    :param info: payload
    :type info: dict or None
    :return: torrents
    """
    Filtering.use_movie(info)
    Filtering.get_data = dict(mode='search',
                              search_string='QUERY',
                              format='json_extended',
                              app_id='script.magnetic.rarbg-mc',
                              token=items.get("token", ""))
    return process(generator=extract_torrents)


def search_episode(info):
    """
    Episode Search
    :param info: payload
    :type info: dict or None
    :return: torrents
    """
    if info['absolute_number'] == 0:
        Filtering.use_tv(info)
    else:
        Filtering.use_anime(info)
    Filtering.get_data = dict(mode='search',
                              search_string='QUERY',
                              format='json_extended',
                              app_id='script.magnetic.rarbg-mc',
                              token=items.get("token", ""))
    return process(generator=extract_torrents)


def search_season(info):
    """
    Season Search
    :param info: payload
    :type info: dict or None
    :return: torrents
    """
    return []


# This registers your module for use
register(search, search_movie, search_episode, search_season)
