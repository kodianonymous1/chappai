# -*- coding: utf-8 -*-
# Name:        main.py
# Author:      Mancuniancol
# Created on:  28.01.2017
# Licence:     GPL v.3: http://www.gnu.org/copyleft/gpl.html
from parsers import *


def extract_torrents(html):
    """
    Parse the HTML to get Torrents
    :param html: html code of the page
    :type html: str or None
    :return: dict
    """
    links = parse_json(html)
    logger.log.debug(links)
    if "data" in links:
        for link in links["data"].get('movies', []):
            for torrent in link.get('torrents', []):
                name = '%s %s' % (link["title_long"], torrent["quality"])  # name
                info_hash = torrent["hash"]  # magnet
                size = torrent["size"]
                seeds = torrent["seeds"]
                peers = torrent["peers"]
                yield (name, info_hash, "", size, seeds, peers)  # name, info_hash, magnet, size, seeds, peers


def search(info):
    """
    General Search
    :param info: payload
    :type info: dict or None
    :return: torrents
    """
    Filtering.use_general(info)
    return process(generator=extract_torrents)


def search_movie(info):
    """
    Movie Search
    :param info: payload
    :type info: dict or None
    :return: torrents
    """
    Filtering.use_movie(info)
    return process(generator=extract_torrents)


def search_episode(info):
    """
    Episode Search
    :param info: payload
    :type info: dict or None
    :return: torrents
    """
    return []


def search_season(info):
    """
    Season Search
    :param info: payload
    :type info: dict or None
    :return: torrents
    """
    return []


# This registers your module for use
register(search, search_movie, search_episode, search_season)
