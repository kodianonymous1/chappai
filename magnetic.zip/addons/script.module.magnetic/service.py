# coding: utf-8
# Name:        service.py
# Author:      Mancuniancol
# Created on:  28.11.2016
# Licence:     GPL v.3: http://www.gnu.org/copyleft/gpl.html
"""
Service module of Magnetic
"""
import datetime
import threading
import xbmc
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
from SocketServer import ThreadingMixIn
from time import strptime

from resources.lib import logger, magnetic
from resources.lib.constants import ADDON_VERSION, MAGNETIC_SERVICE_HOST, MAGNETIC_SERVICE_PORT
from resources.lib.storage import Storage
from resources.lib.utils import check_watched, clean_cache, clear_info, get_item_player, info_video, is_playing, \
    is_watched, remove_resume_point, set_resume_point, timedelta_total_seconds
from resources.lib.video_info import Video

# to avoid error strptime working with threads
strptime("22 Jul 2017", '%d %b %Y')


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """
    Handle requests in a separate thread.
    """
    daemon_threads = True
    allow_reuse_address = True


# noinspection PyPep8Naming
class ParserHandler(BaseHTTPRequestHandler):
    """
    Requests GET and POST
    """

    def do_HEAD(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()

    # parser add-on callback to append results to response
    def do_POST(self):
        magnetic.process_parser(self)

    # Kodi call to get results
    def do_GET(self):
        magnetic.process_torrent(self) if "uri=" in self.path else magnetic.get_results(self)


if __name__ == '__main__':
    from BaseHTTPServer import HTTPServer

    server = ThreadedHTTPServer((MAGNETIC_SERVICE_HOST, MAGNETIC_SERVICE_PORT), ParserHandler)
    clean_cache()
    timer_storage = Storage.open('time', ttl=None)
    timer = timer_storage.get('time', datetime.datetime.now() - datetime.timedelta(seconds=86400))
    logger.info('')
    logger.info('                          _   _')
    logger.info(' _ __  __ _ __ _ _ _  ___| |_(_)__')
    logger.info("| '  \/ _' / _' | ' \/ -_)  _| / _|")
    logger.info('|_|_|_\__,_\__, |_||_\___|\__|_\__|')
    logger.info('          |___/')
    logger.info('')
    logger.info('Author: mancuniancol')
    logger.info('Version: %s' % ADDON_VERSION)
    logger.info('Magnetic service at ' + str(MAGNETIC_SERVICE_HOST) + ":" + str(MAGNETIC_SERVICE_PORT))
    logger.info('Last subscription update: %s' % timer)
    threading.Timer(0, server.serve_forever).start()
    it_was_playing = False
    previous_time_video = 0
    time_video = 0
    while not xbmc.abortRequested:
        xbmc.sleep(500)
        if timedelta_total_seconds(datetime.datetime.now() - timer) > 21600:
            Video.update_subscription()
            timer = datetime.datetime.now()
            timer_storage['time'] = timer
            timer_storage.sync()
            logger.info('Next update at %s' % str(timer))

        if is_playing():
            it_was_playing = True
            time_video = xbmc.Player().getTime()
            total_time_video = xbmc.Player().getTotalTime()

            if (time_video - previous_time_video) > 60:
                previous_time_video = time_video
                set_resume_point(time_video)

            if not info_video:
                get_item_player()

            if not is_watched() and time_video > total_time_video - 300:
                logger.debug("### It is playing: " + repr(check_watched()))
                remove_resume_point()

        else:
            if it_was_playing:
                set_resume_point(time_video)
                it_was_playing = False
                time_video = 0
                clear_info()

    server.shutdown()
    timer_storage.close()
    logger.info("Exiting Magnetic service, Bye!")
