# coding: utf-8
# Name:        main.py
# Author:      Mancuniancol
# Created on:  28.12.2016
# Licence:     GPL v.3: http://www.gnu.org/copyleft/gpl.html
"""
Main Menu magnetic Subscription manager
"""

import sys
import xbmcaddon
import xbmcgui
import xbmcplugin
from os import path
from re import findall
from urllib import quote_plus, unquote_plus
from urlparse import parse_qsl

import resources.lib.json_rcp as json_rcp
from resources.lib.play import search
from resources.lib.storage import *
from resources.lib.utils import ADDON_FANART, check_group_parser, check_parser, clean_cache, end_busy, \
    end_notification, magnetizer, remove_folder, start_busy, string
from resources.lib.utils_video import add_library, remove_subscription, update_imdb, update_subscription
from resources.lib.video_info import find_art_imdb, get_tv_shows_list

base_url = sys.argv[0]
add_on_handle = int(sys.argv[1])
args = dict(parse_qsl(sys.argv[2][1:]))
# read arguments
content_type = args.get('content_type', "video")
mode = args.get('mode', None)
title = unquote_plus(args.get('title', '')).decode('utf-8')
imdb_id = args.get('imdb_id', None)
absolute_number = args.get('absolute_number', '')
operation = args.get('search', None)
add_on_id = args.get('addonid', '')
# storage and global variables
listing = []
tv_shows = Storage.open('subscriptions', ttl=None)
information = Storage.open('library', ttl=None)
speed_parsers = Storage.open("speed")


# functions
def erase():
    """
    Erase cache with the parsers information
    """
    Storage.open("parsers").clear()
    clean_cache()


# START THE MENU
if mode == 'parser':
    erase()
    xbmcaddon.Addon(add_on_id).openSettings()

elif mode == 'settings':
    erase()
    xbmcaddon.Addon().openSettings()

elif mode == 'clear_cache':
    erase()
    xbmcgui.Dialog().ok('magnetic', string(32076))

elif mode == 'copy':
    start_busy()
    erase()
    path_folder = xbmcaddon.Addon(add_on_id).getAddonInfo('path')
    value = dict()  # it contains all the settings from xml file
    fileName = path.join(path_folder, "resources", "settings.xml")
    if path.isfile(fileName):
        with open(fileName, 'r') as fp:
            data = fp.read()

        for key in findall('id="(\w+)"', data):
            if 'url' not in key and 'separator' not in key:
                value[key] = xbmcaddon.Addon(add_on_id).getSetting(id=key)

        items = []
        for one_parser in json_rcp.get_list_parsers():
            if one_parser['enabled']:
                items.append(one_parser['addonid'])

        items.remove(add_on_id)
        ret = xbmcgui.Dialog().select(string(32077), [string(32078)] + items + ['CANCEL'])
        list_copy = (items if ret == 0 else [items[ret - 1]])
        if ret != -1 and ret <= len(items):
            for key, val in value.items():
                if not key.endswith('_search') and 'read_magnet_link' not in key:
                    for one_parser in list_copy:
                        xbmcaddon.Addon(one_parser).setSetting(id=key, value=val)

            xbmcgui.Dialog().ok('magnetic', string(32079) % (add_on_id, '\n'.join(list_copy)))

    end_busy()

elif mode == 'check':
    speed_parsers[add_on_id] = check_parser(add_on_id)
    speed_parsers.close()
    xbmc.executebuiltin("Container.Refresh")

elif mode == 'check_all':
    from xbmcgui import Dialog

    start_busy()
    dialog = Dialog()
    for one_parser in json_rcp.get_list_parsers():
        if one_parser['enabled']:
            dialog.notification(one_parser['name'], string(32093), one_parser['thumbnail'], 10000)
            speed_parsers[one_parser['addonid']] = check_parser(one_parser['addonid'])
            speed_parsers.close()

    dialog.notification('magnetic', string(32094), time=50)
    del dialog
    end_busy()
    xbmc.executebuiltin("Container.Refresh")

elif mode == 'check_group':
    erase()
    message = check_group_parser()
    xbmcgui.Dialog().ok('magnetic', string(32095) % message)

elif mode == 'enable':
    erase()
    json_rcp.enable_parser(add_on_id)
    xbmc.executebuiltin("Container.Refresh")

elif mode == 'disable':
    erase()
    json_rcp.disable_parser(add_on_id)
    xbmc.executebuiltin("Container.Refresh")

elif mode == 'enable_all':
    erase()
    for one_parser in json_rcp.get_list_parsers():
        json_rcp.enable_parser(one_parser['addonid'])

    xbmc.executebuiltin("Container.Refresh")

elif mode == 'disable_all':
    for one_parser in json_rcp.get_list_parsers():
        json_rcp.disable_parser(one_parser['addonid'])
    xbmc.executebuiltin("Container.Refresh")

elif mode == 'defaults_all':
    import shutil
    import os.path

    erase()
    base_path = xbmc.translatePath('special://userdata/addon_data')
    for one_parser in json_rcp.get_list_parsers():
        folder = path.join(base_path, one_parser['addonid'])
        if os.path.isfile(folder):
            shutil.rmtree(folder)

    xbmcgui.Dialog().ok('magnetic', string(32096))

elif operation:
    # contextual menu - Magnetizer
    start_busy()
    xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    xbmcplugin.endOfDirectory(add_on_handle, True, False, False)
    search(info=args)

elif mode == 'add_library':
    xbmcgui.Dialog().notification('[COLOR FFFFD800]magnetic[/COLOR]', string(32145) % title, time=300000)
    start_busy()
    add_library(imdb_id, title)
    end_busy()
    end_notification()
    xbmcgui.Dialog().notification('[COLOR FFFFD800]magnetic[/COLOR]', string(32146) % title)
    mode = None

elif mode == 'rebuilt_library':
    xbmcgui.Dialog().notification('[COLOR FFFFD800]magnetic[/COLOR]', string(32147) % title)
    start_busy()
    remove_subscription(imdb_id, remove=True)
    add_library(imdb_id, title, force=True)
    xbmcgui.Dialog().notification('[COLOR FFFFD800]magnetic[/COLOR]', string(32148) % title)
    end_busy()
    mode = None

elif mode == 'magnetizer':
    start_busy()
    magnetizer()
    end_busy()

elif mode == 'select':
    # creation menu Select
    listing = []
    # Rebuilt
    is_folder = False
    url = base_url + '?mode=rebuilt&imdb_id=%s&title=%s' % (imdb_id, quote_plus(title))
    list_item = xbmcgui.ListItem(label=string(33149))
    icon, fanart = find_art_imdb(imdb_id)
    list_item.setArt({'thumb': icon,
                      'icon': icon,
                      'fanart': fanart})
    listing.append((url, list_item, is_folder))
    # Remove
    url = base_url + '?mode=remove&imdb_id=%s&title=%s' % (imdb_id, quote_plus(title))
    list_item = xbmcgui.ListItem(label=string(33150))
    icon, fanart = find_art_imdb(imdb_id)
    list_item.setArt({'thumb': icon,
                      'icon': icon,
                      'fanart': fanart})
    listing.append((url, list_item, is_folder))
    # update
    url = base_url + '?mode=update_imdb&imdb_id=%s&title=%s' % (imdb_id, quote_plus(title))
    list_item = xbmcgui.ListItem(label=string(33158))
    icon, fanart = find_art_imdb(imdb_id)
    list_item.setArt({'thumb': icon,
                      'icon': icon,
                      'fanart': fanart})
    listing.append((url, list_item, is_folder))

elif mode == 'add':
    query = xbmcgui.Dialog().input(string(33151))
    if len(query) > 0:
        # get list of shows
        list_shows, list_imdb = get_tv_shows_list(query)
        if len(list_shows) == 0:
            xbmcgui.Dialog().ok(string(33010), string(33152))

        else:
            resp = xbmcgui.Dialog().select(string(33153), list_shows)
            if resp > -1:
                title = list_shows[resp]
                imdb_id = list_imdb[resp]
                logger.debug(title)
                logger.debug(imdb_id)
                start_busy()
                payload = '?mode=add_library&imdb_id=%s&title=%s' % (imdb_id, quote_plus(title.encode('utf-8')))
                xbmc.executebuiltin("XBMC.RunPlugin(plugin://script.module.magnetic%s)" % payload)
                xbmc.executebuiltin("Container.Refresh")
                end_busy()

elif mode == 'remove':
    if xbmcgui.Dialog().yesno(string(33010), string(33154) % title):
        del tv_shows[imdb_id]
        tv_shows.sync()
        del information[imdb_id]
        information.sync()
        # erasing files
        if xbmcgui.Dialog().yesno(string(33010), string(33155) % title):
            start_busy()
            folder = xbmc.translatePath(xbmcaddon.Addon('script.module.magnetic').getSetting('shows_folder'))
            remove_folder(folder, title)
            folder = xbmc.translatePath(xbmcaddon.Addon('script.module.magnetic').getSetting('animes_folder'))
            remove_folder(folder, title)
            xbmc.executebuiltin('XBMC.CleanLibrary(video)')  # update the library with the new information
            xbmc.executebuiltin("Action(Back)")
            xbmc.executebuiltin("Container.Refresh")
            end_busy()

elif mode == 'rebuilt':
    if xbmcgui.Dialog().yesno(string(33010), string(33156) % title):
        payload = '?mode=rebuilt_library&imdb_id=%s&title=%s' % (imdb_id, quote_plus(title))
        start_busy()
        xbmc.executebuiltin("XBMC.RunPlugin(plugin://script.module.magnetic%s)" % payload)
        end_busy()

elif mode == 'update_imdb':
    start_busy()
    update_imdb(imdb_id)
    xbmcgui.Dialog().ok('magnetic', string(32094))
    end_busy()

elif mode == 'update':
    update_subscription()

if not mode:
    if content_type == 'executable':
        # creation menu Programs
        for one_parser in json_rcp.get_list_parsers():
            name_parser = one_parser['name']  # gets name
            tag = '[B][COLOR FF008542][%s] [/COLOR][/B]' % string(32090)
            menu_check = [
                (string(32082), 'XBMC.RunPlugin(plugin://script.module.magnetic?mode=check&addonid=%s)' %
                 one_parser['addonid'])]
            menu_enable = (
                string(32081), 'XBMC.RunPlugin(plugin://script.module.magnetic?mode=disable&addonid=%s)' %
                one_parser['addonid'])

            if not one_parser['enabled']:
                tag = '[B][COLOR FFC40401][%s] [/COLOR][/B]' % string(32091)
                menu_enable = (string(32080),
                               'XBMC.RunPlugin(plugin://script.module.magnetic?mode=enable&addonid=%s)' %
                               one_parser['addonid'])
                menu_check = []

            speed = speed_parsers.get(one_parser['addonid'], '')
            list_item = xbmcgui.ListItem(label=tag + name_parser + speed)
            icon = one_parser["thumbnail"]
            fanart = one_parser["fanart"]
            list_item.setArt({'thumb': icon,
                              'icon': icon,
                              'fanart': fanart})

            if one_parser['enabled']:
                url = base_url + '?mode=parser&addonid=%s' % one_parser['addonid']

            else:
                url = ''
            is_folder = False
            list_item.addContextMenuItems(menu_check +
                                          [(string(32083),
                                            'XBMC.RunPlugin(plugin://script.module.magnetic?mode=check_all)'),
                                           (string(32084),
                                            'XBMC.RunPlugin(plugin://script.module.magnetic?mode=check_group)'),
                                           menu_enable,
                                           (string(32085),
                                            'XBMC.RunPlugin(plugin://script.module.magnetic?mode=enable_all)'),
                                           (string(32086),
                                            'XBMC.RunPlugin(plugin://script.module.magnetic?mode=disable_all)'),
                                           (string(32087),
                                            'XBMC.RunPlugin(plugin://script.module.magnetic?mode=copy&addonid=%s)' %
                                            one_parser['addonid']),
                                           (string(32088),
                                            'XBMC.RunPlugin(plugin://script.module.magnetic?mode=defaults_all)'),
                                           (string(32089),
                                            'XBMC.RunPlugin(plugin://script.module.magnetic?mode=settings)')],
                                          replaceItems=True)
            listing.append((url, list_item, is_folder))

    else:
        # creation menu Video
        listing = []
        # Add new subscription
        is_folder = True
        url = base_url + '?mode=add'
        list_item = xbmcgui.ListItem(label=string(33157))
        icon = None
        fanart = ADDON_FANART
        list_item.setArt({'thumb': icon,
                          'icon': icon,
                          'fanart': fanart})
        listing.append((url, list_item, is_folder))
        # update
        url = base_url + '?mode=update'
        list_item = xbmcgui.ListItem(label=string(33158))
        icon = None
        fanart = ADDON_FANART
        list_item.setArt({'thumb': icon,
                          'icon': icon,
                          'fanart': fanart})
        listing.append((url, list_item, is_folder))

        #  Subscriptions
        for imdb_id in tv_shows:
            video = information.get(imdb_id, {imdb_id: None})
            if video[imdb_id]:
                title = video[imdb_id]['title']
                list_item = xbmcgui.ListItem(label=title)
                icon, fanart = find_art_imdb(imdb_id)
                list_item.setArt({'thumb': icon,
                                  'icon': icon,
                                  'fanart': fanart})
                is_folder = True
                url = base_url + '?mode=select&imdb_id=%s&title=%s' % (imdb_id, title)
                listing.append((url, list_item, is_folder))

if len(listing) > 0:
    xbmcplugin.addDirectoryItems(add_on_handle, listing, len(listing))
    xbmcplugin.addSortMethod(add_on_handle, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(add_on_handle, updateListing=False)

# destroying storage objects
tv_shows.close()
information.close()
speed_parsers.close()
del tv_shows
del information
del speed_parsers
