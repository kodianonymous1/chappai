# coding: utf-8
# Name:        play.py
# Author:      Mancuniancol
# Created on:  28.11.2016
# Licence:     GPL v.3: http://www.gnu.org/copyleft/gpl.html

import xbmc
from urllib import quote_plus

from resources.lib.logger import log
from resources.lib.normalize import clean_title
from resources.lib.utils_video import find_imdb


def main():
    label = xbmc.getInfoLabel("ListItem.Label")
    imdb_id = xbmc.getInfoLabel("ListItem.IMDBNumber")
    if not imdb_id.startswith('tt'):
        imdb_id = find_imdb(label)

    title = quote_plus(clean_title(label))
    log.debug(label)
    log.debug(imdb_id)
    log.debug(title)

    # TODO if the imdb_id doesn't exist
    payload = '?mode=add_library&imdb_id=%s&title=%s' % (imdb_id, title)
    xbmc.executebuiltin("XBMC.RunPlugin(plugin://script.module.magnetic%s)" % payload)


if __name__ == '__main__':
    main()
