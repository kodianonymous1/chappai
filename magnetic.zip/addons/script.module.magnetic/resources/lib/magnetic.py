# coding: utf-8
# coding: utf-8
# Name:        magnetic.py
# Author:      Mancuniancol
# Created on:  28.11.2016
# Licence:     GPL v.3: http://www.gnu.org/copyleft/gpl.html
"""
Magnetic module which manages the parsers and requests
"""
import urlparse
from urllib import quote_plus, unquote_plus

import filtering
from browser import get_cloudhole_clearance, get_cloudhole_key, read_torrent
from normalize import clean_title, exceptions_title
from storage import *
from utils import *
from utils_video import find_imdb

parser_results = []
parser_name = []
available_parsers = 0
counter = time.clock() + 60
request_time = time.clock()


def process_torrent(self):
    """
    Process the torrent information from a webpage
    :param self: request
    :type self: parsersHandler
    """
    # request data
    parsed = urlparse.urlparse(self.path)
    info = urlparse.parse_qs(parsed.query)
    uri = info.get('uri', [''])[0]
    filename = str(uuid.uuid4()) + '.torrent'

    # headers
    self.send_response(200)
    self.send_header('Content-type', 'application/x-bittorrent')
    self.send_header('Content-Disposition', 'attachment; filename="%s"' % filename)
    self.send_header('Content-Transfer-Encoding', 'binary')
    self.send_header('Accept-Ranges', 'bytes')
    self.end_headers()

    # torrent
    unquote_uri = unquote_plus(uri)
    torrents = read_torrent(unquote_uri)
    self.wfile.write(torrents)
    self.finish()


def process_parser(self):
    """
    parser call back with results
    :param self: request
    :type self: ParsersHandler
    """
    global parser_results
    global available_parsers
    global parser_name
    global counter

    # parsing path
    parsed = urlparse.urlparse(self.path)
    addon_id = urlparse.parse_qs(parsed.query)['addonid'][0]
    content_length = int(self.headers['Content-Length'])
    payload = self.rfile.read(content_length)
    # headers
    self.send_response(200)
    self.send_header('Content-type', 'text/html')
    self.end_headers()
    # send ok
    self.wfile.write("OK")
    self.finish()
    # continue
    data = json.loads(payload)
    logger.info("parser " + addon_id + " returned " + str(len(data)) + " results in " + str(
        "%.1f" % round(time.clock() - request_time, 2)) + " seconds")
    parser_results.extend(data)
    available_parsers -= 1
    counter = time.clock()
    if addon_id in parser_name:
        parser_name.remove(addon_id)


def get_results(self):
    """
    Process to get the results
    :param self: request
    :type self: parsersHandler
    """
    global parser_results

    # init list
    parser_results = []

    # request data
    parsed = urlparse.urlparse(self.path)
    info = urlparse.parse_qs(parsed.query)
    operation = info.get('search', [''])[0]
    parser = info.get('parser', [''])[0]
    title = unquote_plus(str(info.get('title', [''])[0]).replace("'", ""))
    title = exceptions_title(title)
    year = info.get('year', [''])[0]
    imdb_id = info.get('imdb_id', [''])[0]
    absolute_number = info.get('absolute_number', [''])[0]
    if len(imdb_id) < 5:
        imdb_id = (find_imdb(title + ' ' + year).strip())

    if operation == 'general':
        method = 'search'
        general_item = {'imdb_id': str(imdb_id),
                        'title': title}
        payload = json.dumps(general_item)
        subject = title

    elif operation == "movie":
        method = "search_movie"
        title = clean_title(title)
        movie_item = {'imdb_id': str(imdb_id),
                      'title': title,
                      'year': str(year)}
        payload = json.dumps(movie_item)
        if len(year) > 0:
            subject = '%s (%s)' % (title, year)

        else:
            subject = title

    elif operation == "episode":
        method = "search_episode"
        season = get_int(info.get('season', ['0'])[0])
        episode = get_int(info.get('episode', ['0'])[0])
        episode_item = {'imdb_id': str(imdb_id),
                        'title': title,
                        'season': season,
                        'episode': episode,
                        'absolute_number': get_int(absolute_number)}
        payload = json.dumps(episode_item)
        subject = '%s S%02dE%02d' % (title, season, episode)

    elif operation == "season":
        method = "search_season"
        season = get_int(info.get('season', ['0'])[0])
        season_item = {'imdb_id': str(imdb_id),
                       'title': title,
                       'season': season}
        payload = json.dumps(season_item)
        subject = '%s S(%02d)' % (title, season)

    else:
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        # send the results
        self.wfile.write("OPERATION NOT FOUND")
        self.finish()
        return

    if len(title) == 0 or len(method) == 0:
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        # send the results
        self.wfile.write("Payload Incomplete!!!      " + repr(payload))
        self.finish()
        return

    # check if the search is in cache
    database = Storage.open("parsers", 60 * 6, True)
    cache = database.get(payload, None)
    if cache is None or len(parser) > 0:
        # read the cloudhole key from the API
        if get_setting("use_cloudhole", bool):
            clearance, user_agent = get_cloudhole_clearance(get_cloudhole_key())
            set_setting('clearance', clearance)
            set_setting('user_agent', user_agent)

        # requests the results
        normalized_list = search(method, payload, parser, subject)
        results = normalized_list
        # if there is results it will be saved in cache
        if len(normalized_list.get('magnets', [])) > 0:
            database[payload] = results
            database.sync()
    else:
        normalized_list = cache
        display_message_cache(subject)

    logger.info("Filtering returned: " + str(len(normalized_list.get('magnets', []))) + " results")

    # headers
    self.send_response(200)
    self.send_header('Content-type', 'application/json')
    self.end_headers()
    # send the results
    self.wfile.write(json.dumps(normalized_list))
    self.finish()


def search(method, payload_json, parser="", subject=""):
    """
    Search for torrents - call parsers
    :param subject: Information of the query
    :type subject: str
    :param method: method of search
    :type method: str
    :param payload_json: parload in json format
    :type payload_json: str
    :param parser: name of parser, if the search is individually
    :type parser: str
    :return list of results
    """
    global parser_results
    global available_parsers
    global request_time
    global parser_name
    global counter

    # close any dialog
    close_dialog()
    # reset global variables
    parser_results = []
    parser_name = []
    available_parsers = 0
    counter = time.clock() + 60
    request_time = time.clock()
    # collect data
    if len(parser) == 0:
        set_setting('testing', 'false')
        add_ons = json_rcp.get_list_parsers_enabled()
    else:
        set_setting('testing', 'true')
        add_ons = [parser]

    end_busy()
    if len(add_ons) == 0:
        # return empty list
        notify(string(32060), image=get_icon_path())
        logger.info("No parsers installed")
        return {'results': 0, 'duration': "0 seconds", 'magnets': []}

    p_dialog = xbmcgui.DialogProgressBG()
    p_dialog.create('[COLOR FFFFD800][B]magnetic[/B][/COLOR] : %s' % subject, string(32061))
    total = float(len(add_ons))
    for add_on in add_ons:
        available_parsers += 1
        logger.debug("Processing:" + add_on)
        message = "%s: %s" % (string(32066), add_on.replace('script.magnetic.', ''))
        p_dialog.update(int(available_parsers / total * 50), message=message)
        xbmc.executebuiltin(
            "RunScript(" + add_on + "," + add_on + "," + method + "," + quote_plus(payload_json.encode('utf-8')) + ")",
            True)
        xbmc.sleep(500)

    parsers_time = time.clock()
    total = float(available_parsers)
    # while all parsers have not returned results or timeout not reached
    time_out = min(get_setting("timeout", int), 60)
    # if all parsers have returned results exit or more 15s between parsers, check every 100ms
    while time.clock() - parsers_time < time_out and available_parsers > 0 and time.clock() - counter < time_out / 2:
        xbmc.sleep(100)
        message = string(32062) % available_parsers if available_parsers > 1 else string(32063)
        p_dialog.update(int((total - available_parsers) / total * 50 + 50), message=message)

    # time-out parser
    if len(parser_name) > 0:
        message = ', '.join(parser_name)
        message = message.replace('script.magnetic.', '').title() + string(32064)
        logger.info(message)
        notify(message, ADDON_ICON)

    # filter magnets and append to results
    filtered_results = dict(magnets=filtering.apply_filters(parser_results))
    # append number and time on payload
    filtered_results['results'] = len(filtered_results['magnets'])
    filtered_results['duration'] = str("%.1f" % round(time.clock() - request_time, 2)) + " seconds"
    logger.info(
        "Magnetic search returned: %s results in %s" % (str(len(parser_results)), filtered_results['duration']))
    # destroy notification object
    p_dialog.close()
    del p_dialog

    return filtered_results
