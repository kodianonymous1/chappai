# coding: utf-8
# Name:        json_rcp.py
# Author:      Mancuniancol
# Created on:  27.08.2017
# Licence:     GPL v.3: http://www.gnu.org/copyleft/gpl.html
"""
Helper methods
"""
import json
import xbmc


def get_list_parsers():
    """
    Get the list of installed parsers
    :return: list of installed parsers
    """
    results = []
    request = {"jsonrpc": "2.0",
               "method": "Addons.GetAddons",
               "id": 1,
               "params": {"type": "xbmc.python.script",
                          "properties": ["enabled", "name", "thumbnail", "fanart"]
                          }
               }
    list_parsers = json_rpc(request)
    for one_parser in list_parsers["result"].get("addons", []):
        if one_parser['addonid'].startswith('script.magnetic.'):
            results.append(one_parser)

    return results


def get_list_parsers_enabled():
    """
    Get the list of enabled parsers
    :return: list of enable parsers
    """
    results = []
    request = {"jsonrpc": "2.0",
               "method": "Addons.GetAddons",
               "id": 1,
               "params": {"type": "xbmc.python.script",
                          "properties": ["enabled", "name"]
                          }
               }
    list_parsers = json_rpc(request)
    for one_parser in list_parsers["result"].get("addons", []):
        if one_parser['addonid'].startswith('script.magnetic.') and one_parser['enabled']:
            results.append(one_parser['addonid'])

    return results


def disable_parser(parser):
    """
    Disable a specific parser
    :param parser: parser to disable
    :type parser: str
    """
    request = {"jsonrpc": "2.0",
               "method": "Addons.SetAddonEnabled",
               "id": 1,
               "params": {"addonid": parser, "enabled": False}
               }
    json_rpc(request)


def enable_parser(parser):
    """
    Enable a specific parser
    :param parser: parser to enable
    :type parser: str
    """
    request = {"jsonrpc": "2.0",
               "method": "Addons.SetAddonEnabled",
               "id": 1,
               "params": {"addonid": parser, "enabled": True}
               }
    json_rpc(request)


def json_rpc(request=None):
    """
    Execute json_rcp
    :param request: command
    :return:
    """
    if request:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    else:
        return dict()


def get_movies():
    """
    Get the movies in Kodi's DB
    :return:
    """
    request = {"jsonrpc": "2.0",
               "method": "VideoLibrary.GetMovies",
               "id": "libMovies",
               "params": {
                   "properties": ["title", "imdbnumber", "year"]
               }}
    return json_rpc(request).get("result", {}).get("movies", [])


def get_tv_shows():
    """
    Get the TV Shows in Kodi's DB
    :return:
    """
    request = {"jsonrpc": "2.0",
               "method": "VideoLibrary.GetTVShows",
               "id": "libTvShows",
               "params": {
                   "properties": ["title", "imdbnumber", "thumbnail", "fanart"]
               }}

    return json_rpc(request).get("result", {}).get("tvshows", [])


def get_episode(tv_show_id, episode, season):
    """
    Get the episode from Kodi's DB
    :param tv_show_id: TVDB id
    :param episode: number episode
    :param season: number season
    :return:
    """
    request = {"jsonrpc": "2.0",
               "method": "VideoLibrary.GetEpisodes",
               "id": "1",
               "params": {"tvshowid": tv_show_id,
                          "season": season,
                          "sort": {"method": "episode"},
                          "properties": ["title", "playcount", "season", "episode", "file"],
                          }
               }
    episodes = []
    for elem in json_rpc(request).get("result", {}).get("episodes", []):
        if elem['episode'] == episode:
            episodes.append(elem)

    return episodes


def set_watched(episode_id):
    """
    Change the status for watched
    :param episode_id:
    :return:
    """
    request = {'jsonrpc': '2.0', 'id': '1',
               'method': 'VideoLibrary.SetEpisodeDetails',
               'params': {'playcount': 1,
                          'episodeid': episode_id},
               }
    json_rpc(request)


def set_resume_point(episode_id, resume_point=0):
    """
    Create a resume point
    :param episode_id:
    :param resume_point: in seconds
    :return:
    """
    request = {'jsonrpc': '2.0', 'id': 'setResumePoint',
               'method': 'VideoLibrary.SetEpisodeDetails',
               'params': {"resume": {"position": resume_point},
                          'episodeid': episode_id},
               }
    json_rpc(request)


def get_item_player():
    """
    Get information from the active player
    return: dict
    """
    request = {"jsonrpc": "2.0",
               "method": "Player.GetActivePlayers",
               "id": 1}
    active_players = json_rpc(request)
    if 'result' not in active_players or active_players['result'][0]['type'] not in 'video':
        return {}

    player_id = active_players['result'][0]['playerid']
    request = {"jsonrpc": "2.0",
               "method": "Player.GetItem",
               "params": {"properties": ["title", "season", "episode", "duration", "showtitle", "tvshowid"],
                          "playerid": player_id},
               "id": "VideoGetItem"}

    return json_rpc(request).get("result", {}).get("item", {})
