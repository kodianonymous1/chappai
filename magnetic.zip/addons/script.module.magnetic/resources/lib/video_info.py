# coding: utf-8
# Name:        video_info.py
# Author:      Mancuniancol
# Created on:  28.11.2016
# Licence:     GPL v.3: http://www.gnu.org/copyleft/gpl.html
"""
Collect information for a Video using IMDB ID
"""
import os
import xbmc
import xbmcaddon
import xbmcgui
from datetime import datetime
from re import search
from shutil import rmtree
from time import strptime
from urllib import quote_plus

import json_rcp
import logger
from browser import Browser
from ehp import Html
from normalize import clean_title, formatting_title
from storage import Storage


def update_library():
    if not xbmc.getCondVisibility('Library.IsScanningVideo'):
        xbmc.executebuiltin('XBMC.UpdateLibrary(video)')  # update the library with the new information
        while xbmc.getCondVisibility('Library.IsScanningVideo'):
            xbmc.sleep(1000)


def clean_library():
    """
    Clean library
    :return:
    """
    if not xbmc.getCondVisibility('Library.IsScanningVideo'):
        xbmc.executebuiltin('XBMC.CleanLibrary(video)')  # clean the library
        while xbmc.getCondVisibility('Library.IsScanningVideo'):
            xbmc.sleep(1000)


def string(id_value):
    """
    Internationalisation string
    :param id_value: id value from string.po file
    :type id_value: int
    :return: the translated string
    """
    return xbmcaddon.Addon().getLocalizedString(id_value)


def get_thetvdb_id(imdb_id=None):
    """
    Find thetvdb id from imdb_id
    :param imdb_id: imdb of the tv show
    :type imdb_id: str
    :return: thetvdb id
    """
    result = None
    if imdb_id:
        thetvdb = Storage.open('thetvdb')
        if imdb_id in thetvdb:
            result = thetvdb[imdb_id]

        else:
            request = 'http://thetvdb.com/api/GetSeriesByRemoteID.php?imdbid=%s' % imdb_id
            if Browser.open(request):
                s = Browser.content
                result = s[s.find("<seriesid>") + 10:s.find("</seriesid>")]
                thetvdb[imdb_id] = result

        thetvdb.close()

    return result


def get_tv_shows_list(title=None):
    """
    Get the list the tv shows with IMDB id
    :param title: title of the video
    :type title: str or None
    :return: list the tv shows with IMDB id
    """
    list_titles = []
    list_imdb_id = []
    if title and len(title) > 0:
        title = title.lower()

        url = 'https://www.bing.com/search?q=%s+imdb' % title.replace(' ', '+')
        list_titles = []
        list_imdb_id = []
        if Browser.open(url):
            dom = Html().feed(Browser.content)
            row_search = dom.find_all('li', ('class', 'b_algo'))

            for item in row_search:
                list_titles.append(item('a'))
                imdb_search = search('(tt[0-9]+)', item('cite'))

                if imdb_search:
                    result = imdb_search.group(1)

                else:
                    result = ''

                list_imdb_id.append(result)

    return list_titles, list_imdb_id


def find_art_imdb(imdb_id=None):
    """
    Find the Art for Tv Show
    :param imdb_id:
    :return:
    """
    thumbnail = None
    fanart = None
    if imdb_id:
        tv_shows = json_rcp.get_tv_shows()
        thetvdb_id = get_thetvdb_id(imdb_id)

        for show in tv_shows:
            if thetvdb_id in show['imdbnumber']:
                thumbnail = show['thumbnail']
                fanart = show['fanart']

    return thumbnail, fanart


def find_imdb(title=None):
    """
    Get imdb from title
    :param title: title of the video
    :type title: str or None
    :return: imdb id
    """
    imdb = Storage.open('imdb')
    title = title.lower()
    result = imdb.get(title, None)
    if not result:
        url = 'https://www.bing.com/search?q=%s+imdb' % title.replace(' ', '+')
        if Browser.open(url):
            imdb_search = search('(tt[0-9]+)', Browser.content)

            if imdb_search:
                result = imdb_search.group(1)

    imdb[title] = result
    imdb.close()
    return result


def search_title(title=None):
    """
    Returns possible torrents for tv show
    :param title:
    :return:
    """
    if not title:
        return

    url = "https://torrentz2.cc/search?f=%s" % quote_plus(title)
    if Browser.open(url):
        dom = Html().feed(Browser.content)
        row_search = "dom." + "find_once('div', ('class', 'results')).find_all('dl')"
        name_search = "item('a')"
        if dom is not None:
            for item in eval(row_search):
                if item is not None:
                    yield eval(name_search)


class Video:
    """
    Main class
    """
    _episodes_base_url = 'http://m.imdb.com/title/%s/episodes/?season=%s'
    _base_url = 'http://m.imdb.com/title/%s'
    _counter = 0
    _p_dialog = None
    _percent = 0
    imdb_id = None
    thetvdb_id = None
    is_movie = True
    is_anime = False
    title = None
    year = None
    seasons_episodes = dict()

    def __init__(self):
        pass

    @classmethod
    def _read_episodes(cls, season_value='1'):
        """
        Open the m.imdb page in the specific season and return web page content
        :param season_value: season to search
        :type season_value: str
        :return: str with the web page content
        """
        if not cls.imdb_id:
            return '<html></html>'

        url = cls._episodes_base_url % (cls.imdb_id, season_value)
        Browser.open(url)
        return Browser.content

    @classmethod
    def _read_title_year(cls):
        """
        Get the title and year from the stored imdb_id
        :return: nothing
        """
        url = cls._base_url % cls.imdb_id
        Browser.open(url)
        cls._counter += 1
        dom = Html().feed(Browser.content)
        if not dom:
            return

        title = dom.find_once('h1')()
        cls.title = ' '.join(title.split())
        s = cls.title + '()'
        cls.year = s[s.rfind("(") + 1:s.rfind(")")]
        anime = dom.find_once('p', ('class', 'infobar'))
        cls.is_anime = False
        cls.is_movie = 'Episode Guide' not in Browser.content
        if not cls.is_movie:
            cls.thetvdb_id = get_thetvdb_id(cls.imdb_id)
            s = cls.title + '()'
            cls.title = s[:s.find("(") - 1]
            cls.is_anime = 'Animation' in anime()
            if cls.is_anime:
                resp = xbmcgui.Dialog().yesno('Select type:', 'TV Show uses S00E00 format',
                                              'Anime uses absolute number EP000', nolabel='TV Show',
                                              yeslabel='Anime')
                cls.is_anime = resp != 0

    @classmethod
    def _new_info(cls, tv_show=None):
        """
        Parse the web page to get the new episodes and seasons from specific tv_show
        :param tv_show:
        :return:
        """
        if not tv_show:
            tv_show = dict()

        old_seasons = tv_show.keys()
        logger.debug('Old seasons:')
        logger.debug(old_seasons)
        max_season = str(max(int(x) for x in old_seasons + ['1']))
        logger.debug('Max season:' + max_season)
        html = cls._read_episodes(max_season)
        dom = Html().feed(html)
        if not dom:
            return dict()

        raw_seasons = dom.find_all('li', ('class', 'season_box'))
        new_seasons = list()
        seasons = []
        for season_tag in raw_seasons:
            season_number = season_tag(tag='a', attribute='season_number')
            if season_number.isdigit() and int(season_number) > 0:
                new_seasons.append(season_number)
                seasons.append(season_tag)

        difference = list(set(new_seasons) - set(old_seasons))
        logger.debug('Difference:')
        logger.debug(difference)
        if max_season not in difference:
            difference.append(max_season)

        # only check last season and new seasons
        for season in difference:
            tv_show[season] = []
            logger.debug(season)
            logger.debug(difference)
            html = cls._read_episodes(season)

            dom = Html().feed(html)
            episodes = dom.find_once('div', ('id', 'eplist')).find_all('div')
            for episode in episodes:
                array = episode('a').split('\n')
                if len(array) > 1:
                    try:
                        logger.debug(array)
                        date = array[-1].replace('.', '')
                        time_object = strptime(date, '%d %b %Y')
                        datetime_object = datetime(time_object.tm_year, time_object.tm_mon, time_object.tm_mday)
                        if datetime_object <= datetime.today():
                            tv_show[season].append(array[0].replace('.', ''))

                    except ValueError:
                        pass

            logger.debug(tv_show[season])

        # remove empty seasons
        for season in tv_show.keys():
            if len(tv_show[season]) == 0:
                del tv_show[season]

        logger.debug('Season-Episodes:')
        logger.debug(tv_show)
        return tv_show

    @classmethod
    def _is_new_movie(cls, imdb_id=None):
        """
        Check if the movie exists in Kodi's database
        :param imdb_id: imdb of the movie
        :type imdb_id: str
        :return: bool, True is the movie exists.  False, otherwise.
        """
        if not imdb_id:
            return False

        movies = json_rcp.get_movies()
        result = True
        for movie in movies:
            if imdb_id in movie['imdbnumber']:
                result = False
                break

        return result

    @classmethod
    def _is_new_episode(cls, thetvdb_id=None, season=None, episode=None):
        """
        Check if the episode exists in Kodi's database
        :param thetvdb_id: imdb of the tv show
        :type thetvdb_id: str
        :param season: number of the season of the episode
        :type season: str
        :param episode: number of the episode
        :type episode: str
        :return: bool, True is the episode exists.  False, otherwise.
        """
        if not thetvdb_id or not season or not episode:
            return False

        tv_shows = json_rcp.get_tv_shows()
        result = True

        for show in tv_shows:
            if thetvdb_id in show['imdbnumber']:
                # Found id show in Kodi database
                tv_show_id = show['tvshowid']
                episodes = json_rcp.get_episode(tv_show_id, episode, season)
                result = len(episodes) == 0
                logger.debug(episodes)

        return result

    @staticmethod
    def _create_strm(path, cleaned_title, title, link):
        """
        Create the strm file
        :param path: main path for movie or tv shows
        :type path: str
        :param cleaned_title: the title of the movie or tv show
        :type cleaned_title: str
        :param title: title of the movie or episode (S00E00 format)
        :type title: str
        :param link: link to call magnetizer
        :type link: str
        """
        folder = os.path.join(path, cleaned_title)
        try:
            if not os.path.exists(folder):
                os.makedirs(folder)

            filename = os.path.join(folder, title + '.strm')
            with open(filename, "w") as text_file:
                text_file.write(link)

        except Exception as e:
            print "Error: %s" % repr(e)

    @staticmethod
    def _create_nfo(path, cleaned_title, video_id=None):
        """
        Create the nfo in the main folder
        :param path: main path for movie or tv shows
        :type path: str
        :param cleaned_title: the title of the movie or tv show
        :type cleaned_title: str
        :param video_id: imdb or thetvdb id from video
        :type video_id: str
        :return:
        """
        try:
            if video_id:
                folder = os.path.join(path, cleaned_title)
                if os.path.exists(folder):
                    if video_id.startswith('tt'):
                        filename = os.path.join(folder, cleaned_title + '.nfo')
                        with open(filename, "w") as text_file:
                            text_file.write("http://www.imdb.com/title/%s/" % video_id)

                    else:
                        filename = os.path.join(folder, 'tvshow.nfo')
                        with open(filename, "w") as text_file:
                            text_file.write('http://thetvdb.com/?tab=series&id=%s' % video_id)

        except Exception as e:
            print "Error: %s" % repr(e)

    @classmethod
    def info(cls, imdb_id=None, title='', update=True):
        """
        Collect title, is_movie, season_episodes and year from video
        :param update:
        :param title:
        :type title: str
        :param imdb_id: imdb id from video
        :type imdb_id: str
        :return:
        """
        cls.imdb_id = imdb_id
        if not imdb_id:
            logger.info('Not imdb id')
            list_shows, list_imdb = get_tv_shows_list(title)
            if len(list_shows) == 0:
                xbmcgui.Dialog().ok(string(32010), string(32152))
                return False

            else:
                resp = xbmcgui.Dialog().select(string(32153), list_shows)
                if resp > -1:
                    imdb_id = list_imdb[resp]

                else:
                    return False

        # check the storage
        information = Storage.open('library', ttl=None)
        # continue
        video = information.get(imdb_id, {imdb_id: None})
        if video[imdb_id]:
            cls.title = video[imdb_id]['title']
            cls.is_movie = video[imdb_id]['is_movie']
            cls.is_anime = video[imdb_id].get('is_anime', False)
            cls.year = video[imdb_id]['year']
            cls.thetvdb_id = video[imdb_id]['thetvdb_id']
            cls.seasons_episodes = video[imdb_id]['seasons_episodes']

        else:
            cls._read_title_year()
            video[imdb_id] = dict()
            video[imdb_id]['title'] = cls.title
            video[imdb_id]['is_movie'] = cls.is_movie
            video[imdb_id]['is_anime'] = cls.is_anime
            video[imdb_id]['year'] = cls.year
            video[imdb_id]['thetvdb_id'] = cls.thetvdb_id
            video[imdb_id]['seasons_episodes'] = cls.seasons_episodes

        if not cls.is_movie and update:
            # it needs to update information show
            cls.seasons_episodes = cls._new_info(cls.seasons_episodes)
            video[imdb_id]['seasons_episodes'] = cls.seasons_episodes

        # save in storage
        information[cls.imdb_id] = video
        information.close()

        return True

    @classmethod
    def add_to_library(cls, imdb_id, force=False):
        """
        Add a video to the library
        :param force: to rebuild the library
        :type force: bool
        :param imdb_id: imdb id from video
        :type imdb_id: str
        :return:
        """
        if not imdb_id:
            logger.info('Not imdb id')
            return False

        # Read information
        cls.info(imdb_id)

        if not cls.title:
            return False

        # start to populate
        if cls.is_movie:
            folder = xbmc.translatePath(xbmcaddon.Addon().getSetting('movies_folder'))
            payload = '?search=movie&imdb=%s&title=%s&year=%s' % (imdb_id, quote_plus(clean_title(cls.title)), cls.year)
            link = 'plugin://script.module.magnetic%s' % payload
            if force or cls._is_new_movie(imdb_id):
                cls._create_strm(folder, cls.title, cls.title, link)
                cls._create_nfo(folder, cls.title, cls.imdb_id)

        else:
            folder = xbmc.translatePath(
                xbmcaddon.Addon().getSetting('animes_folder' if cls.is_anime else 'shows_folder'))
            cm = 0
            seasons = cls.seasons_episodes.keys()
            seasons.sort(key=int)
            for season in seasons:
                episodes = cls.seasons_episodes[season]
                episodes.sort(key=int)
                for episode in episodes:
                    cm += 1
                    if cls.is_anime:
                        season = 1
                        episode = cm
                        episode_title = '%s E%002d' % (cls.title, episode)
                        payload = '?search=episode&title=%s&season=%s&episode=%s&absolute_number=%s' % (
                            quote_plus(cls.title), season, episode, episode)
                    else:
                        episode_title = '%s S%02dE%02d' % (cls.title, int(season), int(episode))
                        payload = '?search=episode&title=%s&season=%s&episode=%s&absolute_number=%s' % (
                            quote_plus(cls.title), season, episode, 0)

                    link = 'plugin://script.module.magnetic%s' % payload
                    if force or cls._is_new_episode(cls.thetvdb_id, season, episode):
                        cls._create_strm(folder, cls.title, episode_title, link)

            cls._create_nfo(folder, cls.title, cls.thetvdb_id)

        return True

    @classmethod
    def add_to_library_from_torrent(cls, imdb_id):
        """
        Add a video to the library
        :param imdb_id: imdb id from video
        :type imdb_id: str
        :return:
        """
        if not imdb_id:
            logger.info('Not imdb id')
            return False

        # Read information
        cls.info(imdb_id, update=False)
        logger.debug(cls.thetvdb_id)
        folder = xbmc.translatePath(
            xbmcaddon.Addon().getSetting('animes_folder' if cls.is_anime else 'shows_folder'))

        for item in search_title(cls.title):
            logger.debug(item)
            format_title = formatting_title(item, type_video='SHOW')
            season = format_title['season']
            episode = format_title['episode']
            logger.debug(season)
            logger.debug(episode)
            if season == 0 or episode == 0:
                continue

            if not cls._is_new_episode(cls.thetvdb_id, season, episode):
                logger.debug('%s S%02dE%02d is not new' % (cls.title, int(season), int(episode)))
                return False

            if cls.is_anime:
                episode_title = '%s E%002d' % (cls.title, episode)
                payload = '?search=episode&title=%s&season=%s&episode=%s&absolute_number=%s' % (
                    quote_plus(cls.title), season, episode, episode)
            else:
                episode_title = '%s S%02dE%02d' % (cls.title, int(season), int(episode))
                payload = '?search=episode&title=%s&season=%s&episode=%s&absolute_number=%s' % (
                    quote_plus(cls.title), season, episode, 0)

            link = 'plugin://script.module.magnetic%s' % payload
            logger.debug(link)
            if cls._is_new_episode(cls.thetvdb_id, season, episode):
                cls._create_strm(folder, cls.title, episode_title, link)

        return True

    @classmethod
    def update_subscription(cls):
        """
        Check the list of tv shows and update the strm files
        :return:
        """
        tv_shows = Storage.open('subscriptions', ttl=None)
        information = Storage.open('library', ttl=None)
        for imdb_id in tv_shows:
            logger.debug(imdb_id)
            if not xbmc.Player().isPlayingVideo():
                dialog = xbmcgui.Dialog()
                video = information.get(imdb_id, {imdb_id: None})
                icon, fanart = find_art_imdb(imdb_id)
                dialog.notification('[COLOR FFFFD800][B]magnetic[/B][/COLOR]',
                                    video[imdb_id]['title'] if video[imdb_id] else imdb_id, icon=icon)
                del dialog

            cls.add_to_library_from_torrent(imdb_id)

        update_library()
        information.close()
        tv_shows.close()

    @staticmethod
    def add_subscription(imdb_id):
        """
        Add tv show to the subscription list
        :param imdb_id: imdb id from video
        :type imdb_id: str
        :return: True if succeed. False, otherwise.
        """
        if not imdb_id:
            return False

        tv_shows = Storage.open('subscriptions', ttl=None)
        tv_shows[imdb_id] = 'x'
        tv_shows.close()
        return True

    @staticmethod
    def remove_subscription(imdb_id, remove=True):
        """
        Remove tv show to the subscription list
        :param remove: if the files will be removed or not
        :type remove: bool
        :param imdb_id: imdb id from video
        :type imdb_id: str
        :return: True if succeed. False, otherwise.
        """
        if not imdb_id:
            return False

        tv_shows = Storage.open('subscriptions', ttl=None)
        information = Storage.open('library', ttl=None)
        video = information.get(imdb_id, {imdb_id: None})
        title = None
        if video[imdb_id]:
            title = video[imdb_id]['title']

        if imdb_id in tv_shows:
            del tv_shows[imdb_id]
            del information[imdb_id]
        tv_shows.close()
        information.close()
        if remove and title:
            show_folder = xbmc.translatePath(xbmcaddon.Addon().getSetting('shows_folder'))
            folder = os.path.join(show_folder, title)
            logger.debug(folder)
            if os.path.exists(folder):
                rmtree(folder)

        clean_library()
        return True

    @staticmethod
    def is_subscribed(imdb_id):
        """
        Return is the tv show is the subscription list
        :param imdb_id: imdb id from video
        :type imdb_id: str
        :return: True is in the list. False, otherwise.
        """
        if not imdb_id:
            return False

        tv_shows = Storage.open('subscriptions', ttl=None)
        result = imdb_id in tv_shows
        tv_shows.close()
        return result
