# coding: utf-8
# Name:        utils.py
# Author:      Mancuniancol
# Created on:  28.11.2016
# Licence:     GPL v.3: http://www.gnu.org/copyleft/gpl.html
"""
Helper methods
"""
import json
import os
import re
import socket
import urllib2
import xbmc
import xbmcgui
from contextlib import closing
from shutil import rmtree

import json_rcp
from constants import *
from storage import Storage

info_video = None
watched = False


def is_playing():
    """
    Checks if the video player is working
    """
    return xbmc.Player().isPlayingVideo()


def close_dialog():
    """
    Close Ok Dialog
    """
    xbmc.executebuiltin('Dialog.Close(okdialog, true)')


def start_busy():
    """
    Start Busy icon
    """
    xbmc.executebuiltin("ActivateWindow(busydialog)")


def end_busy():
    """
    End Busy icon
    """
    xbmc.executebuiltin("Dialog.Close(busydialog)")


def end_notification():
    """
    End Busy icon
    """
    xbmc.executebuiltin("Dialog.Close(notification)")


def remove_folder(folder, title=None):
    """
    Remove a folder
    :param folder: folder to remove
    :type folder: string
    :param title: title folder to remove
    :type title: string
    :return: None
    """
    if title:
        folder = os.path.join(folder, title)

    if os.path.isdir(folder):
        rmtree(folder)


def clear_info():
    """
    Reset info_video and watched global variable
    :return: None
    """
    global info_video, watched
    info_video = None
    watched = False


def is_watched():
    """
    Return value watched global variable
    :return: bool
    """
    global watched
    return watched


def get_item_player():
    """
    Get video information from the Player
    :return: dict()
    """
    global info_video
    info_video = json_rcp.get_item_player()


def check_watched():
    """
    mark all the episodes from info_video as watched
    :return: None
    """
    global info_video, watched
    # {u'tvshowid': -1, u'episode': -1, u'title': u'', u'season': -1, u'label': u'[HorribleSubs]
    # Dragon Ball Super - 84 [720p].mkv', u'type': u'unknown', u'showtitle': u''}

    if 'showtitle' in info_video and info_video['season'] > -1 and info_video['episode'] > -1:
        tv_show_id = find_tv_show_id(info_video['showtitle'])
        episodes = json_rcp.get_episode(tv_show_id, info_video['episode'], info_video['season'])
        for episode in episodes:
            json_rcp.set_watched(episode['episodeid'])

        watched = True
        xbmc.executebuiltin("Container.Update")
        return tv_show_id, episodes

    else:
        return info_video['label']


def set_resume_point(resume_point=0):
    """
    Set the resume point
    :param resume_point: time in seconds
    :type resume_point: double
    :return:
    """
    global info_video

    resume_point_storage = Storage().open("resume_point", ttl=43200)
    resume_point_storage[xbmc.getInfoLabel("ListItem.Label")] = (info_video, resume_point)
    resume_point_storage.close()


def remove_resume_point():
    """
    remove the resume point
    :return:
    """
    global info_video

    resume_point_storage = Storage().open("resume_point", ttl=43200)
    if xbmc.getInfoLabel("ListItem.Label") in resume_point_storage:
        del resume_point_storage[xbmc.getInfoLabel("ListItem.Label")]

    resume_point_storage.close()


def find_tv_show_id(title):
    """
    Find the ID from Tv show using title
    :param title: title to find ID
    :type title: string
    :return:
    """
    tv_show_id = None
    tv_shows = json_rcp.get_tv_shows()
    for tv_show in tv_shows:
        if tv_show['title'] in title:
            tv_show_id = tv_show['tvshowid']
            break

    return tv_show_id


def magnetizer():
    """
    Run Magnetizer
    :return:
    """
    import contextitem
    contextitem.main()


def check_parser(parser=""):
    """
    Verify the parser's health
    :param parser: name of parser to check
    :type parser: str
    :return: string with the duration and number of collected results
    """
    magnetic_url = "http://%s:%s" % (str(MAGNETIC_SERVICE_HOST), str(MAGNETIC_SERVICE_PORT))
    title = 'simpsons'
    if 'nyaa' in parser:
        title = 'one%20piece'

    if 'yts' in parser or 'yify' in parser or 'nextorrent' in parser:
        title = 'batman'

    url = magnetic_url + "?search=general&title=%s&parser=%s" % (title, parser)
    results = dict()
    socket.setdefaulttimeout(120)
    try:
        req = urllib2.Request(url, None)
        with closing(urllib2.urlopen(req, timeout=120)) as response:
            results = json.loads(response.read())

    except Exception as e:
        print "Error checking parser %s: %s" % (parser, repr(e))

    duration = results.get('duration', '[COLOR FFC40401]Error[/COLOR]')
    items = results.get('results', 'zero')
    return " [%s for %s items]" % (duration, items)


def check_group_parser():
    """
    Verify the health of enabled parsers
    """
    magnetic_url = "http://%s:%s" % (str(MAGNETIC_SERVICE_HOST), str(MAGNETIC_SERVICE_PORT))
    title = 'simpsons'
    url = magnetic_url + "?search=general&title=%s" % title
    results = dict()
    socket.setdefaulttimeout(120)
    try:
        req = urllib2.Request(url, None)
        with closing(urllib2.urlopen(req, timeout=120)) as response:
            results = json.loads(response.read())

    except Exception as e:
        print "Error checking enabled parsers: %s" % (repr(e))

    duration = results.get('duration', '[COLOR FFC40401]Error[/COLOR]')
    items = results.get('results', 'zero')

    return " [%s for %s items]" % (duration, items)


def get_info(key, parser=None):
    """
    Read the Information from the Addon
    :param parser:
    :param key:
    :return:
    """
    return xbmcaddon.Addon(parser).getAddonInfo(key)


def get_setting(key, converter=unicode, choices=None, override=False, script=""):
    """
    Read add-on's settings
    # Borrowed from xbmc swift2
    :param script:
    :param override: use global setting
    :type override: bool
    :param key: parameter to read
    :type key: str
    :param converter: type of parameter
    :type converter: object
    :param choices: if the parameter has different values, it could pick one
    :type choices: object
    :return:
    """
    if override:
        script = 'script.module.magnetic'

    value = xbmcaddon.Addon(script).getSetting(id=key)
    if converter is str:
        return value

    elif converter is unicode:
        return value.decode('utf-8')

    elif converter is bool:
        return value == 'true'

    elif converter is int:
        return int(value)

    elif isinstance(choices, (list, tuple)):
        return choices[int(value)]

    else:
        raise TypeError('Acceptable converters are str, unicode, bool and '
                        'int. Acceptable choices are instances of list '
                        ' or tuple.')


def set_setting(key, value, script=""):
    """
    Modify add-on's settings
    :param script:
    :param key: parameter to modify
    :type key: str
    :param value: value of the parameter
    :type value: str
    """
    xbmcaddon.Addon(script).setSetting(key, value)


def get_icon_path():
    """
    Get the path from add-on's icon
    :return: icon's path
    """
    addon_path = xbmcaddon.Addon().getAddonInfo("path")

    return os.path.join(addon_path, 'icon.png')


def string(id_value):
    """
    Internationalisation string
    :param id_value: id value from string.po file
    :type id_value: int
    :return: the translated string
    """
    return xbmcaddon.Addon().getLocalizedString(id_value)


def get_int(text):
    """
    Convert string to integer number
    :param text: string to convert
    :type text: str or unicode
    :return: converted string in integer
    """
    return int(get_float(text))


def get_float(text):
    """
    Convert string to float number
    :param text: string to convert
    :type text: str or unicode
    :return: converted string in float
    """
    value = 0
    if isinstance(text, (float, long, int)):
        value = float(text)

    elif isinstance(text, str) or isinstance(text, unicode):
        # noinspection PEP8, PyBroadException
        try:
            text = clean_number(text)
            match = re.search('([0-9]*\.[0-9]+|[0-9]+)', text)
            if match:
                value = float(match.group(0))

        except:
            value = 0

    return value


# noinspection PeP8, PyBroadException
def size_int(size_txt):
    """
    Convert string with size format to integer
    :param size_txt: string to be converted
    :type size_txt: str
    :return: converted string in integer
    """
    try:
        return int(size_txt)

    except:
        size_txt = size_txt.upper()
        size1 = size_txt.replace('B', '').replace('I', '').replace('K', '').replace('M', '').replace('G', '')
        size = get_float(size1)
        if 'K' in size_txt:
            size *= 1000

        if 'M' in size_txt:
            size *= 1000000

        if 'G' in size_txt:
            size *= 1e9

        return size


def clean_number(text):
    """
    Convert string with a number to USA decimal format
    :param text: string with the number
    :type text: str or unicode
    :return: converted number in string
    """
    comma = text.find(u',')
    point = text.find(u'.')
    if comma > 0 and point > 0:
        if comma < point:
            text = text.replace(u',', u'')

        else:
            text = text.replace(u'.', u'')
            text = text.replace(u',', u'.')

    return text


def notify(message, image=None):
    """
    Create notification dialog
    :param message: message to notify
    :type message: str
    :param image: path of the image
    :type image: str
    """
    dialog = xbmcgui.Dialog()
    dialog.notification(ADDON_NAME, message, icon=image)
    del dialog


def display_message_cache(subject=''):
    """
    Create the progress dialog when the cache is used
    :param subject: Information of the query
    :type subject: str
    """
    p_dialog = xbmcgui.DialogProgressBG()
    p_dialog.create('[COLOR FFFFD800][B]magnetic[/B][/COLOR] : %s' % subject, string(32061))
    xbmc.sleep(50)
    p_dialog.update(25, string(32065))
    xbmc.sleep(50)
    p_dialog.update(50, string(32065))
    xbmc.sleep(50)
    p_dialog.update(75, string(32065))
    xbmc.sleep(50)
    p_dialog.close()
    del p_dialog


def clean_cache():
    """
    Clean all cache
    :return:
    """
    storage_path = os.path.join(xbmc.translatePath("special://temp"), ".storage")
    if os.path.isdir(storage_path):
        for f in os.listdir(storage_path):
            if re.search('.cache', f):
                os.remove(os.path.join(storage_path, f))

    cookies_path = xbmc.translatePath("special://temp")
    if os.path.isdir(cookies_path):
        for f in os.listdir(cookies_path):
            if re.search('.jar', f):
                os.remove(os.path.join(cookies_path, f))


def timedelta_total_seconds(timedelta):
    """
    Count seconds
    :param timedelta:
    :return: seconds
    """
    return (timedelta.microseconds + 0.0 + (timedelta.seconds + timedelta.days * 24 * 3600) * 10 ** 6) / 10 ** 6
