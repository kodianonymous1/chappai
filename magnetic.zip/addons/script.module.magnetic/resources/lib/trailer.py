# coding: utf-8
# Name:        play.py
# Author:      Mancuniancol
# Created on:  28.11.2016
# Licence:     GPL v.3: http://www.gnu.org/copyleft/gpl.html
"""
Play a trailer
"""
import re
import xbmc
from urllib import quote_plus

from browser import Browser
from video_info import find_imdb


def play_trailer(title=None, year=''):
    if not title:
        return

    url = "https://www.google.com/search?q=%s+youtube+official+trailer" % quote_plus(title)
    if len(year) > 0:
        url += '+%s' % year

    if not Browser.open(url):
        return
    code = re.search('watch\?v=(\S+)', Browser.content)
    if not code:
        return
    link = 'plugin://plugin.video.youtube/play/?video_id=%s' % code.group(1)[:-1]
    xbmc.executebuiltin("PlayMedia(%s)" % link)


def information(title=None, imdb_id=None):
    if not imdb_id:
        imdb_id = find_imdb(title)
    if imdb_id:
        xbmc.executebuiltin('XBMC.RunScript(script.extendedinfo,info=extendedinfo,imdb_id=%s)' % imdb_id)
