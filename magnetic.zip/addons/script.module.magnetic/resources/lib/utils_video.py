# coding: utf-8
# Name:        utils.py
# Author:      Mancuniancol
# Created on:  28.11.2016
# Licence:     GPL v.3: http://www.gnu.org/copyleft/gpl.html
"""
Helper methods video
"""
import xbmc

import video_info


def update_imdb(imdb_id):
    """
    update tv show
    :param imdb_id: imdb id from video
    :type imdb_id: str
    :return: True if succeed. False, otherwise.
    """
    video_info.Video.add_to_library_from_torrent(imdb_id)


def update_subscription():
    """
    update all tv shows to the subscription list
    :return: True if succeed. False, otherwise.
    """
    video_info.Video.update_subscription()


def remove_subscription(imdb_id, remove=True):
    """
    Remove tv show to the subscription list
    :param remove: if the files will be removed or not
    :type remove: bool
    :param imdb_id: imdb id from video
    :type imdb_id: str
    :return: True if succeed. False, otherwise.
    """
    video_info.Video.remove_subscription(imdb_id, remove=remove)


def add_library(imdb_id=None, title=None, force=False):
    """
    Add a video to the library using the imdb id from the video
    :param title:
    :type title: str
    :param imdb_id: imdb id from video
    :type imdb_id: str or None
    :param force: to rebuild the library
    :type force: bool
    :return:
    """
    if imdb_id:
        if video_info.Video.info(imdb_id, title):
            if video_info.Video.add_to_library(imdb_id, force=force):
                if not video_info.Video.is_movie:
                    video_info.Video.add_subscription(imdb_id)
                if not xbmc.getCondVisibility('Library.IsScanningVideo'):
                    xbmc.executebuiltin('XBMC.UpdateLibrary(video)')  # update the library with the new information


def find_imdb(title=None):
    """
    Get imdb from title
    :param title: title of the video
    :type title: str or None
    :return: imdb id
    """
    return video_info.find_imdb(title)
