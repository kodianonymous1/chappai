[B]Why to use Magnetic?[/B]
It gives you, just a common Add-on to find all your torrents. Then, it is easier to maintain, keep your search preferences and you can get mostly the same results any where. You are not lock to one Add-on.

You can install the Magnetic repo [URL="https://offshoregit.com/pulsarunofficial/magnetic_repo/repository.magnetic/repository.magnetic-0.1.2.zip"]here[/URL].

[B]Definitions[/B]
[U]Torrenter V2[/U]: Add-on which display information of videos (all the sections of movies and tv shows), search and play torrents. Quasar uses scripts called Searches to get the information.

[U]YATP[/U]: it is only player of torrents. Nothing more. It doesn't search or show information of videos, no sections of movies or tv shows. It doesn't have providers.

[U]Quasar[/U]: Same thing that Torrenter. It uses its own scripts which are called providers and they are incompatible with Torrenter's.

[U]Magnetic[/U]: Add-on which collect torrents under demand.

[U]Torrenter Searcher Magnetic[/U]: Torrenter's seacher which makes call to Magnetic for information.

[U]Magnetic Quasar's provider[/U]: Quasar's provider which makes calls to Magnetic for information.

[U]Magnetizer[/U]: Add-on which is called from contextual menu and uses the name of the item where is called to make calls to Magnetic and it uses any torrent player to play the selected torrent. That includes Quasar, or at least, its player part only.

[U]Parsers[/U]:  Program Add-on which search results to particular site.  Magnetic needs those parsers to work.

[B]Scenarios[/B]
If you use Quasar+Provider, it will work as traditional Pulsar and Quasar have been working, Quasar collects the information. Then, Quasar will check the information of each result getting current information about the size, seeds and peers. Finally, Quasar will show the list.  However, it is not compatible with the Burst.

If you Use Magnetizer+Quasar. It is Magnetizer which calls directly Magnetic. Then, Magnetizer (not Quasar) will show the list of torrents. Magnetizer doesn't verify nor find the missing information provided by Magnetic.

Magnetizer can be called anywhere where it is a video information. Even from the library and other add-ons like Salts, Exodus, etc...

[B]Magnetic module and its parser[/B]
Magnetic is Add-on for Kodi which allows to search torrents for other Add-ons like Torrenter V2 or Quasar.
It also can work independently using the action called Magnetizer in any contextual menu in Kodi and using YATP, KmediaTorrent, XBMCTorrent, Quasar or Torrenter V2 as torrent player.
Magnetic is composed by main module called Magnetic Torrent Manager (script.module.magnetic) and several parsers which starts with script.magnetic.
The Magnetic Manager which is located at Video section controls Magnetic.
[INDENT]BECAUSE MAGNETIC RUNS AS SERVICE, IT IS MANDATORY TO REBOOT EACH TIME THAT YOU GET AN UPDATE. OTHERWISE, MAGNETIC WILL FAIL AND IT WON'T GIVE ANY LINKS.[/INDENT]
Installing Magnetic:
•	Only if you want to use Magnetic as Quasar's or Torrenter V2's provider.  If you want to use only Magnetizer, you can skip this step.  Disable all the current Quasar's and Torrenter V2 providers.
•	Install the repo if you don't have it already installed.  In parenthesis, the name used by the repo.
•	Install the script.module.magnetic (Magnetic Torrent Manager).

•	(Optional) Install the script.quasar.magnetic (Magnetic Quasar's Provider).  Only if you want to use Magnetic as Quasar's provider.
•	(Optional) Install the searcher.torrenter. magnetic (Torrenter Searcher Magnetic) Only if you want to use Magnetic as Torrenter V2's parser.
•	Install as many parsers you want.
[RIGHT]ALL PARSERS WERE BEING TESTED IN KRYPTON. SOME PARSERS DON'T WORK IN PREVIOUS KADI VERSIONS DUE TO INCOMPATIBILITES WITH OPENSSL CERTIFICATE,YOU WILL GET ZERO RESULTS OR A NOTIFICATION. PLEASE,JUST UNINSTALL THAT PROVIDER OR UPDATE YOUR KODI VERSION TO KRYPTON.
QUASAR CHECKS THE HEALTH AND UPDATE THE SEEDS/PEERS INFORMATION. THEN, IT WILL TAKE MORE TIME THAT OTHER TORRENT PLAYERS. BY DEFAULT, EACH PARSER GIVES 10 RESULTS AND IF YOU HAVE 10 PROVIDERS, QUASAR WILL CHECK FOR 100 RESULTS. DEPENDING OF YOUR MACHINE, INTERNET CONNECTION AND LOAD OF THE ONLINE TRACKERS, IT COULD TAKE MINUTES. AS SOLUTION, CONFIGURE THE PROVIDERS TO GIVE ONLY 5 RESULTS OR USE LESS PROVIDERS.[/RIGHT]
•	Only if you want to use Magnetic as Quasar's or Torrenter V2's provider.  If you want to use only Magnetizer, you can skip this step.  Configure Quasar's provider time-out in 15 seconds and Torrenter's provider time-out in Normal (20 seconds). If you use bigger values, it will be the same for Magnetic, because it uses a default value of 10 seconds for its time-out.
•	Go to Magnetic Manager located in the programs section.
[INDENT]YOU CAN USE THE CONTEXTUAL MENU OVER ANY PARSER TO CALL THE OPTIONS.[/INDENT]
•	Select the option Enabled All. It will enable all the installed parsers.
•	Select the option Check All Individually. It will performance a speed test for the enabled parsers.
•	Disable all providers except one (i.e. fastest provider with 10 items).
•	Try to find something in each add-on.
[INDENT]IF YOU DON'T GET LINKS, PLEASE, REBOOT TO BE SURE THAT THE MAGNETIC SERVICE IS ON.  EVERY TIME THAT YOU CALL MAGNETIC, IT WILL APPEAR A MESSAGE.  IF YOU DON'T SEE THE MESSAGE THAT MEANS THE SERVICE IS NOT RUNNING.
IF AFTER THE REBOOT YOU ARE NOT GETTING ANY LINKS, THEN ENABLE THE DEBUG LOG USING THE STEP 2 OF THIS LINK. TRY AGAIN, AND CHECK IN THE LOG FOR THE URL ADDRESS THAT PROVIDER IS USING. TEST IT IN YOUR BROWSER TO VERIFY IF YOU CAN GET ANY RESULTS THERE. CHECK AGAIN THE LOG FOR ANY ERROR IN THE PROVIDER THAT YOU ARE USING. REMEMBER, THAT SOMETIMES THE WEBSITES ARE DOWN OR YOUR KODI VERSION IS NOT COMPATIBLE (OPENSSL).[/INDENT]
•	Try another Magnetic parser. Do not forget to disable the previous one.
•	If you get links, you can add another parser keeping the previous one enable. Use the Check All
as Group to evaluate their speed as group.
Make the required adjustment in the number of providers or timeouts.
Magnetic comes with Contextual Menu which is called Magnetizer. This allows you to use Magnetic everywhere in Kodi and playing the torrent using your favorite torrent player.  Go to Magnetic Manager and configure which Torrenter Player you can to use with Magnetizer, by default, it asks you which torrent player to use.

You can also use the Magnetic Manager to copy settings and configure your magnetic parsers (just click).
Minimum Kodi version 15 (lsengard)


Explanation why different results between Quasar and Magnetizer
There are different types of providers. The best ones which gives magnet from the beginning. Quasar's friendly. These parsers have the "open subpage" option disabled.

There are others which don't give the information in one requests, like nextorrent, 1337x, private tracker (the "subpage option" is enabled).

They are not Quasar friendly. Even, you cannot write a traditional provider with them.

That is another reason why I wrote Magnetizer. And I didn't call it Magnetic which is only a collector of torrent. Not more. Magnetic can be called from other add-ons, like Quasar or Magnetizer. That is the reason why they call different too.

Continuing with the explanation. For those parsers, if you use Quasar, Magnetic cannot return a magnet, it needs to be torrent. That is the trick. Magnetic gives itself like torrent file to Quasar, then Quasar tries to get that Torrent. Magnetic needs to create a torrent from the magnet information. For that, I use itorrents.org. Sometimes, that place doesn't have the torrent or give publicity. Then, it fails to give the information to Quasar and it removes from its list.

Instead, Magnetizer gets always the magnet if there is available and Magnetizer doesn't check each link.

For me Quasar is more reliable. If you have the link displayed that means that it is a valid link. With Magnetizer, you never know.

Then, it is complete normal the difference, because they do the job different. The idea is giving more options to look for something. Not compete between them. Like you see in your case, If Quasar doesn't give you results, you can try Magnetizer.

But, to be fair, you will need to use Quasar friendly providers to have almost the same results or, at least more close. Try with the pirate bay, idope, zooqle. However, Quasar sorts and groups the info. Magnetizer does not.


EXAMPLES
--------
```
general: http://127.0.0.1:5005?search=general&title=ANYTHING
Movie: http://127.0.0.1:5005?search=movie&imdb=tt1111111&title=MOVIE&year=2016
Episode: http://127.0.0.1:5005?search=episode&title=SHOW&season=1&episode=1
Season: http://127.0.0.1:5005?search=season&title=SHOW&season=1
```


specific parser
```
general: http://127.0.0.1:5005?search=general&title=ANYTHING&parser=script.magnetic.name_parser
```
