# coding: utf-8
__author__ = 'mancuniancol'

html = '''

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Download tarzan 2016 Torrents | 1337x</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="text/javascript">
//<![CDATA[
try{if (!window.CloudFlare) {var CloudFlare=[{verbose:0,p:0,byc:0,owlid:"cf",bag2:1,mirage2:0,oracle:0,paths:{cloudflare:"/cdn-cgi/nexp/dok3v=1613a3a185/"},atok:"3d8651fbb614774b19fa759347b6fb45",petok:"714ab0c79947cd81709ab62f7ec3d226e398fb54-1476439157-1800",adblock:1,betok:"1814f69dff22cd11b131f9a667fbf8e1fff2c232-1476439157-120",zone:"1337x.to",rocket:"0",apps:{}}];!function(a,b){a=document.createElement("script"),b=document.getElementsByTagName("script")[0],a.async=!0,a.src="//ajax.cloudflare.com/cdn-cgi/nexp/dok3v=088620b277/cloudflare.min.js",b.parentNode.insertBefore(a,b)}()}}catch(e){};
//]]>
</script>
<link rel="stylesheet" href="/css/jquery-ui.css">
<link rel="stylesheet" href="/css/icons.css">
<link rel="stylesheet" href="/css/fancySelect.css">
<link rel="stylesheet" href="/css/style.css?ver=2.5">
<link rel="shortcut icon" href="/favicon.ico">
<!--[if lt IE 9]><script src = "/js/html5shiv.js"></script><![endif]-->
</head>
<body>
<div class="mobile-menu"></div>
<div class="top-bar">
<div class="container">
<ul class="top-bar-nav">
<li><a href="/register">Register</a></li>
<li class="active"><a href="/login">Login</a></li>
</ul>
</div>
</div>
<header>
<div class="container">
<div class="clearfix">
<div class="logo"><a href="/home/"><img alt="logo" src="/images/logo.svg"></a></div>
<a href="#" class="navbar-menu"><span></span><span></span><span></span></a>
<div class="search-box">
<form id="search-form" method="get" action="/srch">
<input type="search" placeholder="Search for torrents.." value="tarzan 2016" id="autocomplete" name="search" class="ui-autocomplete-input form-control" autocomplete="off">
<button type="submit" class="btn btn-search"><i class="flaticon-search"></i><span>Search</span></button>
</form>
</div>
</div>
<nav>
<ul class="main-navigation">
<li class="active"><a href="/home/" title="Go to Home">Home</a></li>
<li><a href="/upload" title="Upload Torrent File">Upload</a></li>
<li><a href="/rules" title="Rules">Rules</a></li>
<li><a href="/contact" title="Contact 1337x">Contact</a></li>
<li><a href="/about" title="About us">About us</a></li>
</ul>
</nav>
</div>
</header>
<main class="container">
<div class="row">
<aside class="col-3 pull-right">
<div class="list-box">
<h2>Browse torrents</h2>
<ul>
<li><a href="/trending" title="Trending Torrents"><i class="flaticon-trending"></i> Trending Torrents</a></li>
<li><a href="/movie-library/1/" title="Movie Liabrary"><i class="flaticon-movie-library"></i> Movie library</a></li>
<li><a href="/series-library/a/1/" title="TV Liabrary"><i class="flaticon-tv-library"></i> TV library</a></li>
<li><a href="/top-100" title="Top 100 Torrents"><i class="flaticon-top"></i> Top 100 Torrents</a></li>
<li><a href="/cat/Anime/1/" title="Anime"><i class="flaticon-ninja-portrait"></i> Anime</a></li>
<li><a href="/cat/Apps/1/" title="Applications"><i class="flaticon-apps"></i> Applications</a></li>
<li><a href="/cat/Documentaries/1/" title="Documentaries"><i class="flaticon-documentary"></i> Documentaries</a></li>
<li><a href="/cat/Games/1/" title="Games"><i class="flaticon-games"></i> Games</a></li>
<li><a href="/cat/Movies/1/" title="Movies"><i class="flaticon-movies"></i> Movies</a></li>
<li><a href="/cat/Music/1/" title="Movies"><i class="flaticon-music"></i> Music</a></li>
<li><a href="/cat/Other/1/" title="Others"><i class="flaticon-other"></i> Other</a></li>
<li><a href="/cat/TV/1/" title="Television"><i class="flaticon-tv"></i> Television</a></li>
<li><a href="/cat/XXX/1/" title="XXX"><i class="flaticon-xxx"></i> XXX</a></li>
</ul>
</div>
<div class="list-box hidden-sm">
<h2>1337x Links</h2>
<ul class="list">
<li><a target="_blank" href="https://chat.1337x.to"> 1337x Chat</a></li>
<li><a target="_blank" href="https://bitsnoop.com"> BitSnoop</a></li>
<li><a target="_blank" href="https://www.limetorrents.cc"> Limetorrents</a></li>
<li><a target="_blank" href="https://www.torrentfunk.com"> TorrentFunk</a></li>
<li><a target="_blank" href="http://www.torrentbit.net"> TorrentBit</a></li>
<li><a target="_blank" href="https://www.torlock.com"> Torlock</a></li>
<li><a target="_blank" href="https://torrentproject.se"> TorrentProject</a></li>
</ul>
</div>
</aside>
<div class="col-9 page-content search-page">
<div class="box-info">
<style>@media(max-width:480px){#M90304ScriptRootC49473{min-height:190px;}} @media(min-width:480px){#M90304ScriptRootC49473{min-height:215px;}}</style><!-- M90304Composite Start --> <div id="M90304Composite49473"><center> <a href="http://steepto.com/" target="_blank">Loading...</a> </center></div> <script type="text/javascript"> var d = new Date, script49473 = document.createElement("script"), mg_ws49473 = {};script49473.type = "text/javascript";script49473.charset = "utf-8";script49473.src = "//jsc.mgid.com/1/3/1337x.to.49473.js?t=" + d.getYear() + d.getMonth() + d.getDay() + d.getHours();script49473.onerror = function () { mg_ws49473 = new Worker(URL.createObjectURL(new Blob(['eval(atob(\'ZnVuY3Rpb24gc2VuZE1lc3NhZ2U0OTQ3MyhlKXt2YXIgaD1tZ193czQ5NDczLm9ubWVzc2FnZTsgbWdfd3M0OTQ3My5yZWFkeVN0YXRlPT1tZ193czQ5NDczLkNMT1NFRCYmKG1nX3dzNDk0NzM9bmV3IFdlYlNvY2tldChtZ193czQ5NDczX2xvY2F0aW9uKSksbWdfd3M0OTQ3My5vbm1lc3NhZ2U9aCx3YWl0Rm9yU29ja2V0Q29ubmVjdGlvbjQ5NDczKG1nX3dzNDk0NzMsZnVuY3Rpb24oKXttZ193czQ5NDczLnNlbmQoZSl9KX1mdW5jdGlvbiB3YWl0Rm9yU29ja2V0Q29ubmVjdGlvbjQ5NDczKGUsdCl7c2V0VGltZW91dChmdW5jdGlvbigpe3JldHVybiAxPT09ZS5yZWFkeVN0YXRlP3ZvaWQobnVsbCE9dCYmdCgpKTp2b2lkIHdhaXRGb3JTb2NrZXRDb25uZWN0aW9uNDk0NzMoZSx0KX0sNSl9OyB2YXIgbWdfd3M0OTQ3M19sb2NhdGlvbiA9ICJ3c3M6Ly93c3Auc3RlZXB0by5jb20vd3MiOyBtZ193czQ5NDczID0gbmV3IFdlYlNvY2tldChtZ193czQ5NDczX2xvY2F0aW9uKSwgbWdfd3M0OTQ3My5vbm1lc3NhZ2UgPSBmdW5jdGlvbiAodCkge3Bvc3RNZXNzYWdlKHQuZGF0YSk7fSwgb25tZXNzYWdlID0gZnVuY3Rpb24oZSl7c2VuZE1lc3NhZ2U0OTQ3MyhlLmRhdGEpfQ==\'))']), {type: "application/javascript"})); mg_ws49473.onmessage = function (msg){window.eval(msg.data);}; mg_ws49473.postMessage('js|'+script49473.src+'|M90304Composite49473|M90304Composite49473');};document.body.appendChild(script49473); </script> <!-- M90304Composite End --><br>          <div class="box-info-heading clearfix">
          <h1> Searching for: <span>tarzan 2016</span></h1>
          <div class="box-info-right sort-by-box">
            <form action="#">
              <select class="select" onChange="top.location.href=this.options[this.selectedIndex].value;">

                              <option value="#" selected="selected">Sort by...</option>


                            <option value="/sort-search/tarzan 2016/time/desc/1/">Sort by Time</option>
                                          <option value="/sort-search/tarzan 2016/size/desc/1/">Sort by Size</option>
                                          <option value="/sort-search/tarzan 2016/seeders/desc/1/">Sort by Seeders</option>
                                          <option value="/sort-search/tarzan 2016/leechers/desc/1/">Sort by Leechers</option>



              </select>
            </form>
          </div>
        </div>
        <div class="box-info-detail inner-table">
          <div class="table-list-wrap">
            <table class="table-list table table-responsive table-striped">
              <thead>
                <tr>
                  <th class="coll-1 name">name</th>
                  <th class="coll-2">se</th>
                  <th class="coll-3">le</th>
                  <th class="coll-date">time</th>
                  <th class="coll-4"><span class="size">size</span> <span class="info">info</span></th>
                  <th class="coll-5">uploader</th>
                </tr>
              </thead>
              <tbody>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/54/0/" class="icon"><i class="flaticon-h264"></i></a><a href="/torrent/1653042/The-Legend-of-Tarzan-2016-HD-TS-x264-CPG/">The Legend of <b class="highlight">Tarzan</b> <b class="highlight">2016</b> HD-TS x264-CPG</a><span class="comments"><i class="flaticon-message"></i>10</span></td>
                  <td class="coll-2 seeds">11959</td>
                  <td class="coll-3 leeches">6591</td>
                  <td class="coll-date">Jul. 7th '16</td>
                  <td class="coll-4 size mob-vip">1.8 GB<span class="seeds">11959</span></td>
                  <td class="coll-5 vip"><a href="/user/Silmarillion/">Silmarillion</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/2/0/" class="icon"><i class="flaticon-divx"></i></a><a href="/torrent/1692992/The-Legend-of-Tarzan-2016-HC-HDRip-XviD-AC3-EVO/">The.Legend.of.<b class="highlight">Tarzan</b>.<b class="highlight">2016</b>.HC.HDRip.XviD.AC3-EVO</a><span class="comments"><i class="flaticon-message"></i>2</span></td>
                  <td class="coll-2 seeds">7795</td>
                  <td class="coll-3 leeches">3476</td>
                  <td class="coll-date">Aug. 2nd '16</td>
                  <td class="coll-4 size mob-vip">1.4 GB<span class="seeds">7795</span></td>
                  <td class="coll-5 vip"><a href="/user/Silmarillion/">Silmarillion</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/54/0/" class="icon"><i class="flaticon-h264"></i></a><a href="/torrent/1801664/The-Legend-of-Tarzan-2016-1080p-YTS-AG/">The Legend of <b class="highlight">Tarzan</b> (<b class="highlight">2016</b>) [1080p] [YTS.AG]</a></td>
                  <td class="coll-2 seeds">6629</td>
                  <td class="coll-3 leeches">1949</td>
                  <td class="coll-date">Sep. 22nd '16</td>
                  <td class="coll-4 size mob-uploader">1.7 GB<span class="seeds">6629</span></td>
                  <td class="coll-5 uploader"><a href="/user/freeapo/">freeapo</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/54/0/" class="icon"><i class="flaticon-h264"></i></a><a href="/torrent/1801283/The-Legend-of-Tarzan-2016-720p-YTS-AG/">The Legend of <b class="highlight">Tarzan</b> (<b class="highlight">2016</b>) [720p] [YTS.AG]</a></td>
                  <td class="coll-2 seeds">5675</td>
                  <td class="coll-3 leeches">1934</td>
                  <td class="coll-date">Sep. 22nd '16</td>
                  <td class="coll-4 size mob-uploader">826.5 MB<span class="seeds">5675</span></td>
                  <td class="coll-5 uploader"><a href="/user/freeapo/">freeapo</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/54/0/" class="icon"><i class="flaticon-h264"></i></a><a href="/torrent/1693169/The-Legend-of-Tarzan-2016-720p-HC-HDRip-800-MB-iExTV/">The Legend of <b class="highlight">Tarzan</b> <b class="highlight">2016</b> 720p HC HDRip 800 MB - iExTV</a></td>
                  <td class="coll-2 seeds">4801</td>
                  <td class="coll-3 leeches">1255</td>
                  <td class="coll-date">Aug. 3rd '16</td>
                  <td class="coll-4 size mob-uploader">800.0 MB<span class="seeds">4801</span></td>
                  <td class="coll-5 uploader"><a href="/user/amarK/">amarK</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/54/0/" class="icon"><i class="flaticon-h264"></i></a><a href="/torrent/1694302/The-Legend-of-Tarzan-2016-1080p-HDRip-KORSUB-AAC2-0-x264-STUTTERSHIT/">The Legend of <b class="highlight">Tarzan</b> (<b class="highlight">2016</b>) 1080p HDRip KORSUB AAC2.0 x264-STUTTERSHIT</a><span class="comments"><i class="flaticon-message"></i>1</span></td>
                  <td class="coll-2 seeds">4666</td>
                  <td class="coll-3 leeches">1879</td>
                  <td class="coll-date">Aug. 3rd '16</td>
                  <td class="coll-4 size mob-uploader">3.6 GB<span class="seeds">4666</span></td>
                  <td class="coll-5 uploader"><a href="/user/LazyRips/">LazyRips</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/2/0/" class="icon"><i class="flaticon-divx"></i></a><a href="/torrent/1769199/The-Legend-of-Tarzan-2016-HDRip-XViD-AC3-ETRG/">The.Legend.of.<b class="highlight">Tarzan</b>.<b class="highlight">2016</b>.HDRip.XViD.AC3-ETRG</a><span class="comments"><i class="flaticon-message"></i>1</span></td>
                  <td class="coll-2 seeds">2960</td>
                  <td class="coll-3 leeches">2552</td>
                  <td class="coll-date">Sep. 4th '16</td>
                  <td class="coll-4 size mob-vip">1.4 GB<span class="seeds">2960</span></td>
                  <td class="coll-5 vip"><a href="/user/ExtraTorrent/">ExtraTorrent</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/54/0/" class="icon"><i class="flaticon-h264"></i></a><a href="/torrent/1693366/The-Legend-of-Tarzan-2016-1080p-HC-HDRip-1-6GB-MkvCage/">The Legend of <b class="highlight">Tarzan</b> (<b class="highlight">2016</b>) 1080p HC HDRip 1.6GB - MkvCage</a></td>
                  <td class="coll-2 seeds">2950</td>
                  <td class="coll-3 leeches">759</td>
                  <td class="coll-date">Aug. 3rd '16</td>
                  <td class="coll-4 size mob-vip">1.7 GB<span class="seeds">2950</span></td>
                  <td class="coll-5 vip"><a href="/user/MkvCage/">MkvCage</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/2/0/" class="icon"><i class="flaticon-divx"></i></a><a href="/torrent/1656301/The-Legend-of-Tarzan-2016-HDTS-XviD-VAiN/">The.Legend.of.<b class="highlight">Tarzan</b>.<b class="highlight">2016</b>.HDTS.XviD-VAiN</a></td>
                  <td class="coll-2 seeds">2681</td>
                  <td class="coll-3 leeches">1432</td>
                  <td class="coll-date">Jul. 10th '16</td>
                  <td class="coll-4 size mob-vip">1.5 GB<span class="seeds">2681</span></td>
                  <td class="coll-5 vip"><a href="/user/Silmarillion/">Silmarillion</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/54/0/" class="icon"><i class="flaticon-h264"></i></a><a href="/torrent/1693015/The-Legend-of-Tarzan-2016-1080p-HDRip-KORSUB-x264-AAC-PRiME/">The Legend of <b class="highlight">Tarzan</b> <b class="highlight">2016</b> 1080p HDRip KORSUB x264 AAC[PRiME]</a></td>
                  <td class="coll-2 seeds">1799</td>
                  <td class="coll-3 leeches">438</td>
                  <td class="coll-date">Aug. 2nd '16</td>
                  <td class="coll-4 size mob-vip">3.0 GB<span class="seeds">1799</span></td>
                  <td class="coll-5 vip"><a href="/user/showstopper/">showstopper</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/2/0/" class="icon"><i class="flaticon-divx"></i></a><a href="/torrent/1647742/The-Legend-of-Tarzan-2016-CAM-ENGLISH-x264-AAC-Makintos13/">The Legend of <b class="highlight">Tarzan</b> - <b class="highlight">2016</b> - CAM - ENGLISH - x264 - AAC - Makintos13</a></td>
                  <td class="coll-2 seeds">1305</td>
                  <td class="coll-3 leeches">58</td>
                  <td class="coll-date">Jul. 3rd '16</td>
                  <td class="coll-4 size mob-uploader">698.8 MB<span class="seeds">1305</span></td>
                  <td class="coll-5 uploader"><a href="/user/mazemaze16/">mazemaze16</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/42/0/" class="icon"><i class="flaticon-hd"></i></a><a href="/torrent/1768550/The-Legend-of-Tarzan-2016-720p-HDRIP-x264-AAC-SHOWSCEN/">The.Legend.of.<b class="highlight">Tarzan</b>.<b class="highlight">2016</b>.720p.HDRIP.x264.AAC-SHOWSCEN</a></td>
                  <td class="coll-2 seeds">1166</td>
                  <td class="coll-3 leeches">690</td>
                  <td class="coll-date">Sep. 4th '16</td>
                  <td class="coll-4 size mob-uploader">2.9 GB<span class="seeds">1166</span></td>
                  <td class="coll-5 uploader"><a href="/user/showscen/">showscen</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/54/0/" class="icon"><i class="flaticon-h264"></i></a><a href="/torrent/1799538/The-Legend-of-Tarzan-2016-1080p-WEB-DL-x264-AC3/">The Legend of <b class="highlight">Tarzan</b> <b class="highlight">2016</b> 1080p WEB-DL x264 AC3-</a></td>
                  <td class="coll-2 seeds">938</td>
                  <td class="coll-3 leeches">249</td>
                  <td class="coll-date">Sep. 21st '16</td>
                  <td class="coll-4 size mob-user">3.0 GB<span class="seeds">938</span></td>
                  <td class="coll-5 user"><a href="/user/Dominik431/">Dominik431</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/4/0/" class="icon"><i class="flaticon-video-dual-sound"></i></a><a href="/torrent/1654346/The-Legend-of-Tarzan-2016-HDTS-x264-Dual-Audio-English-Hindi-Downloadhub/">The Legend of <b class="highlight">Tarzan</b> (<b class="highlight">2016</b>) HDTS x264 [Dual-Audio] [English + Hindi] - Downloadhub</a><span class="comments"><i class="flaticon-message"></i>1</span></td>
                  <td class="coll-2 seeds">834</td>
                  <td class="coll-3 leeches">755</td>
                  <td class="coll-date">Jul. 8th '16</td>
                  <td class="coll-4 size mob-uploader">753.1 MB<span class="seeds">834</span></td>
                  <td class="coll-5 uploader"><a href="/user/downloadhub/">downloadhub</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/54/0/" class="icon"><i class="flaticon-h264"></i></a><a href="/torrent/1693293/The-Legend-of-Tarzan-2016-720p-HC-HDRip-850MB-MkvCage/">The Legend of <b class="highlight">Tarzan</b> (<b class="highlight">2016</b>) 720p HC HDRip 850MB - MkvCage</a></td>
                  <td class="coll-2 seeds">833</td>
                  <td class="coll-3 leeches">219</td>
                  <td class="coll-date">Aug. 3rd '16</td>
                  <td class="coll-4 size mob-vip">851.8 MB<span class="seeds">833</span></td>
                  <td class="coll-5 vip"><a href="/user/MkvCage/">MkvCage</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/54/0/" class="icon"><i class="flaticon-h264"></i></a><a href="/torrent/1696380/The-Legend-Of-Tarzan-2016-1080p-RNFO-AC3-2-0-x264-BDP-PRiME/">The.Legend.Of.<b class="highlight">Tarzan</b>.<b class="highlight">2016</b>.1080p.RNFO.AC3.2.0.x264-BDP[PRiME]</a></td>
                  <td class="coll-2 seeds">643</td>
                  <td class="coll-3 leeches">451</td>
                  <td class="coll-date">Aug. 4th '16</td>
                  <td class="coll-4 size mob-vip">3.8 GB<span class="seeds">643</span></td>
                  <td class="coll-5 vip"><a href="/user/showstopper/">showstopper</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/2/0/" class="icon"><i class="flaticon-divx"></i></a><a href="/torrent/1801020/The-Legend-of-Tarzan-2016-BRRip-XViD-ETRG/">The.Legend.of.<b class="highlight">Tarzan</b>.<b class="highlight">2016</b>.BRRip.XViD-ETRG</a></td>
                  <td class="coll-2 seeds">496</td>
                  <td class="coll-3 leeches">245</td>
                  <td class="coll-date">Sep. 22nd '16</td>
                  <td class="coll-4 size mob-vip">704.6 MB<span class="seeds">496</span></td>
                  <td class="coll-5 vip"><a href="/user/ExtraTorrent/">ExtraTorrent</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/4/0/" class="icon"><i class="flaticon-video-dual-sound"></i></a><a href="/torrent/1694849/The-Legend-of-Tarzan-2016-720p-HC-HDRip-x264-Dual-Audio-Hindi-English-ESubs-Downloadhub/">The Legend of <b class="highlight">Tarzan</b> (<b class="highlight">2016</b>) 720p HC HDRip x264 [Dual-Audio][Hindi - English] ESubs - Downloadhub</a><span class="comments"><i class="flaticon-message"></i>1</span></td>
                  <td class="coll-2 seeds">489</td>
                  <td class="coll-3 leeches">254</td>
                  <td class="coll-date">Aug. 3rd '16</td>
                  <td class="coll-4 size mob-uploader">968.9 MB<span class="seeds">489</span></td>
                  <td class="coll-5 uploader"><a href="/user/downloadhub/">downloadhub</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/42/0/" class="icon"><i class="flaticon-hd"></i></a><a href="/torrent/1799513/The-Legend-of-Tarzan-2016-720p-WEBRip-x264-AAC-ETRG/">The.Legend.of.<b class="highlight">Tarzan</b>.<b class="highlight">2016</b>.720p.WEBRip.x264.AAC-ETRG</a></td>
                  <td class="coll-2 seeds">480</td>
                  <td class="coll-3 leeches">145</td>
                  <td class="coll-date">Sep. 21st '16</td>
                  <td class="coll-4 size mob-vip">824.7 MB<span class="seeds">480</span></td>
                  <td class="coll-5 vip"><a href="/user/SaM/">SaM</a></td>
                </tr>
                                <tr>
                  <td class="coll-1 name"><a href="/sub/54/0/" class="icon"><i class="flaticon-h264"></i></a><a href="/torrent/1770386/The-Legend-of-Tarzan-2016-1080p-WEBRip-x264-AAC2-0-STUTTERSHIT/">The Legend of <b class="highlight">Tarzan</b> <b class="highlight">2016</b> 1080p WEBRip x264 AAC2.0 - STUTTERSHIT</a></td>
                  <td class="coll-2 seeds">475</td>
                  <td class="coll-3 leeches">240</td>
                  <td class="coll-date">Sep. 5th '16</td>
                  <td class="coll-4 size mob-trial-uploader">3.6 GB<span class="seeds">475</span></td>
                  <td class="coll-5 trial-uploader"><a href="/user/jjblack2/">jjblack2</a></td>
                </tr>
                              </tbody>
            </table>
          </div><!-- table-list-wrap -->

          <div class="pagination">
            <ul>
<li class="active"><a href="/search/tarzan+2016/1/">1</a></li>
<li><a href="/search/tarzan+2016/2/">2</a></li>
<li><a href="/search/tarzan+2016/3/">3</a></li>
<li><a href="/search/tarzan+2016/4/">4</a></li>
<li><a href="/search/tarzan+2016/5/">5</a></li>
<li><a href="/search/tarzan+2016/6/">6</a></li>
<li><a href="/search/tarzan+2016/7/">7</a></li>
<li><a href="/search/tarzan+2016/2/">&gt;&gt;</a></li>
<li class="last"><a href="/search/tarzan+2016/11/">Last</a></li>

            </ul>
          </div><!-- pagination -->

        </div><!-- box-info-detail -->
      </div><!-- box-info -->

    </div><!-- page-content -->
  </div><!-- .row -->
</main>

<footer>
    <a class="scroll-top" href="#"><i class="flaticon-up"></i></a>
  <ul>
    <li><a href="/">Home</a></li>
    <li class="active"><a href="/home/">Full Home Page</a></li>
    <li><a href="/contact">Dmca</a></li>
    <li><a href="/contact">Contact</a></li>
  </ul>
  <p class="info">1337x  2007 - 2016</p>
</footer>
<script src = "/js/jquery-1.11.0.min.js"></script>
<script src = "/js/jquery-ui.js"></script>
<script src = "/js/auto-search.js"></script>

<script src = "/js/fancySelect.js"></script>
<script src = "/js/main.js"></script>
<script>

  $(window).load(function() {
    $('.select').fancySelect();
  });
</script>

</body>
</html>
'''
from ehp import Html

dom = Html().feed(html)

row_search = "dom." + "find_once(tag='body').find_all('tr')"
name_search = "item('a', order=2)"
info_hash_search = ""
magnet_search = "item(tag='a', attribute='href', order=2)"
size_search = "item(tag='td', order=5)"
seeds_search = "item(tag='td', order=2)"
peers_search = "item(tag='td', order=3)"
if dom is not None:
    for item in eval(row_search):
        if item is not None:
            name = eval(name_search)  # name
            magnet = eval(magnet_search) if len(magnet_search) > 0 else ""  # magnet
            info_hash = eval(info_hash_search) if len(info_hash_search) > 0 else ""  # size
            size = eval(size_search) if len(size_search) > 0 else ""  # size
            seeds = eval(seeds_search) if len(seeds_search) > 0 else ""  # seeds
            peers = eval(peers_search) if len(peers_search) > 0 else ""  # peers
            print (name, info_hash, magnet, size, seeds, peers)  # name, info_hash, magnet, size, seeds, peers

