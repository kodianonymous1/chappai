from utils import get_float

print get_float("1,015.37 MB")