# coding: utf-8
__author__ = 'mancuniancol'

html = '''

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" >
		<!--<meta property="og:url" content="http://dolphin.com/happy-new-year/" />-->
		<!--<meta property="og:type" content="website" />-->
		<!--<meta property="og:title" content="In 2016,you will get a gift - Dolphin Browser" />-->
		<!--<meta property="og:description" content="Enter your name and see what you might encounter in the new year." />-->
		<!--<meta property="og:image" content="images/share-logo.png" /> -->
		<!--<meta property="og:url" content="http://idope.se/" />-->
		<!--<meta property="og:type" content="website" />-->
		<!--<meta property="og:title" content="welcome to idope.se for torrent search " />-->
		<!--<meta property="og:description" content="Enter your name and see what you might encounter in the new year." />-->
		<!--<meta property="og:image" content="w/static_pc/img/idope_facebook.png" />-->

		<title>tarzan 2016 - idope torrent search</title>
		<meta name="viewport" content="initial-scale=1, maximum-scale=1" >
		<meta name="Keywords" content="idope, torrent, Download tarzan 2016"/>
		<meta name="Description" content="idope - tribute to kickass"/>
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<link rel="stylesheet" type="text/css" href="/static_pc/css/app.css"/>
		<link rel="stylesheet" type="text/css" href="/static_pc/css/mui.min.css"/>
		<link rel="stylesheet" type="text/css" href="/static_pc/css/searchresult_1.0.0.9.css"/>
		<link rel="shortcut  icon" href="/static_pc/img/favicon.ico"/>
		<script src="/static_pc/js/jquery-1.8.2.min.js" type="text/javascript" charset="utf-8"></script>
	</head>
	<body>

		<div id="hidecategorydiv">-1</div>
		<div id="div0">
			<div id="div1">
				<a href="/">
					<img id="toplogo" src="/static_pc/img/searchresult_toplogo.png" alt="idope - torrent"/>
				</a>
				<div id="inputdiv">
					<input  type="text" name="" id="input" value="tarzan 2016" onkeydown="return input(event)"/>
					<img onclick="searchimgclick()" src="/static_pc/img/searchresult_searchimg.png" id="searchimg" alt="idope - torrent"></img>
				</div>
				<div id="topbottons">
					<a href="/browse.html">
						<div id="toprecentbotton">Recent Torrents</div>
					</a>
					<a href="/top.html">
						<div id="toptopbotton">Most Popular</div>
					</a>
				</div>
			</div>
		</div>
		<div id="" style="clear: both;"></div>
		<div id="showdiv">
			<div id="showdivchild">
				<div id="categorydiv">
					<div id="lidiv">
						<ul id="ul">
							<li id="li0" mycategory="-1">

								<div class="litext" style="color:#55a8fd;">All</div>
								<hr  class="hr" style="display: block;"/></li>


							<li id="li1" mycategory="2">

								<div class="litext">Video</div>
								<hr  class="hr"/></li>

							<li id="li2" mycategory="1">

								<div class="litext">Movies</div>
								<hr  class="hr"/></li>

							<li id="li3" mycategory="3">

								<div class="litext">TV</div>
								<hr  class="hr"/></li>

							<li id="li4" mycategory="7">

								<div class="litext">Games</div>
								<hr  class="hr"/></li>

							<li id="li5" mycategory="6">

								<div class="litext">Music</div>
								<hr  class="hr" /></li>

							<li id="li6" mycategory="4">

								<div class="litext">Anime</div>
								<hr  class="hr" /></li>

							<li id="li7" mycategory="8">

								<div class="litext">Apps</div>
								<hr  class="hr"/></li>

							<li id="li8" mycategory="9">

								<div class="litext" >Books</div>
								<hr  class="hr"/></li>

							<li id="li9" mycategory="5">

								<div class="litext">XXX</div>
								<hr  class="hr"/></li>

							<li id="li10" mycategory="0">

								<div class="litext">Others</div>
								<hr  class="hr"/></li>

						</ul>
					</div>
				</div>
				<hr class="commonhr" />
				<div id="selectdiv">
					<div id="sort" class="hidediv">-1</div>
					<div class="selecttext">Sort by:</div>
					<!--%%selected="selected"-->
					<div id="seletct1div">
						<!--%%sort-->
						<select name="" id="seletct1" >
							<option value="1"  selected="selected" >SEED</option>
							<option value="2" >SIZE</option>
							<option value="3" >AGE</option>
						</select>
					</div>
					<div class="selecttext">in</div>
					<div id="seletct2div">
						<select name="" id="seletct2">
								<option value="4"  selected="selected" >DESCENDING</option>
								<option value="5" >ASENDING</option>
						</select >
					</div>
					<div class="selecttext">order</div>
				</div>
				<div class="clear"></div>
				<div id="div2">
					<div id="div2child">

						<!--<input id="hidetrack" class="hideinfohash" value="&amp;tr=http%3A%2F%2Ftracker.trackerfix.com:80%2Fannounce&amp;tr=udp%3A%2F%2F9.rarbg.com:2710%2Fannounce&amp;tr=udp%3A%2F%2F9.rarbg.me:2710%2Fannounce&amp;tr=udp%3A%2F%2F9.rarbg.to:2710%2Fannounce&amp;tr=udp%3A%2F%2Fcoppersurfer.tk:6969%2Fannounce&amp;tr=udp%3A%2F%2Feddie4.nl:6969%2Fannounce&amp;tr=udp%3A%2F%2Fexodus.desync.com:6969&amp;tr=udp%3A%2F%2Fglotorrents.pw:6969%2Fannounce&amp;tr=udp%3A%2F%2Fopen.demonii.com:1337&amp;tr=udp%3A%2F%2Fp4p.arenabg.ch:1337%2Fannounce&amp;tr=udp%3A%2F%2Fp4p.arenabg.com:1337&amp;tr=udp%3A%2F%2Ftorrent.gresille.org:80%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.aletorrenty.pl:2710%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.coppersurfer.tk:6969%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.glotorrents.com:6969%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.internetwarriors.net:1337&amp;tr=udp%3A%2F%2Ftracker.leechers-paradise.org:6969%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.openbittorrent.com:80%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.opentrackr.org:1337%2Fannounce&amp;tr=udp%3A%2F%2Fzer0day.ch:1337%2Fannounce">&amp;tr=http%3A%2F%2Ftracker.trackerfix.com:80%2Fannounce&amp;tr=udp%3A%2F%2F9.rarbg.com:2710%2Fannounce&amp;tr=udp%3A%2F%2F9.rarbg.me:2710%2Fannounce&amp;tr=udp%3A%2F%2F9.rarbg.to:2710%2Fannounce&amp;tr=udp%3A%2F%2Fcoppersurfer.tk:6969%2Fannounce&amp;tr=udp%3A%2F%2Feddie4.nl:6969%2Fannounce&amp;tr=udp%3A%2F%2Fexodus.desync.com:6969&amp;tr=udp%3A%2F%2Fglotorrents.pw:6969%2Fannounce&amp;tr=udp%3A%2F%2Fopen.demonii.com:1337&amp;tr=udp%3A%2F%2Fp4p.arenabg.ch:1337%2Fannounce&amp;tr=udp%3A%2F%2Fp4p.arenabg.com:1337&amp;tr=udp%3A%2F%2Ftorrent.gresille.org:80%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.aletorrenty.pl:2710%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.coppersurfer.tk:6969%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.glotorrents.com:6969%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.internetwarriors.net:1337&amp;tr=udp%3A%2F%2Ftracker.leechers-paradise.org:6969%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.openbittorrent.com:80%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.opentrackr.org:1337%2Fannounce&amp;tr=udp%3A%2F%2Fzer0day.ch:1337%2Fannounce</input>-->
						<input id="hidetrack"  style="display:none" value="&amp;tr=http%3A%2F%2Ftracker.trackerfix.com:80%2Fannounce&amp;tr=udp%3A%2F%2F9.rarbg.com:2710%2Fannounce&amp;tr=udp%3A%2F%2F9.rarbg.me:2710%2Fannounce&amp;tr=udp%3A%2F%2F9.rarbg.to:2710%2Fannounce&amp;tr=udp%3A%2F%2Fcoppersurfer.tk:6969%2Fannounce&amp;tr=udp%3A%2F%2Feddie4.nl:6969%2Fannounce&amp;tr=udp%3A%2F%2Fexodus.desync.com:6969&amp;tr=udp%3A%2F%2Fglotorrents.pw:6969%2Fannounce&amp;tr=udp%3A%2F%2Fopen.demonii.com:1337&amp;tr=udp%3A%2F%2Fp4p.arenabg.ch:1337%2Fannounce&amp;tr=udp%3A%2F%2Fp4p.arenabg.com:1337&amp;tr=udp%3A%2F%2Ftorrent.gresille.org:80%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.aletorrenty.pl:2710%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.coppersurfer.tk:6969%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.glotorrents.com:6969%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.internetwarriors.net:1337&amp;tr=udp%3A%2F%2Ftracker.leechers-paradise.org:6969%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.openbittorrent.com:80%2Fannounce&amp;tr=udp%3A%2F%2Ftracker.opentrackr.org:1337%2Fannounce&amp;tr=udp%3A%2F%2Fzer0day.ch:1337%2Fannounce"/>

						<div class="resultdiv">
							<div class="resultdivtop">
								<img class="resultdivtopimg" src="/static_pc/img/c1.png" alt="idope - torrent"/>
								<!--<div  class="resultdivtopname" onclick="itemclick(0)">[ Torrent9.ws ] The.Legend.of.Tarzan.2016.FRENCH.BDRip.XViD-FUNKKY </div>-->
								<a href="/torrent/tarzan 2016/bdf9065c8da7b18adb6e8a0d801e30c09be86645/" target="_blank"><div  class="resultdivtopname" >
									[ Torrent9.ws ] The.Legend.of.Tarzan.2016.FRENCH.BDRip.XViD-FUNKKY</div></a>
							</div>
							<div class="resultdivbotton">


									<div class="resultdivbottoncategory">Movies</div>


								<div class="resulttime">
									<div  class="resultdivbottontimeimg">AGE:</div>
									<div class="resultdivbottontime">3 weeks</div>
								</div>
								<div class="resultlength">
									<div  class="resultdivbottonlengthimg">SIZE:</div>
									<div class="resultdivbottonlength">1.4 GB</div>
								</div>
								<div class="resultseed">
									<div  class="resultdivbottonseedimg">SEED:</div>
									<div class="resultdivbottonseed">1590</div>
								</div>
								<div class="resultfile">
									<div  class="resultdivbottonfilesimg">FILES:</div>
									<div class="resultdivbottonfiles">2</div>
								</div>
								<div id="hideinfohash0" class="hideinfohash">bdf9065c8da7b18adb6e8a0d801e30c09be86645</div>
								<div id="hidename0" class="hideinfohash">[ Torrent9.ws ] The.Legend.of.Tarzan.2016.FRENCH.BDRip.XViD-FUNKKY</div>

								<div class="magneticdiv" onclick="itemclick(0)">
									<img class="magneticimg" src="/static_pc/img/magneticimg.png" alt="idope - torrent"/>
									<div class="magnetictext">MAGNET URI</div>
								</div>
							</div>
						</div>

						<div class="resultdiv">
							<div class="resultdivtop">
								<img class="resultdivtopimg" src="/static_pc/img/c1.png" alt="idope - torrent"/>
								<!--<div  class="resultdivtopname" onclick="itemclick(1)">A Lenda de Tarzan 2016 Bluray 720p Dublado - WWW.THEPIRATEFILMES.COM </div>-->
								<a href="/torrent/tarzan 2016/98f013fa083f7ca6b063a0c01d9cfe5e6c2fb8ce/" target="_blank"><div  class="resultdivtopname" >
									A Lenda de Tarzan 2016 Bluray 720p Dublado - WWW.THEPIRATEFILMES.COM</div></a>
							</div>
							<div class="resultdivbotton">


									<div class="resultdivbottoncategory">Movies</div>


								<div class="resulttime">
									<div  class="resultdivbottontimeimg">AGE:</div>
									<div class="resultdivbottontime">2 weeks</div>
								</div>
								<div class="resultlength">
									<div  class="resultdivbottonlengthimg">SIZE:</div>
									<div class="resultdivbottonlength">1.5 GB</div>
								</div>
								<div class="resultseed">
									<div  class="resultdivbottonseedimg">SEED:</div>
									<div class="resultdivbottonseed">1158</div>
								</div>
								<div class="resultfile">
									<div  class="resultdivbottonfilesimg">FILES:</div>
									<div class="resultdivbottonfiles">3</div>
								</div>
								<div id="hideinfohash1" class="hideinfohash">98f013fa083f7ca6b063a0c01d9cfe5e6c2fb8ce</div>
								<div id="hidename1" class="hideinfohash">A Lenda de Tarzan 2016 Bluray 720p Dublado - WWW.THEPIRATEFILMES.COM</div>

								<div class="magneticdiv" onclick="itemclick(1)">
									<img class="magneticimg" src="/static_pc/img/magneticimg.png" alt="idope - torrent"/>
									<div class="magnetictext">MAGNET URI</div>
								</div>
							</div>
						</div>

						<div class="resultdiv">
							<div class="resultdivtop">
								<img class="resultdivtopimg" src="/static_pc/img/c1.png" alt="idope - torrent"/>
								<!--<div  class="resultdivtopname" onclick="itemclick(2)">The Legend Of Tarzan (2016) [YTS.AG] </div>-->
								<a href="/torrent/tarzan 2016/bed60eae1ccbe0c791b7f1fdb898e852d8e0abcc/" target="_blank"><div  class="resultdivtopname" >
									The Legend Of Tarzan (2016) [YTS.AG]</div></a>
							</div>
							<div class="resultdivbotton">


									<div class="resultdivbottoncategory">Movies</div>


								<div class="resulttime">
									<div  class="resultdivbottontimeimg">AGE:</div>
									<div class="resultdivbottontime">3 weeks</div>
								</div>
								<div class="resultlength">
									<div  class="resultdivbottonlengthimg">SIZE:</div>
									<div class="resultdivbottonlength">826.5 MB</div>
								</div>
								<div class="resultseed">
									<div  class="resultdivbottonseedimg">SEED:</div>
									<div class="resultdivbottonseed">1051</div>
								</div>
								<div class="resultfile">
									<div  class="resultdivbottonfilesimg">FILES:</div>
									<div class="resultdivbottonfiles">2</div>
								</div>
								<div id="hideinfohash2" class="hideinfohash">bed60eae1ccbe0c791b7f1fdb898e852d8e0abcc</div>
								<div id="hidename2" class="hideinfohash">The Legend Of Tarzan (2016) [YTS.AG]</div>

								<div class="magneticdiv" onclick="itemclick(2)">
									<img class="magneticimg" src="/static_pc/img/magneticimg.png" alt="idope - torrent"/>
									<div class="magnetictext">MAGNET URI</div>
								</div>
							</div>
						</div>

						<div class="resultdiv">
							<div class="resultdivtop">
								<img class="resultdivtopimg" src="/static_pc/img/c1.png" alt="idope - torrent"/>
								<!--<div  class="resultdivtopname" onclick="itemclick(3)">A Lenda de Tarzan 1080p (2016) Dual Áudio BluRay 5.1 -- By - Lucas Firmo </div>-->
								<a href="/torrent/tarzan 2016/b74a717d009c8dc7c82d4ee5538f46dbad6db543/" target="_blank"><div  class="resultdivtopname" >
									A Lenda de Tarzan 1080p (2016) Dual Áudio BluRay 5.1 -- By - Lucas Firmo</div></a>
							</div>
							<div class="resultdivbotton">


									<div class="resultdivbottoncategory">Movies</div>


								<div class="resulttime">
									<div  class="resultdivbottontimeimg">AGE:</div>
									<div class="resultdivbottontime">2 weeks</div>
								</div>
								<div class="resultlength">
									<div  class="resultdivbottonlengthimg">SIZE:</div>
									<div class="resultdivbottonlength">1.9 GB</div>
								</div>
								<div class="resultseed">
									<div  class="resultdivbottonseedimg">SEED:</div>
									<div class="resultdivbottonseed">981</div>
								</div>
								<div class="resultfile">
									<div  class="resultdivbottonfilesimg">FILES:</div>
									<div class="resultdivbottonfiles">3</div>
								</div>
								<div id="hideinfohash3" class="hideinfohash">b74a717d009c8dc7c82d4ee5538f46dbad6db543</div>
								<div id="hidename3" class="hideinfohash">A Lenda de Tarzan 1080p (2016) Dual Áudio BluRay 5.1 -- By - Lucas Firmo</div>

								<div class="magneticdiv" onclick="itemclick(3)">
									<img class="magneticimg" src="/static_pc/img/magneticimg.png" alt="idope - torrent"/>
									<div class="magnetictext">MAGNET URI</div>
								</div>
							</div>
						</div>

						<div class="resultdiv">
							<div class="resultdivtop">
								<img class="resultdivtopimg" src="/static_pc/img/c2.png" alt="idope - torrent"/>
								<!--<div  class="resultdivtopname" onclick="itemclick(4)">Tarzan.Legenda.2016.D.AVC.ExKinoRay.mkv </div>-->
								<a href="/torrent/tarzan 2016/c14ebc14dec36c0d1f4204eb9750df6712fc2302/" target="_blank"><div  class="resultdivtopname" >
									Tarzan.Legenda.2016.D.AVC.ExKinoRay.mkv</div></a>
							</div>
							<div class="resultdivbotton">


									<div class="resultdivbottoncategory">Video</div>


								<div class="resulttime">
									<div  class="resultdivbottontimeimg">AGE:</div>
									<div class="resultdivbottontime">3 weeks</div>
								</div>
								<div class="resultlength">
									<div  class="resultdivbottonlengthimg">SIZE:</div>
									<div class="resultdivbottonlength">2.2 GB</div>
								</div>
								<div class="resultseed">
									<div  class="resultdivbottonseedimg">SEED:</div>
									<div class="resultdivbottonseed">925</div>
								</div>
								<div class="resultfile">
									<div  class="resultdivbottonfilesimg">FILES:</div>
									<div class="resultdivbottonfiles">1</div>
								</div>
								<div id="hideinfohash4" class="hideinfohash">c14ebc14dec36c0d1f4204eb9750df6712fc2302</div>
								<div id="hidename4" class="hideinfohash">Tarzan.Legenda.2016.D.AVC.ExKinoRay.mkv</div>

								<div class="magneticdiv" onclick="itemclick(4)">
									<img class="magneticimg" src="/static_pc/img/magneticimg.png" alt="idope - torrent"/>
									<div class="magnetictext">MAGNET URI</div>
								</div>
							</div>
						</div>

						<div class="resultdiv">
							<div class="resultdivtop">
								<img class="resultdivtopimg" src="/static_pc/img/c1.png" alt="idope - torrent"/>
								<!--<div  class="resultdivtopname" onclick="itemclick(5)">The Legend Of Tarzan (2016) [1080p] [YTS.AG] </div>-->
								<a href="/torrent/tarzan 2016/b36113d00a92367893164d60c64a7f0a1736dc2c/" target="_blank"><div  class="resultdivtopname" >
									The Legend Of Tarzan (2016) [1080p] [YTS.AG]</div></a>
							</div>
							<div class="resultdivbotton">


									<div class="resultdivbottoncategory">Movies</div>


								<div class="resulttime">
									<div  class="resultdivbottontimeimg">AGE:</div>
									<div class="resultdivbottontime">3 weeks</div>
								</div>
								<div class="resultlength">
									<div  class="resultdivbottonlengthimg">SIZE:</div>
									<div class="resultdivbottonlength">1.7 GB</div>
								</div>
								<div class="resultseed">
									<div  class="resultdivbottonseedimg">SEED:</div>
									<div class="resultdivbottonseed">921</div>
								</div>
								<div class="resultfile">
									<div  class="resultdivbottonfilesimg">FILES:</div>
									<div class="resultdivbottonfiles">2</div>
								</div>
								<div id="hideinfohash5" class="hideinfohash">b36113d00a92367893164d60c64a7f0a1736dc2c</div>
								<div id="hidename5" class="hideinfohash">The Legend Of Tarzan (2016) [1080p] [YTS.AG]</div>

								<div class="magneticdiv" onclick="itemclick(5)">
									<img class="magneticimg" src="/static_pc/img/magneticimg.png" alt="idope - torrent"/>
									<div class="magnetictext">MAGNET URI</div>
								</div>
							</div>
						</div>

						<div class="resultdiv">
							<div class="resultdivtop">
								<img class="resultdivtopimg" src="/static_pc/img/c1.png" alt="idope - torrent"/>
								<!--<div  class="resultdivtopname" onclick="itemclick(6)">The Legend of Tarzan 2016 HD-TS x264-CPG </div>-->
								<a href="/torrent/tarzan 2016/c2fadab194e430b155b5f28941145578069fa43b/" target="_blank"><div  class="resultdivtopname" >
									The Legend of Tarzan 2016 HD-TS x264-CPG</div></a>
							</div>
							<div class="resultdivbotton">


									<div class="resultdivbottoncategory">Movies</div>


								<div class="resulttime">
									<div  class="resultdivbottontimeimg">AGE:</div>
									<div class="resultdivbottontime">3 months</div>
								</div>
								<div class="resultlength">
									<div  class="resultdivbottonlengthimg">SIZE:</div>
									<div class="resultdivbottonlength">1.8 GB</div>
								</div>
								<div class="resultseed">
									<div  class="resultdivbottonseedimg">SEED:</div>
									<div class="resultdivbottonseed">907</div>
								</div>
								<div class="resultfile">
									<div  class="resultdivbottonfilesimg">FILES:</div>
									<div class="resultdivbottonfiles">3</div>
								</div>
								<div id="hideinfohash6" class="hideinfohash">c2fadab194e430b155b5f28941145578069fa43b</div>
								<div id="hidename6" class="hideinfohash">The Legend of Tarzan 2016 HD-TS x264-CPG</div>

								<div class="magneticdiv" onclick="itemclick(6)">
									<img class="magneticimg" src="/static_pc/img/magneticimg.png" alt="idope - torrent"/>
									<div class="magnetictext">MAGNET URI</div>
								</div>
							</div>
						</div>

						<div class="resultdiv">
							<div class="resultdivtop">
								<img class="resultdivtopimg" src="/static_pc/img/c2.png" alt="idope - torrent"/>
								<!--<div  class="resultdivtopname" onclick="itemclick(7)">The.Legend.of.Tarzan.2016.D.HDTV.720p_KOSHARA.mkv </div>-->
								<a href="/torrent/tarzan 2016/cb3f3c238ade1e6f412f71436a8e5ee40c72211e/" target="_blank"><div  class="resultdivtopname" >
									The.Legend.of.Tarzan.2016.D.HDTV.720p_KOSHARA.mkv</div></a>
							</div>
							<div class="resultdivbotton">


									<div class="resultdivbottoncategory">Video</div>


								<div class="resulttime">
									<div  class="resultdivbottontimeimg">AGE:</div>
									<div class="resultdivbottontime">1 months</div>
								</div>
								<div class="resultlength">
									<div  class="resultdivbottonlengthimg">SIZE:</div>
									<div class="resultdivbottonlength">3.3 GB</div>
								</div>
								<div class="resultseed">
									<div  class="resultdivbottonseedimg">SEED:</div>
									<div class="resultdivbottonseed">898</div>
								</div>
								<div class="resultfile">
									<div  class="resultdivbottonfilesimg">FILES:</div>
									<div class="resultdivbottonfiles">1</div>
								</div>
								<div id="hideinfohash7" class="hideinfohash">cb3f3c238ade1e6f412f71436a8e5ee40c72211e</div>
								<div id="hidename7" class="hideinfohash">The.Legend.of.Tarzan.2016.D.HDTV.720p_KOSHARA.mkv</div>

								<div class="magneticdiv" onclick="itemclick(7)">
									<img class="magneticimg" src="/static_pc/img/magneticimg.png" alt="idope - torrent"/>
									<div class="magnetictext">MAGNET URI</div>
								</div>
							</div>
						</div>

						<div class="resultdiv">
							<div class="resultdivtop">
								<img class="resultdivtopimg" src="/static_pc/img/c2.png" alt="idope - torrent"/>
								<!--<div  class="resultdivtopname" onclick="itemclick(8)">The.Legend.of.Tarzan.2016.D.HDTVRip.1400MB_KOSHARA.avi </div>-->
								<a href="/torrent/tarzan 2016/a8a762b04d2e26e88c498bb8209bc05081d4a0b2/" target="_blank"><div  class="resultdivtopname" >
									The.Legend.of.Tarzan.2016.D.HDTVRip.1400MB_KOSHARA.avi</div></a>
							</div>
							<div class="resultdivbotton">


									<div class="resultdivbottoncategory">Video</div>


								<div class="resulttime">
									<div  class="resultdivbottontimeimg">AGE:</div>
									<div class="resultdivbottontime">1 months</div>
								</div>
								<div class="resultlength">
									<div  class="resultdivbottonlengthimg">SIZE:</div>
									<div class="resultdivbottonlength">1.5 GB</div>
								</div>
								<div class="resultseed">
									<div  class="resultdivbottonseedimg">SEED:</div>
									<div class="resultdivbottonseed">889</div>
								</div>
								<div class="resultfile">
									<div  class="resultdivbottonfilesimg">FILES:</div>
									<div class="resultdivbottonfiles">1</div>
								</div>
								<div id="hideinfohash8" class="hideinfohash">a8a762b04d2e26e88c498bb8209bc05081d4a0b2</div>
								<div id="hidename8" class="hideinfohash">The.Legend.of.Tarzan.2016.D.HDTVRip.1400MB_KOSHARA.avi</div>

								<div class="magneticdiv" onclick="itemclick(8)">
									<img class="magneticimg" src="/static_pc/img/magneticimg.png" alt="idope - torrent"/>
									<div class="magnetictext">MAGNET URI</div>
								</div>
							</div>
						</div>

						<div class="resultdiv">
							<div class="resultdivtop">
								<img class="resultdivtopimg" src="/static_pc/img/c2.png" alt="idope - torrent"/>
								<!--<div  class="resultdivtopname" onclick="itemclick(9)">[ www.CpasBien.cm ] The.Legend.of.Tarzan.2016.FRENCH.WEBRip.XViD-FUNKKY.avi </div>-->
								<a href="/torrent/tarzan 2016/8f87c416fe51f063a0f51113dd7dc54882b28f05/" target="_blank"><div  class="resultdivtopname" >
									[ www.CpasBien.cm ] The.Legend.of.Tarzan.2016.FRENCH.WEBRip.XViD-FUNKKY.avi</div></a>
							</div>
							<div class="resultdivbotton">


									<div class="resultdivbottoncategory">Video</div>


								<div class="resulttime">
									<div  class="resultdivbottontimeimg">AGE:</div>
									<div class="resultdivbottontime">3 weeks</div>
								</div>
								<div class="resultlength">
									<div  class="resultdivbottonlengthimg">SIZE:</div>
									<div class="resultdivbottonlength">1.4 GB</div>
								</div>
								<div class="resultseed">
									<div  class="resultdivbottonseedimg">SEED:</div>
									<div class="resultdivbottonseed">877</div>
								</div>
								<div class="resultfile">
									<div  class="resultdivbottonfilesimg">FILES:</div>
									<div class="resultdivbottonfiles">1</div>
								</div>
								<div id="hideinfohash9" class="hideinfohash">8f87c416fe51f063a0f51113dd7dc54882b28f05</div>
								<div id="hidename9" class="hideinfohash">[ www.CpasBien.cm ] The.Legend.of.Tarzan.2016.FRENCH.WEBRip.XViD-FUNKKY.avi</div>

								<div class="magneticdiv" onclick="itemclick(9)">
									<img class="magneticimg" src="/static_pc/img/magneticimg.png" alt="idope - torrent"/>
									<div class="magnetictext">MAGNET URI</div>
								</div>
							</div>
						</div>


					</div>

					<div id="rightloadapp">
						<img id="downloadapplogo" src="/static_pc/img/downloadapplogo.png"/>
						<div id="downloadapptext1">Our services never go down.</div>
						<div id="downloadapptext2">Better mobile-search experience.</div>
						<a href="/apk/down.html" target="_blank">
							<div id="downloadapptext3">DOWNLOAD APP</div>
						</a>
					</div>
				</div>
				<hr class="shorthr"/>

				<div id="div3">
					<div id="hidepage">1</div>
						<!--<div id="hidemaxpage">114</div>-->





						<div class="page" style="color: #55a8fd;" >1</div>
						<!--<div id="next">NEXT </div>    -->


						<div class="page" >2</div>

						<div class="page" >3</div>

						<div class="page" >4</div>

						<div class="page" >5</div>

						<div class="page" >6</div>

						<div class="page" >7</div>

						<div class="page" >8</div>

						<div class="page" >9</div>

						<div class="page" >10</div>



						<div id="next">NEXT </div>



				</div>
			</div>
		</div>
		<div id="" class="myclear">

		</div>
		<div id="div4">

			<div id="feedback">feedback</div>

			<a href="/apk/down.html" target="_blank">
				<div id="downloadapp">download APP</div>
			</a>
			<a href="https://www.facebook.com/idope.se" target="_blank">
				<img id="facebook" src="/static_pc/img/result_facebook.png" alt="idope - torrent"/>
			</a>
			<a href="https://twitter.com/iDope_Torrent" target="_blank">
				<img id="twitter" src="/static_pc/img/result_twitter.png" alt="idope - torrent"/>
			</a>
		</div>
		<div id="goodcover"></div>
		<div id="feedbackdiv">
			<div id="feedbacktopbar">FEEDBACK</div>
			<textarea id="textarea" name="" rows="" cols=""
			placeholder="Do you like us? It's ok if you don't, just tell us why we suck!You can also request torrents here ;)"></textarea>
			<!--<div id="contactdiv">CONTACT</div>-->
			<div class="spacediv"></div>
			<!--<div id="emaildiv">Your email</div>-->
			<div class="spacediv"></div>
			<textarea id="emailtextarea" name="" rows="" cols=""
			placeholder="If you need further support, please leave your email address here."></textarea>
			<hr class="feedbackhr" />
			<div id="feedbackbottondiv">
				<div id="feedbacksubmit" onclick="submit()">SUBMIT</div>
				<div id="feedbackcancle" >CANCEL</div>
			</div>
		</div>
		<script src="/static_pc/js/mui.min.pack.js" type="text/javascript" charset="utf-8"></script>
		<script src="/static_pc/js/searchresult_1.0.0.11.js" type="text/javascript" charset="utf-8"></script>
	</body>
</html>


'''
from ehp import Html

dom = Html().feed(html)

row_search = "dom." + "find_all(tag='div', select=('class', 'resultdiv'))"
name_search = "item('a')"
info_hash_search = "item(tag='div', select=('class', 'hideinfohash'))"
magnet_search = ""
size_search = "item(tag='div', select=('class', 'resultdivbottonlength'))"
seeds_search = "item(tag='div', select=('class', 'resultdivbottonseed'))"
peers_search = ""
if dom is not None:
    for item in eval(row_search):
        if item is not None:
            name = eval(name_search)  # name
            magnet = eval(magnet_search) if len(magnet_search) > 0 else ""  # magnet
            info_hash = eval(info_hash_search) if len(info_hash_search) > 0 else ""  # size
            size = eval(size_search) if len(size_search) > 0 else ""  # size
            seeds = eval(seeds_search) if len(seeds_search) > 0 else ""  # seeds
            peers = eval(peers_search) if len(peers_search) > 0 else ""  # peers
            print (name, info_hash, magnet, size, seeds, peers)  # name, info_hash, magnet, size, seeds, peers
