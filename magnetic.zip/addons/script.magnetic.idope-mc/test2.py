# from storage import *
# storage_info = Storage('C:\\Users\\resua\\AppData\\Roaming\\Kodi\\userdata\\addon_data\\script.module.magnetic', None)
# provider = "hello"
# database = storage_info[provider]
# database["carro"]="12"
# database.sync()
import json
season_item = {'title': 'hello',
               'season': 2,
               'absolute_number': int(0)}
payload = json.dumps(season_item)
